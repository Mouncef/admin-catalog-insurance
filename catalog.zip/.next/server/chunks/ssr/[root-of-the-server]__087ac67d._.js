module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/components/layout/ThemeDropdown.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemeDropdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const THEMES = [
    "light",
    "dark",
    "cupcake",
    "bumblebee",
    "emerald",
    "corporate",
    "synthwave",
    "retro",
    "cyberpunk",
    "valentine",
    "halloween",
    "garden",
    "forest",
    "aqua",
    "lofi",
    "pastel",
    "fantasy",
    "wireframe",
    "black",
    "luxury",
    "dracula",
    "cmyk",
    "autumn",
    "business",
    "acid",
    "lemonade",
    "night",
    "coffee",
    "winter",
    "dim",
    "nord",
    "sunset",
    "caramellatte",
    "abyss",
    "silk"
];
const Check = ({ className = "" })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "16",
        height: "16",
        viewBox: "0 0 24 24",
        fill: "currentColor",
        className: `h-3 w-3 shrink-0 transition-opacity ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M20.285 2l-11.285 11.567-5.286-5.011-3.714 3.716 9 8.728 15-15.285z"
        }, void 0, false, {
            fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
            lineNumber: 15,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
        lineNumber: 12,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
const Swatch = ({ theme })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-theme": theme,
        className: "bg-base-100 grid shrink-0 grid-cols-2 gap-0.5 rounded-md p-1 shadow-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-base-content size-1.5 rounded-full"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                lineNumber: 22,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-primary size-1.5 rounded-full"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                lineNumber: 23,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-secondary size-1.5 rounded-full"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                lineNumber: 24,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-accent size-1.5 rounded-full"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                lineNumber: 25,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
        lineNumber: 20,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
const Chevron = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "12",
        height: "12",
        className: "mt-px hidden size-2 fill-current opacity-60 sm:inline-block",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 2048 2048",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M1799 349l242 241-1017 1017L7 590l242-241 775 775 775-775z"
        }, void 0, false, {
            fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
            lineNumber: 32,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
        lineNumber: 30,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
function ThemeDropdown() {
    // 1) stable au SSR: pas de lecture de window/localStorage
    const [theme, setTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("dark"); // placeholder stable
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // 2) côté client, on synchronise
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setMounted(true);
        const saved = "undefined" !== "undefined" && localStorage.getItem("theme") || document.documentElement.getAttribute("data-theme") || "dark";
        setTheme(saved);
        document.documentElement.setAttribute("data-theme", saved);
    }, []);
    const pick = (t)=>{
        setTheme(t);
        document.documentElement.setAttribute("data-theme", t);
        try {
            localStorage.setItem("theme", t);
        } catch  {}
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        title: "Change Theme",
        className: "dropdown dropdown-end",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                tabIndex: 0,
                role: "button",
                "aria-label": "Change Theme",
                className: "btn group btn-sm gap-1.5 px-1.5 btn-ghost",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-base-100 group-hover:border-base-content/20 border-base-content/10 grid shrink-0 grid-cols-2 gap-0.5 rounded-md border p-1 transition-colors",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-base-content size-1 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                lineNumber: 65,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-primary size-1 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                lineNumber: 66,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-secondary size-1 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                lineNumber: 67,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-accent size-1 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                lineNumber: 68,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                        lineNumber: 63,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Chevron, {}, void 0, false, {
                        fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                        lineNumber: 70,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                lineNumber: 61,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                tabIndex: 0,
                className: "dropdown-content bg-base-200 text-base-content rounded-box top-px max-h-[calc(100vh-8.6rem)] overflow-y-auto border-[length:var(--border)] border-white/5 shadow-2xl outline-[length:var(--border)] outline-black/5 mt-16",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    className: "menu w-56",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "menu-title text-xs",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Theme"
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                lineNumber: 79,
                                columnNumber: 56
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                            lineNumber: 79,
                            columnNumber: 21
                        }, this),
                        THEMES.map((t)=>{
                            const isActive = mounted && theme === t; // ✅ seulement après mount
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>pick(t),
                                    className: "gap-3 px-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Swatch, {
                                            theme: t
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                            lineNumber: 90,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-32 truncate",
                                            children: t
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                            lineNumber: 91,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Check, {
                                            className: isActive ? "opacity-100" : "opacity-0"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                            lineNumber: 93,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                    lineNumber: 85,
                                    columnNumber: 33
                                }, this)
                            }, t, false, {
                                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                                lineNumber: 84,
                                columnNumber: 29
                            }, this);
                        })
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                    lineNumber: 78,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
                lineNumber: 74,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/ThemeDropdown.jsx",
        lineNumber: 59,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/layout/Navbar.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Navbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$ThemeDropdown$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layout/ThemeDropdown.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$panel$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PanelLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/panel-left.js [app-ssr] (ecmascript) <export default as PanelLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$panel$2d$left$2d$close$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PanelLeftClose$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/panel-left-close.js [app-ssr] (ecmascript) <export default as PanelLeftClose>");
"use client";
;
;
;
;
function Navbar({ drawerId = "my-drawer-2" }) {
    const [collapsed, setCollapsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // Lire l’état persistant au chargement (optionnel)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const saved = localStorage.getItem("sidebar-collapsed") === "1";
        setCollapsed(saved);
        document.documentElement.setAttribute("data-sidebar", saved ? "collapsed" : "expanded");
    }, []);
    const toggleSidebar = ()=>{
        const next = !collapsed;
        setCollapsed(next);
        document.documentElement.setAttribute("data-sidebar", next ? "collapsed" : "expanded");
        localStorage.setItem("sidebar-collapsed", next ? "1" : "0");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "navbar bg-base-100 shadow-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "navbar-start gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: drawerId,
                        className: "btn btn-ghost lg:hidden",
                        children: "☰"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/Navbar.jsx",
                        lineNumber: 28,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: toggleSidebar,
                        className: "btn btn-ghost btn-square hidden lg:inline-flex",
                        "aria-pressed": collapsed,
                        "aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar",
                        children: collapsed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$panel$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PanelLeft$3e$__["PanelLeft"], {
                            className: "size-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/Navbar.jsx",
                            lineNumber: 39,
                            columnNumber: 34
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$panel$2d$left$2d$close$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PanelLeftClose$3e$__["PanelLeftClose"], {
                            className: "size-5"
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/Navbar.jsx",
                            lineNumber: 39,
                            columnNumber: 68
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/Navbar.jsx",
                        lineNumber: 33,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/Navbar.jsx",
                lineNumber: 26,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "navbar-center hidden lg:flex"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Navbar.jsx",
                lineNumber: 45,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "navbar-end gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layout$2f$ThemeDropdown$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/layout/Navbar.jsx",
                        lineNumber: 63,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "dropdown dropdown-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                tabIndex: 0,
                                role: "button",
                                className: "btn btn-ghost btn-circle avatar",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "avatar avatar-online avatar-placeholder",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-neutral text-neutral-content w-9 rounded-full",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xl",
                                            children: "MZ"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/Navbar.jsx",
                                            lineNumber: 70,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/Navbar.jsx",
                                        lineNumber: 69,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/Navbar.jsx",
                                    lineNumber: 68,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/Navbar.jsx",
                                lineNumber: 67,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                tabIndex: 0,
                                className: "menu menu-sm dropdown-content bg-base-100 rounded-box z-1 mt-3 w-52 p-2 shadow",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            className: "justify-between",
                                            children: [
                                                "Profile",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "badge",
                                                    children: "New"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Navbar.jsx",
                                                    lineNumber: 85,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/Navbar.jsx",
                                            lineNumber: 83,
                                            columnNumber: 29
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/Navbar.jsx",
                                        lineNumber: 82,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            children: "Settings"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/Navbar.jsx",
                                            lineNumber: 88,
                                            columnNumber: 29
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/Navbar.jsx",
                                        lineNumber: 88,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            children: "Logout"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/Navbar.jsx",
                                            lineNumber: 89,
                                            columnNumber: 29
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/layout/Navbar.jsx",
                                        lineNumber: 89,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/Navbar.jsx",
                                lineNumber: 79,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/Navbar.jsx",
                        lineNumber: 66,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/Navbar.jsx",
                lineNumber: 60,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/Navbar.jsx",
        lineNumber: 24,
        columnNumber: 9
    }, this);
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/components/layout/Breadcrumbs.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Breadcrumbs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"use client";
;
;
;
function titleize(segment) {
    const title = decodeURIComponent(segment).replace(/-/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
    switch(title){
        case "Category":
            return "Catégories";
        default:
            return title;
    }
}
function Breadcrumbs() {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])() || "/";
    const segments = pathname.split("/").filter(Boolean);
    const crumbs = [
        {
            href: "/",
            label: "Accueil"
        },
        ...segments.map((seg, idx)=>({
                href: "/" + segments.slice(0, idx + 1).join("/"),
                label: titleize(seg)
            }))
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "breadcrumbs text-sm",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            children: crumbs.map((c, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    children: i === crumbs.length - 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-semibold",
                        children: c.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/Breadcrumbs.jsx",
                        lineNumber: 37,
                        columnNumber: 29
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: c.href,
                        children: c.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/Breadcrumbs.jsx",
                        lineNumber: 39,
                        columnNumber: 29
                    }, this)
                }, c.href, false, {
                    fileName: "[project]/src/components/layout/Breadcrumbs.jsx",
                    lineNumber: 35,
                    columnNumber: 21
                }, this))
        }, void 0, false, {
            fileName: "[project]/src/components/layout/Breadcrumbs.jsx",
            lineNumber: 33,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/layout/Breadcrumbs.jsx",
        lineNumber: 32,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/layout/Sidebar.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Sidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$container$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/container.js [app-ssr] (ecmascript) <export default as Container>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$table$2d$properties$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TableProperties$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/table-properties.js [app-ssr] (ecmascript) <export default as TableProperties>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$database$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Database$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/database.js [app-ssr] (ecmascript) <export default as Database>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-ssr] (ecmascript) <export default as Package>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/box.js [app-ssr] (ecmascript) <export default as Box>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bookmark$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bookmark$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bookmark.js [app-ssr] (ecmascript) <export default as Bookmark>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$activity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SquareActivity$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/square-activity.js [app-ssr] (ecmascript) <export default as SquareActivity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookText$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-text.js [app-ssr] (ecmascript) <export default as BookText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/cog.js [app-ssr] (ecmascript) <export default as Cog>");
"use client";
;
;
;
/* === Icônes inline (pas de dépendance) === */ const Icon = {
    Home: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M3 10.5L12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1V10.5z"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Sidebar.jsx",
                lineNumber: 10,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 9,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    Box: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M21 8l-9-5-9 5 9 5 9-5z"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 15,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M3 8v8l9 5 9-5V8"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 16,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 14,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    Users: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 21,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "9",
                    cy: "7",
                    r: "4"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 22,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M23 21v-2a4 4 0 0 0-3-3.87"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 23,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M16 3.13a4 4 0 0 1 0 7.75"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 24,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 20,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    CreditCard: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                    x: "2",
                    y: "5",
                    width: "20",
                    height: "14",
                    rx: "2"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 29,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M2 10h20"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 30,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 28,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    Chart: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M3 3v18h18"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 35,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M7 16l3-3 2 2 5-5"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 36,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 34,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    Settings: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 41,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4a1.65 1.65 0 0 0-1 .6 1.65 1.65 0 0 0-.33 1.82l.02.06a2 2 0 1 1-3.38 0l.02-.06A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82-.33l-.06.02a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-.6-1 1.65 1.65 0 0 0-1.82-.33l-.06.02a2 2 0 1 1 0-3.38l.06.02A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06A2 2 0 1 1 7.04 4.3l.06.06A1.65 1.65 0 0 0 9 4.6c.37 0 .72-.12 1-.33a1.65 1.65 0 0 0 .33-1.82l-.02-.06a2 2 0 1 1 3.38 0l-.02.06A1.65 1.65 0 0 0 15 4.6c.37 0 .72-.12 1-.33a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c0 .37.12.72.33 1 .21.28.33.63.33 1s-.12.72-.33 1a1.65 1.65 0 0 0-.33 1z"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 42,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 40,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    Key: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "7.5",
                    cy: "15.5",
                    r: "3.5"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 47,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M10.5 12.5L21 2l1 1-2 2 1 1-2 2 1 1-6 6"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 48,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 46,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    Shield: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Sidebar.jsx",
                lineNumber: 53,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 52,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    File: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 58,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M14 2v6h6"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 59,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 57,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)),
    Help: (p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            ...p,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "12",
                    cy: "12",
                    r: "10"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 64,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M9.09 9a3 3 0 1 1 5.83 1c0 2-3 2-3 4"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 65,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M12 17h.01"
                }, void 0, false, {
                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                    lineNumber: 66,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/layout/Sidebar.jsx",
            lineNumber: 63,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
};
function Sidebar({ drawerId = "my-drawer-2" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "drawer lg:drawer-open",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                id: drawerId,
                type: "checkbox",
                className: "drawer-toggle"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Sidebar.jsx",
                lineNumber: 74,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "drawer-content"
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Sidebar.jsx",
                lineNumber: 77,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "drawer-side",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: drawerId,
                        "aria-label": "close sidebar",
                        className: "drawer-overlay"
                    }, void 0, false, {
                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                        lineNumber: 80,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "menu bg-base-200 text-base-content min-h-full w-80 p-4 gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-lg font-semibold flex items-center gap-2 px-2 py-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$box$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Box$3e$__["Box"], {
                                            size: 16
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/Sidebar.jsx",
                                            lineNumber: 87,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sidebar-label",
                                            children: "Back Office Echiquier"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/layout/Sidebar.jsx",
                                            lineNumber: 88,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                    lineNumber: 86,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                lineNumber: 85,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "menu-title",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Configuration"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                    lineNumber: 115,
                                    columnNumber: 48
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                lineNumber: 115,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                            className: "flex items-center gap-2",
                                            title: "Référentiels",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$database$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Database$3e$__["Database"], {
                                                    size: 16
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 119,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "sidebar-label",
                                                    children: "Référentiels"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 120,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/Sidebar.jsx",
                                            lineNumber: 118,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "/modules",
                                                        className: "flex items-center gap-2",
                                                        title: "Modules",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 125,
                                                                columnNumber: 41
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "sidebar-label",
                                                                children: "Modules"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 126,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                        lineNumber: 124,
                                                        columnNumber: 37
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 123,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "/categories",
                                                        className: "flex items-center gap-2",
                                                        title: "Catégories",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bookmark$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bookmark$3e$__["Bookmark"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 131,
                                                                columnNumber: 41
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "sidebar-label",
                                                                children: "Catégories"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 132,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                        lineNumber: 130,
                                                        columnNumber: 37
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 129,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "/actes",
                                                        className: "flex items-center gap-2",
                                                        title: "Actes",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$activity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SquareActivity$3e$__["SquareActivity"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 137,
                                                                columnNumber: 41
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "sidebar-label",
                                                                children: "Actes"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 138,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                        lineNumber: 136,
                                                        columnNumber: 37
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 135,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "/niveaux",
                                                        className: "flex items-center gap-2",
                                                        title: "Niveaux",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$container$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Container$3e$__["Container"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 143,
                                                                columnNumber: 41
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "sidebar-label",
                                                                children: "Niveaux"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 144,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                        lineNumber: 142,
                                                        columnNumber: 37
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 141,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/Sidebar.jsx",
                                            lineNumber: 122,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                    lineNumber: 117,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                lineNumber: 116,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "menu-title",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Echiquier"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                    lineNumber: 153,
                                    columnNumber: 48
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                lineNumber: 153,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                            className: "flex items-center gap-2",
                                            title: "Administration",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog$3e$__["Cog"], {
                                                    size: 16
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 157,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "sidebar-label",
                                                    children: "Administration"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 158,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/Sidebar.jsx",
                                            lineNumber: 156,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "/offres",
                                                        className: "flex items-center gap-2",
                                                        title: "Offres",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookText$3e$__["BookText"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 163,
                                                                columnNumber: 41
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "sidebar-label",
                                                                children: "Offres"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 164,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                        lineNumber: 162,
                                                        columnNumber: 37
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 161,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "/catalogues",
                                                        className: "flex items-center gap-2",
                                                        title: "Catalogues",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$table$2d$properties$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TableProperties$3e$__["TableProperties"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 169,
                                                                columnNumber: 41
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "sidebar-label",
                                                                children: "Catalogues"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                                lineNumber: 170,
                                                                columnNumber: 41
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                        lineNumber: 168,
                                                        columnNumber: 37
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                                    lineNumber: 167,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/layout/Sidebar.jsx",
                                            lineNumber: 160,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/layout/Sidebar.jsx",
                                    lineNumber: 155,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/layout/Sidebar.jsx",
                                lineNumber: 154,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/layout/Sidebar.jsx",
                        lineNumber: 83,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/layout/Sidebar.jsx",
                lineNumber: 79,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/Sidebar.jsx",
        lineNumber: 73,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/providers/MultiStorageProvider.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MultiStorageProvider",
    ()=>MultiStorageProvider,
    "useMultiStorage",
    ()=>useMultiStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
const DEFAULT_NAMESPACE = 'app:';
const MultiStorageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
const isPlainObject = (v)=>v && typeof v === 'object' && !Array.isArray(v);
const safeParse = (json)=>{
    try {
        return JSON.parse(json);
    } catch  {
        return null;
    }
};
function hydrateFromLocalStorage(sources, namespace) {
    const state = {};
    for (const [key, cfg] of Object.entries(sources)){
        const storageKey = namespace + key;
        const raw = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : null;
        const parsed = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : null;
        const baseDefault = cfg?.default ?? cfg ?? null;
        const shouldMerge = isPlainObject(baseDefault) && isPlainObject(parsed);
        let value = parsed ?? baseDefault;
        if (shouldMerge) value = {
            ...baseDefault,
            ...parsed
        };
        if (cfg?.version && isPlainObject(value)) value.version = cfg.version;
        state[key] = value;
    }
    return state;
}
function MultiStorageProvider({ children, sources = {}, overwriteOnLoad = false, namespace = DEFAULT_NAMESPACE, clearNamespaceBeforeOverwrite = true }) {
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>hydrateFromLocalStorage(sources, namespace));
    // Éventuel écrasement initial (dev/reset)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!overwriteOnLoad) return;
        try {
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            for (const [key, value] of Object.entries(data)){
                window.localStorage.setItem(namespace + key, JSON.stringify(value));
            }
        } catch  {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    // Sync cross-tab
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        function onStorage(e) {
            if (!e.key || !e.key.startsWith(namespace)) return;
            const shortKey = e.key.slice(namespace.length);
            const parsed = safeParse(e.newValue);
            if (parsed !== null) setData((prev)=>({
                    ...prev,
                    [shortKey]: parsed
                }));
        }
        window.addEventListener('storage', onStorage);
        return ()=>window.removeEventListener('storage', onStorage);
    }, [
        namespace
    ]);
    const api = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            data,
            get: (key)=>data[key],
            set: (key, valueOrUpdater)=>{
                setData((prev)=>{
                    const value = typeof valueOrUpdater === 'function' ? valueOrUpdater(prev[key]) : valueOrUpdater;
                    const next = {
                        ...prev,
                        [key]: value
                    };
                    try {
                        if (value === undefined) {
                            // optionnel: nettoyer proprement si undefined passé
                            window.localStorage.removeItem(namespace + key);
                        } else {
                            window.localStorage.setItem(namespace + key, JSON.stringify(value));
                        }
                    } catch  {}
                    return next;
                });
            },
            patch: (key, patch)=>{
                setData((prev)=>{
                    const nextVal = isPlainObject(prev[key]) ? {
                        ...prev[key],
                        ...patch
                    } : patch;
                    try {
                        window.localStorage.setItem(namespace + key, JSON.stringify(nextVal));
                    } catch  {}
                    return {
                        ...prev,
                        [key]: nextVal
                    };
                });
            },
            resetKey: (key)=>{
                const base = sources[key]?.default ?? sources[key] ?? null;
                const val = isPlainObject(base) ? {
                    ...base,
                    ...sources[key]?.version ? {
                        version: sources[key].version
                    } : {}
                } : base;
                setData((prev)=>{
                    try {
                        window.localStorage.setItem(namespace + key, JSON.stringify(val));
                    } catch  {}
                    return {
                        ...prev,
                        [key]: val
                    };
                });
            },
            resetAll: ()=>{
                const fresh = {};
                for (const [key, cfg] of Object.entries(sources)){
                    const base = cfg?.default ?? cfg ?? null;
                    const val = isPlainObject(base) ? {
                        ...base,
                        ...cfg?.version ? {
                            version: cfg.version
                        } : {}
                    } : base;
                    fresh[key] = val;
                    try {
                        window.localStorage.setItem(namespace + key, JSON.stringify(val));
                    } catch  {}
                }
                setData(fresh);
            },
            clearNamespace: ()=>{
                try {
                    const toDelete = [];
                    for(let i = 0; i < window.localStorage.length; i++){
                        const k = window.localStorage.key(i);
                        if (k && k.startsWith(namespace)) toDelete.push(k);
                    }
                    toDelete.forEach((k)=>window.localStorage.removeItem(k));
                } catch  {}
            }
        }), [
        data,
        namespace,
        sources
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MultiStorageContext.Provider, {
        value: api,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/providers/MultiStorageProvider.jsx",
        lineNumber: 152,
        columnNumber: 9
    }, this);
}
function useMultiStorage() {
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(MultiStorageContext);
    if (!ctx) throw new Error('useMultiStorage must be used within <MultiStorageProvider>');
    return ctx;
}
}),
"[project]/src/lib/settings/default.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SETTINGS_VERSION",
    ()=>SETTINGS_VERSION,
    "defaultSettings",
    ()=>defaultSettings
]);
const SETTINGS_VERSION = 1;
const defaultSettings = {
    version: SETTINGS_VERSION,
    // --- préférences UI/app ---
    theme: "light",
    locale: "fr-FR",
    density: "comfortable",
    // --- endpoints / URLs connues par l'UI ---
    apiBaseUrl: "/api",
    // --- flags fonctionnels ---
    showBeta: false,
    ref_niveau_sets_v1: [
        {
            id: "set-classique",
            code: "CLASSIQUE",
            libelle: "Base → Elite",
            ordre: 1,
            is_enabled: true
        },
        {
            id: "set-numerique",
            code: "N1..N6",
            libelle: "Niveau 1 → 6",
            ordre: 2,
            is_enabled: true
        }
    ],
    ref_niveaux_v1: [
        // Set CLASSIQUE
        {
            id: "niv-base",
            ref_set_id: "set-classique",
            code: "BASE",
            libelle: "Niveau de base",
            ordre: 1,
            is_enabled: true
        },
        {
            id: "niv-essentiel",
            ref_set_id: "set-classique",
            code: "ESSENTIEL",
            libelle: "Couverture essentielle",
            ordre: 2,
            is_enabled: true
        },
        {
            id: "niv-confort",
            ref_set_id: "set-classique",
            code: "CONFORT",
            libelle: "Couverture confort",
            ordre: 3,
            is_enabled: true
        },
        {
            id: "niv-renforce",
            ref_set_id: "set-classique",
            code: "RENFORCE",
            libelle: "Renforcé",
            ordre: 4,
            is_enabled: true
        },
        {
            id: "niv-premium",
            ref_set_id: "set-classique",
            code: "PREMIUM",
            libelle: "Premium",
            ordre: 5,
            is_enabled: true
        },
        {
            id: "niv-elite",
            ref_set_id: "set-classique",
            code: "ELITE",
            libelle: "Élite",
            ordre: 6,
            is_enabled: false
        },
        // Set N1..N6
        {
            id: "niv-n1",
            ref_set_id: "set-numerique",
            code: "N1",
            libelle: "Niveau 1",
            ordre: 1,
            is_enabled: true
        },
        {
            id: "niv-n2",
            ref_set_id: "set-numerique",
            code: "N2",
            libelle: "Niveau 2",
            ordre: 2,
            is_enabled: true
        },
        {
            id: "niv-n3",
            ref_set_id: "set-numerique",
            code: "N3",
            libelle: "Niveau 3",
            ordre: 3,
            is_enabled: true
        },
        {
            id: "niv-n4",
            ref_set_id: "set-numerique",
            code: "N4",
            libelle: "Niveau 4",
            ordre: 4,
            is_enabled: true
        },
        {
            id: "niv-n5",
            ref_set_id: "set-numerique",
            code: "N5",
            libelle: "Niveau 5",
            ordre: 5,
            is_enabled: true
        },
        {
            id: "niv-n6",
            ref_set_id: "set-numerique",
            code: "N6",
            libelle: "Niveau 6",
            ordre: 6,
            is_enabled: true
        }
    ],
    ref_modules_v1: [
        {
            "id": "1f3d7b4e-9a2c-4d1e-b65a-5d2f8a9c3e71",
            "code": "HOSP",
            "libelle": "Hospitalisation",
            "ordre": 1
        },
        {
            "id": "2a5b8c7d-3e1f-4a9b-8c6d-0e1f2a3b4c5d",
            "code": "DENTAIRE",
            "libelle": "Dentaire",
            "ordre": 2
        },
        {
            "id": "3c6d9e0f-1a2b-4c5d-8e9f-0a1b2c3d4e5f",
            "code": "OPTIQUE",
            "libelle": "Optique",
            "ordre": 3
        },
        {
            "id": "4e7f0a1b-2c3d-4e5f-9a0b-1c2d3e4f5a6b",
            "code": "PHARMA",
            "libelle": "Pharmacie",
            "ordre": 4
        },
        {
            "id": "5a6b7c8d-9e0f-4a1b-8c2d-3e4f5a6b7c8d",
            "code": "CONSULT",
            "libelle": "Médecine / Consultations",
            "ordre": 5
        },
        {
            "id": "6b7c8d9e-0f1a-4b2c-9d3e-4f5a6b7c8d9e",
            "code": "MATERNITE",
            "libelle": "Maternité",
            "ordre": 6
        },
        {
            "id": "7c8d9e0f-1a2b-4c3d-8e4f-5a6b7c8d9e0f",
            "code": "SOINS_INF",
            "libelle": "Soins infirmiers",
            "ordre": 7
        },
        {
            "id": "8d9e0f1a-2b3c-4d5e-9f6a-7b8c9d0e1f2a",
            "code": "AUX_MED",
            "libelle": "Auxiliaires médicaux",
            "ordre": 8
        },
        {
            "id": "9e0f1a2b-3c4d-5e6f-8a7b-9c0d1e2f3a4b",
            "code": "EQUIPEMENTS",
            "libelle": "Équipements et prothèses",
            "ordre": 9
        },
        {
            "id": "0f1a2b3c-4d5e-6f7a-8b9c-0d1e2f3a4b5c",
            "code": "PREVENTION",
            "libelle": "Services - Prévention",
            "ordre": 10
        },
        {
            "id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "SOINS_COURANTS",
            "libelle": "Soins courants",
            "ordre": 11
        },
        {
            "id": "0ec2af6a-ede4-408d-874e-98dba7e61419",
            "code": "AIDES_AUDITIVES",
            "libelle": "Aides auditives",
            "ordre": 12
        }
    ],
    ref_categories_v1: [
        {
            "id": "a1b2c3d4-0001-4e11-9a10-111111111111",
            "ref_module_id": "1f3d7b4e-9a2c-4d1e-b65a-5d2f8a9c3e71",
            "code": "FRAIS_SEJOUR",
            "libelle": "Frais de séjour (hébergement, plateau technique)",
            "ordre": 1
        },
        {
            "id": "a1b2c3d4-0002-4e11-9a10-222222222222",
            "ref_module_id": "1f3d7b4e-9a2c-4d1e-b65a-5d2f8a9c3e71",
            "code": "HONO",
            "libelle": "Honoraires médicaux et chirurgicaux",
            "ordre": 2
        },
        {
            "id": "a1b2c3d4-0003-4e11-9a10-333333333333",
            "ref_module_id": "1f3d7b4e-9a2c-4d1e-b65a-5d2f8a9c3e71",
            "code": "CHAMBRE_PART",
            "libelle": "Chambre particulière",
            "ordre": 3
        },
        {
            "id": "a1b2c3d4-0004-4e11-9a10-444444444444",
            "ref_module_id": "1f3d7b4e-9a2c-4d1e-b65a-5d2f8a9c3e71",
            "code": "FORFAIT_JOURNALIER",
            "libelle": "Forfait journalier",
            "ordre": 4
        },
        {
            "id": "a1b2c3d4-0005-4e11-9a10-555555555555",
            "ref_module_id": "1f3d7b4e-9a2c-4d1e-b65a-5d2f8a9c3e71",
            "code": "TRANSPORT_MEDICAL",
            "libelle": "Transport médical",
            "ordre": 5
        },
        {
            "id": "b1c2d3e4-0001-4e22-8b20-111111111112",
            "ref_module_id": "2a5b8c7d-3e1f-4a9b-8c6d-0e1f2a3b4c5d",
            "code": "SOINS",
            "libelle": "Soins dentaires courants",
            "ordre": 1
        },
        {
            "id": "b1c2d3e4-0002-4e22-8b20-222222222223",
            "ref_module_id": "2a5b8c7d-3e1f-4a9b-8c6d-0e1f2a3b4c5d",
            "code": "PROTHESES",
            "libelle": "Prothèses dentaires",
            "ordre": 2
        },
        {
            "id": "b1c2d3e4-0003-4e22-8b20-333333333334",
            "ref_module_id": "2a5b8c7d-3e1f-4a9b-8c6d-0e1f2a3b4c5d",
            "code": "ORTHODONTIE",
            "libelle": "Orthodontie",
            "ordre": 3
        },
        {
            "id": "b1c2d3e4-0004-4e22-8b20-444444444445",
            "ref_module_id": "2a5b8c7d-3e1f-4a9b-8c6d-0e1f2a3b4c5d",
            "code": "PARODONTOLOGIE",
            "libelle": "Parodontologie",
            "ordre": 4
        },
        {
            "id": "c1d2e3f4-0001-4e33-7c30-111111111113",
            "ref_module_id": "3c6d9e0f-1a2b-4c5d-8e9f-0a1b2c3d4e5f",
            "code": "VERRES",
            "libelle": "Verres correcteurs",
            "ordre": 1
        },
        {
            "id": "c1d2e3f4-0002-4e33-7c30-222222222224",
            "ref_module_id": "3c6d9e0f-1a2b-4c5d-8e9f-0a1b2c3d4e5f",
            "code": "MONTURE",
            "libelle": "Monture",
            "ordre": 2
        },
        {
            "id": "c1d2e3f4-0003-4e33-7c30-333333333335",
            "ref_module_id": "3c6d9e0f-1a2b-4c5d-8e9f-0a1b2c3d4e5f",
            "code": "LENTILLES",
            "libelle": "Lentilles de contact",
            "ordre": 3
        },
        {
            "id": "c1d2e3f4-0004-4e33-7c30-444444444446",
            "ref_module_id": "3c6d9e0f-1a2b-4c5d-8e9f-0a1b2c3d4e5f",
            "code": "CHIR_REFRACTIVE",
            "libelle": "Chirurgie réfractive",
            "ordre": 4
        },
        {
            "id": "d1e2f3a4-0001-4e44-6d40-111111111114",
            "ref_module_id": "4e7f0a1b-2c3d-4e5f-9a0b-1c2d3e4f5a6b",
            "code": "MEDICAMENTS_REMBOURSABLES",
            "libelle": "Médicaments remboursables",
            "ordre": 1
        },
        {
            "id": "d1e2f3a4-0002-4e44-6d40-222222222225",
            "ref_module_id": "4e7f0a1b-2c3d-4e5f-9a0b-1c2d3e4f5a6b",
            "code": "MEDICAMENTS_NON_REMBOURSABLES",
            "libelle": "Médicaments non remboursables",
            "ordre": 2
        },
        {
            "id": "d1e2f3a4-0003-4e44-6d40-333333333336",
            "ref_module_id": "4e7f0a1b-2c3d-4e5f-9a0b-1c2d3e4f5a6b",
            "code": "VACCINS",
            "libelle": "Vaccins",
            "ordre": 3
        },
        {
            "id": "d1e2f3a4-0004-4e44-6d40-444444444447",
            "ref_module_id": "4e7f0a1b-2c3d-4e5f-9a0b-1c2d3e4f5a6b",
            "code": "PREPARATIONS",
            "libelle": "Préparations magistrales",
            "ordre": 4
        },
        {
            "id": "e1f2a3b4-0001-4e55-5e50-111111111115",
            "ref_module_id": "5a6b7c8d-9e0f-4a1b-8c2d-3e4f5a6b7c8d",
            "code": "MEDECIN_GENERALISTE",
            "libelle": "Médecin généraliste",
            "ordre": 1
        },
        {
            "id": "e1f2a3b4-0002-4e55-5e50-222222222226",
            "ref_module_id": "5a6b7c8d-9e0f-4a1b-8c2d-3e4f5a6b7c8d",
            "code": "SPECIALISTE",
            "libelle": "Consultations spécialiste",
            "ordre": 2
        },
        {
            "id": "e1f2a3b4-0003-4e55-5e50-333333333337",
            "ref_module_id": "5a6b7c8d-9e0f-4a1b-8c2d-3e4f5a6b7c8d",
            "code": "URGENCE",
            "libelle": "Consultations d'urgence",
            "ordre": 3
        },
        {
            "id": "e1f2a3b4-0004-4e55-5e50-444444444448",
            "ref_module_id": "5a6b7c8d-9e0f-4a1b-8c2d-3e4f5a6b7c8d",
            "code": "TELECONSULTATION",
            "libelle": "Téléconsultation",
            "ordre": 4
        },
        {
            "id": "f1a2b3c4-0001-4e66-4f60-111111111116",
            "ref_module_id": "6b7c8d9e-0f1a-4b2c-9d3e-4f5a6b7c8d9e",
            "code": "ACCOUCHEMENT",
            "libelle": "Accouchement",
            "ordre": 1
        },
        {
            "id": "f1a2b3c4-0002-4e66-4f60-222222222227",
            "ref_module_id": "6b7c8d9e-0f1a-4b2c-9d3e-4f5a6b7c8d9e",
            "code": "PRENATAL",
            "libelle": "Soins prénataux",
            "ordre": 2
        },
        {
            "id": "f1a2b3c4-0003-4e66-4f60-333333333338",
            "ref_module_id": "6b7c8d9e-0f1a-4b2c-9d3e-4f5a6b7c8d9e",
            "code": "POSTPARTUM",
            "libelle": "Soins post-partum",
            "ordre": 3
        },
        {
            "id": "f1a2b3c4-0004-4e66-4f60-444444444449",
            "ref_module_id": "6b7c8d9e-0f1a-4b2c-9d3e-4f5a6b7c8d9e",
            "code": "PMA",
            "libelle": "Assistance médicale à la procréation",
            "ordre": 4
        },
        {
            "id": "g1a2b3c4-0001-4e77-3a70-111111111117",
            "ref_module_id": "7c8d9e0f-1a2b-4c3d-8e4f-5a6b7c8d9e0f",
            "code": "PANSEMENTS",
            "libelle": "Pansements et soins infirmiers",
            "ordre": 1
        },
        {
            "id": "g1a2b3c4-0002-4e77-3a70-222222222228",
            "ref_module_id": "7c8d9e0f-1a2b-4c3d-8e4f-5a6b7c8d9e0f",
            "code": "INJECTIONS",
            "libelle": "Injections",
            "ordre": 2
        },
        {
            "id": "g1a2b3c4-0003-4e77-3a70-333333333339",
            "ref_module_id": "7c8d9e0f-1a2b-4c3d-8e4f-5a6b7c8d9e0f",
            "code": "PERFUSIONS",
            "libelle": "Perfusions",
            "ordre": 3
        },
        {
            "id": "h1a2b3c4-0001-4e88-2b80-111111111118",
            "ref_module_id": "8d9e0f1a-2b3c-4d5e-9f6a-7b8c9d0e1f2a",
            "code": "KINESITHERAPIE",
            "libelle": "Kinésithérapie",
            "ordre": 1
        },
        {
            "id": "h1a2b3c4-0002-4e88-2b80-222222222229",
            "ref_module_id": "8d9e0f1a-2b3c-4d5e-9f6a-7b8c9d0e1f2a",
            "code": "ORTHOPHONIE",
            "libelle": "Orthophonie",
            "ordre": 2
        },
        {
            "id": "h1a2b3c4-0003-4e88-2b80-333333333340",
            "ref_module_id": "8d9e0f1a-2b3c-4d5e-9f6a-7b8c9d0e1f2a",
            "code": "ORTHOPTIE",
            "libelle": "Orthoptie",
            "ordre": 3
        },
        {
            "id": "h1a2b3c4-0004-4e88-2b80-444444444450",
            "ref_module_id": "8d9e0f1a-2b3c-4d5e-9f6a-7b8c9d0e1f2a",
            "code": "PODOLOGIE",
            "libelle": "Podologie",
            "ordre": 4
        },
        {
            "id": "h1a2b3c4-0005-4e88-2b80-555555555560",
            "ref_module_id": "8d9e0f1a-2b3c-4d5e-9f6a-7b8c9d0e1f2a",
            "code": "ERGOTHERAPIE",
            "libelle": "Ergothérapie",
            "ordre": 5
        },
        {
            "id": "i1a2b3c4-0001-4e99-1c90-111111111119",
            "ref_module_id": "9e0f1a2b-3c4d-5e6f-8a7b-9c0d1e2f3a4b",
            "code": "PROTHESES_AUDITIVES",
            "libelle": "Prothèses auditives",
            "ordre": 1
        },
        {
            "id": "i1a2b3c4-0002-4e99-1c90-222222222221",
            "ref_module_id": "9e0f1a2b-3c4d-5e6f-8a7b-9c0d1e2f3a4b",
            "code": "ORTESES",
            "libelle": "Orthèses et contentions",
            "ordre": 2
        },
        {
            "id": "i1a2b3c4-0003-4e99-1c90-333333333331",
            "ref_module_id": "9e0f1a2b-3c4d-5e6f-8a7b-9c0d1e2f3a4b",
            "code": "APPAREILLAGE",
            "libelle": "Appareillage médical (DME)",
            "ordre": 3
        },
        {
            "id": "i1a2b3c4-0004-4e99-1c90-444444444441",
            "ref_module_id": "9e0f1a2b-3c4d-5e6f-8a7b-9c0d1e2f3a4b",
            "code": "DMI",
            "libelle": "Dispositifs médicaux implantables",
            "ordre": 4
        },
        {
            "id": "j1a2b3c4-0001-4eaa-0da0-111111111120",
            "ref_module_id": "0f1a2b3c-4d5e-6f7a-8b9c-0d1e2f3a4b5c",
            "code": "BILAN_SANTE",
            "libelle": "Bilan de santé",
            "ordre": 1
        },
        {
            "id": "j1a2b3c4-0002-4eaa-0da0-222222222222",
            "ref_module_id": "0f1a2b3c-4d5e-6f7a-8b9c-0d1e2f3a4b5c",
            "code": "DENTISTERIE_PREVENTIVE",
            "libelle": "Dentisterie préventive (détartrage, scellement)",
            "ordre": 2
        },
        {
            "id": "j1a2b3c4-0003-4eaa-0da0-333333333332",
            "ref_module_id": "0f1a2b3c-4d5e-6f7a-8b9c-0d1e2f3a4b5c",
            "code": "SEVRAGE_TABAGIQUE",
            "libelle": "Sevrage tabagique",
            "ordre": 3
        },
        {
            "id": "j1a2b3c4-0004-4eaa-0da0-444444444442",
            "ref_module_id": "0f1a2b3c-4d5e-6f7a-8b9c-0d1e2f3a4b5c",
            "code": "VACCINATION",
            "libelle": "Vaccination",
            "ordre": 4
        },
        {
            "id": "eca403c7-fd69-4eb4-b19f-03d968171458",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "HONORAIRES_MEDICAUX",
            "libelle": "Honoraires médicaux",
            "ordre": 1
        },
        {
            "id": "f4ea2e83-7705-41f8-ab3b-edd047c0917e",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "IMAGERIE_MEDICAL",
            "libelle": "Imagerie Médicale",
            "ordre": 2
        },
        {
            "id": "038d5c32-bf4d-4c26-ac2c-ed1c827ea2da",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "ANALYSES_EXAMENS_LAB",
            "libelle": "Analyses d'examens et de laboratoire",
            "ordre": 3
        },
        {
            "id": "cd081014-9ded-4952-a7eb-86ac13442858",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "HONORAIRES_PARAMEDICAUX",
            "libelle": "Honoraires paramédicaux",
            "ordre": 4
        },
        {
            "id": "d536d258-c264-4644-9767-e185eb30149c",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "MEDICAMENTS",
            "libelle": "Médicaments",
            "ordre": 5
        },
        {
            "id": "dc5f600a-c704-4d01-94c5-e470882aff03",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "HOMEOPATHIE_PRESCRITE_NON_REMBOURSE_SS",
            "libelle": "Homéopathie prescrite non remboursée par la Sécurité sociale",
            "ordre": 6
        },
        {
            "id": "4dbcb1cb-a041-4702-bd7d-92bf6ce9db08",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "TRANSPORT",
            "libelle": "Transport",
            "ordre": 7
        },
        {
            "id": "92fa1115-5b00-44bc-8748-2543ace54f36",
            "ref_module_id": "15ada47f-4f2b-4aa5-bd8e-fbf6ba1f4ea8",
            "code": "MATERIEL_MEDICAL",
            "libelle": "Matériel médical",
            "ordre": 7
        }
    ],
    ref_acts_v1: [
        {
            "id": "ac111111-0001-4aaa-8a10-000000000001",
            "ref_categorie_id": "b1c2d3e4-0001-4e22-8b20-111111111112",
            "code": "DENT_DETARTRAGE",
            "libelle": "Détartrage dentaire",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ac111111-0002-4aaa-8a10-000000000002",
            "ref_categorie_id": "b1c2d3e4-0001-4e22-8b20-111111111112",
            "code": "DENT_CONSULT",
            "libelle": "Consultation dentaire",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ac111111-0003-4aaa-8a10-000000000003",
            "ref_categorie_id": "b1c2d3e4-0001-4e22-8b20-111111111112",
            "code": "DENT_RADIO_PANO",
            "libelle": "Radiographie panoramique",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "ac111111-0004-4aaa-8a10-000000000004",
            "ref_categorie_id": "b1c2d3e4-0001-4e22-8b20-111111111112",
            "code": "DENT_SOINS_CARIE",
            "libelle": "Soins de carie (obturations)",
            "allow_surco": true,
            "ordre": 4
        },
        {
            "id": "ac222222-0001-4bbb-8b20-000000000001",
            "ref_categorie_id": "b1c2d3e4-0002-4e22-8b20-222222222223",
            "code": "PROTHESE_CM",
            "libelle": "Couronne céramo‑métal",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ac222222-0002-4bbb-8b20-000000000002",
            "ref_categorie_id": "b1c2d3e4-0002-4e22-8b20-222222222223",
            "code": "PROTHESE_CERAM_FULL",
            "libelle": "Couronne tout céramique",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ac222222-0003-4bbb-8b20-000000000003",
            "ref_categorie_id": "b1c2d3e4-0002-4e22-8b20-222222222223",
            "code": "PROTHESE_BRIDGE_3E",
            "libelle": "Bridge 3 éléments",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "ac222222-0004-4bbb-8b20-000000000004",
            "ref_categorie_id": "b1c2d3e4-0002-4e22-8b20-222222222223",
            "code": "PROTHESE_INLAY_CORE",
            "libelle": "Inlay‑core",
            "allow_surco": true,
            "ordre": 4
        },
        {
            "id": "ac333333-0001-4ccc-8c30-000000000001",
            "ref_categorie_id": "b1c2d3e4-0003-4e22-8b20-333333333334",
            "code": "ORTHO_BAGUE_METAL",
            "libelle": "Orthodontie bagues métalliques",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ac333333-0002-4ccc-8c30-000000000002",
            "ref_categorie_id": "b1c2d3e4-0003-4e22-8b20-333333333334",
            "code": "ORTHO_BAGUE_CERAM",
            "libelle": "Orthodontie bagues céramiques",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ac333333-0003-4ccc-8c30-000000000003",
            "ref_categorie_id": "b1c2d3e4-0003-4e22-8b20-333333333334",
            "code": "ORTHO_ALIGNEURS",
            "libelle": "Aligneurs transparents",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "ac333333-0004-4ccc-8c30-000000000004",
            "ref_categorie_id": "b1c2d3e4-0003-4e22-8b20-333333333334",
            "code": "ORTHO_CONTENTION",
            "libelle": "Contention orthodontique",
            "allow_surco": true,
            "ordre": 4
        },
        {
            "id": "ac444444-0001-4ddd-8d40-000000000001",
            "ref_categorie_id": "b1c2d3e4-0004-4e22-8b20-444444444445",
            "code": "PARO_DETARTRAGE_SOUS",
            "libelle": "Détartrage sous‑gingival",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ac444444-0002-4ddd-8d40-000000000002",
            "ref_categorie_id": "b1c2d3e4-0004-4e22-8b20-444444444445",
            "code": "PARO_SURFACAGE",
            "libelle": "Surfaçage radiculaire",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ac444444-0003-4ddd-8d40-000000000003",
            "ref_categorie_id": "b1c2d3e4-0004-4e22-8b20-444444444445",
            "code": "PARO_BILAN",
            "libelle": "Bilan parodontal",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "op111111-0001-4aaa-9a10-000000000001",
            "ref_categorie_id": "c1d2e3f4-0001-4e33-7c30-111111111113",
            "code": "VERRE_SIMPLE",
            "libelle": "Verre simple foyer (correction simple)",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "op111111-0002-4aaa-9a10-000000000002",
            "ref_categorie_id": "c1d2e3f4-0001-4e33-7c30-111111111113",
            "code": "VERRE_COMPLEXE",
            "libelle": "Verre correction complexe",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "op111111-0003-4aaa-9a10-000000000003",
            "ref_categorie_id": "c1d2e3f4-0001-4e33-7c30-111111111113",
            "code": "VERRE_PROGRESSIF",
            "libelle": "Verre progressif",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "op222222-0001-4bbb-9b20-000000000001",
            "ref_categorie_id": "c1d2e3f4-0002-4e33-7c30-222222222224",
            "code": "MONTURE_ADULTE",
            "libelle": "Monture adulte",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "op222222-0002-4bbb-9b20-000000000002",
            "ref_categorie_id": "c1d2e3f4-0002-4e33-7c30-222222222224",
            "code": "MONTURE_ENFANT",
            "libelle": "Monture enfant",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "op333333-0001-4ccc-9c30-000000000001",
            "ref_categorie_id": "c1d2e3f4-0003-4e33-7c30-333333333335",
            "code": "LENTILLE_JOURNALIERE",
            "libelle": "Lentilles journalières",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "op333333-0002-4ccc-9c30-000000000002",
            "ref_categorie_id": "c1d2e3f4-0003-4e33-7c30-333333333335",
            "code": "LENTILLE_MENSUELLE",
            "libelle": "Lentilles mensuelles",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "op333333-0003-4ccc-9c30-000000000003",
            "ref_categorie_id": "c1d2e3f4-0003-4e33-7c30-333333333335",
            "code": "LENTILLE_RGP",
            "libelle": "Lentilles rigides (RGP)",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "op444444-0001-4ddd-9d40-000000000001",
            "ref_categorie_id": "c1d2e3f4-0004-4e33-7c30-444444444446",
            "code": "CHIR_LASIK",
            "libelle": "Chirurgie réfractive LASIK",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "op444444-0002-4ddd-9d40-000000000002",
            "ref_categorie_id": "c1d2e3f4-0004-4e33-7c30-444444444446",
            "code": "CHIR_PRK",
            "libelle": "Chirurgie réfractive PRK",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ho111111-0001-4aaa-7a10-000000000001",
            "ref_categorie_id": "a1b2c3d4-0001-4e11-9a10-111111111111",
            "code": "HOSP_FRAIS_SEJOUR_BASE",
            "libelle": "Frais de séjour – base",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ho222222-0001-4bbb-7b20-000000000001",
            "ref_categorie_id": "a1b2c3d4-0002-4e11-9a10-222222222222",
            "code": "HOSP_HONO_CHIR",
            "libelle": "Honoraires chirurgicaux",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ho222222-0002-4bbb-7b20-000000000002",
            "ref_categorie_id": "a1b2c3d4-0002-4e11-9a10-222222222222",
            "code": "HOSP_HONO_ANESTH",
            "libelle": "Honoraires d'anesthésie",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ho333333-0001-4ccc-7c30-000000000001",
            "ref_categorie_id": "a1b2c3d4-0003-4e11-9a10-333333333333",
            "code": "HOSP_CHAMBRE_PART_JOUR",
            "libelle": "Chambre particulière (par jour)",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ho444444-0001-4ddd-7d40-000000000001",
            "ref_categorie_id": "a1b2c3d4-0004-4e11-9a10-444444444444",
            "code": "HOSP_FORFAIT_JOURNALIER",
            "libelle": "Forfait journalier (par jour)",
            "allow_surco": false,
            "ordre": 1
        },
        {
            "id": "ho555555-0001-4eee-7e50-000000000001",
            "ref_categorie_id": "a1b2c3d4-0005-4e11-9a10-555555555555",
            "code": "HOSP_TRANSPORT_VSL",
            "libelle": "Transport VSL",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ho555555-0002-4eee-7e50-000000000002",
            "ref_categorie_id": "a1b2c3d4-0005-4e11-9a10-555555555555",
            "code": "HOSP_TRANSPORT_AMBULANCE",
            "libelle": "Transport ambulance",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ph111111-0001-4aaa-6a10-000000000001",
            "ref_categorie_id": "d1e2f3a4-0001-4e44-6d40-111111111114",
            "code": "PHARMA_REMBOURSABLE",
            "libelle": "Médicament remboursable",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ph222222-0001-4bbb-6b20-000000000001",
            "ref_categorie_id": "d1e2f3a4-0002-4e44-6d40-222222222225",
            "code": "PHARMA_NON_REMBOURSABLE",
            "libelle": "Médicament non remboursable",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ph333333-0001-4ccc-6c30-000000000001",
            "ref_categorie_id": "d1e2f3a4-0003-4e44-6d40-333333333336",
            "code": "VACCIN_GRIPPE",
            "libelle": "Vaccin grippe saisonnière",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ph333333-0002-4ccc-6c30-000000000002",
            "ref_categorie_id": "d1e2f3a4-0003-4e44-6d40-333333333336",
            "code": "VACCIN_HEP_B",
            "libelle": "Vaccin hépatite B",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ph444444-0001-4ddd-6d40-000000000001",
            "ref_categorie_id": "d1e2f3a4-0004-4e44-6d40-444444444447",
            "code": "PREPARATION_MAGISTRALE",
            "libelle": "Préparation magistrale",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "co111111-0001-4aaa-5a10-000000000001",
            "ref_categorie_id": "e1f2a3b4-0001-4e55-5e50-111111111115",
            "code": "CONS_MED_GEN",
            "libelle": "Consultation médecin généraliste",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "co222222-0001-4bbb-5b20-000000000001",
            "ref_categorie_id": "e1f2a3b4-0002-4e55-5e50-222222222226",
            "code": "CONS_CARDIO",
            "libelle": "Consultation cardiologie",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "co222222-0002-4bbb-5b20-000000000002",
            "ref_categorie_id": "e1f2a3b4-0002-4e55-5e50-222222222226",
            "code": "CONS_DERMA",
            "libelle": "Consultation dermatologie",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "co222222-0003-4bbb-5b20-000000000003",
            "ref_categorie_id": "e1f2a3b4-0002-4e55-5e50-222222222226",
            "code": "CONS_GYNECO",
            "libelle": "Consultation gynécologie",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "co333333-0001-4ccc-5c30-000000000001",
            "ref_categorie_id": "e1f2a3b4-0003-4e55-5e50-333333333337",
            "code": "CONS_URGENCE",
            "libelle": "Consultation d'urgence",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "co444444-0001-4ddd-5d40-000000000001",
            "ref_categorie_id": "e1f2a3b4-0004-4e55-5e50-444444444448",
            "code": "CONS_TELECONSULT",
            "libelle": "Téléconsultation",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ma111111-0001-4aaa-4a10-000000000001",
            "ref_categorie_id": "f1a2b3c4-0001-4e66-4f60-111111111116",
            "code": "MAT_VOIE_BASSE",
            "libelle": "Accouchement par voie basse",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ma111111-0002-4aaa-4a10-000000000002",
            "ref_categorie_id": "f1a2b3c4-0001-4e66-4f60-111111111116",
            "code": "MAT_CESARIENNE",
            "libelle": "Accouchement par césarienne",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ma222222-0001-4bbb-4b20-000000000001",
            "ref_categorie_id": "f1a2b3c4-0002-4e66-4f60-222222222227",
            "code": "MAT_ECHO_T1",
            "libelle": "Échographie T1",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ma222222-0002-4bbb-4b20-000000000002",
            "ref_categorie_id": "f1a2b3c4-0002-4e66-4f60-222222222227",
            "code": "MAT_ECHO_T2",
            "libelle": "Échographie T2",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "ma222222-0003-4bbb-4b20-000000000003",
            "ref_categorie_id": "f1a2b3c4-0002-4e66-4f60-222222222227",
            "code": "MAT_ECHO_T3",
            "libelle": "Échographie T3",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "ma333333-0001-4ccc-4c30-000000000001",
            "ref_categorie_id": "f1a2b3c4-0003-4e66-4f60-333333333338",
            "code": "MAT_SUIVI_POSTPARTUM",
            "libelle": "Suivi post‑partum",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ma444444-0001-4ddd-4d40-000000000001",
            "ref_categorie_id": "f1a2b3c4-0004-4e66-4f60-444444444449",
            "code": "PMA_FIV_ICSI",
            "libelle": "PMA – FIV/ICSI",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "ma444444-0002-4ddd-4d40-000000000002",
            "ref_categorie_id": "f1a2b3c4-0004-4e66-4f60-444444444449",
            "code": "PMA_INSEMINATION",
            "libelle": "PMA – Insémination intra‑utérine",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "in111111-0001-4aaa-3a10-000000000001",
            "ref_categorie_id": "g1a2b3c4-0001-4e77-3a70-111111111117",
            "code": "INF_PANSEMENT_SIMPLE",
            "libelle": "Pansement simple",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "in111111-0002-4aaa-3a10-000000000002",
            "ref_categorie_id": "g1a2b3c4-0001-4e77-3a70-111111111117",
            "code": "INF_PANSEMENT_COMPLEXE",
            "libelle": "Pansement complexe",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "in222222-0001-4bbb-3b20-000000000001",
            "ref_categorie_id": "g1a2b3c4-0002-4e77-3a70-222222222228",
            "code": "INF_INJECTION_SC",
            "libelle": "Injection sous‑cutanée",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "in222222-0002-4bbb-3b20-000000000002",
            "ref_categorie_id": "g1a2b3c4-0002-4e77-3a70-222222222228",
            "code": "INF_INJECTION_IM",
            "libelle": "Injection intra‑musculaire",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "in333333-0001-4ccc-3c30-000000000001",
            "ref_categorie_id": "g1a2b3c4-0003-4e77-3a70-333333333339",
            "code": "INF_PERFUSION_DOM",
            "libelle": "Perfusion à domicile",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "au111111-0001-4aaa-2a10-000000000001",
            "ref_categorie_id": "h1a2b3c4-0001-4e88-2b80-111111111118",
            "code": "AUX_KINE_SEANCE",
            "libelle": "Séance de kinésithérapie",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "au222222-0001-4bbb-2b20-000000000001",
            "ref_categorie_id": "h1a2b3c4-0002-4e88-2b80-222222222229",
            "code": "AUX_ORTHOPHONIE_SEANCE",
            "libelle": "Séance d'orthophonie",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "au333333-0001-4ccc-2c30-000000000001",
            "ref_categorie_id": "h1a2b3c4-0003-4e88-2b80-333333333340",
            "code": "AUX_ORTHOPTIE_SEANCE",
            "libelle": "Séance d'orthoptie",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "au444444-0001-4ddd-2d40-000000000001",
            "ref_categorie_id": "h1a2b3c4-0004-4e88-2b80-444444444450",
            "code": "AUX_PODOLOGIE_SEANCE",
            "libelle": "Séance de podologie",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "au555555-0001-4eee-2e50-000000000001",
            "ref_categorie_id": "h1a2b3c4-0005-4e88-2b80-555555555560",
            "code": "AUX_ERGO_SEANCE",
            "libelle": "Séance d'ergothérapie",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "eq111111-0001-4aaa-1a10-000000000001",
            "ref_categorie_id": "i1a2b3c4-0001-4e99-1c90-111111111119",
            "code": "EQP_PROTHESE_AUDITIVE",
            "libelle": "Prothèse auditive",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "eq222222-0001-4bbb-1b20-000000000001",
            "ref_categorie_id": "i1a2b3c4-0002-4e99-1c90-222222222221",
            "code": "EQP_ORTHESE_GENOU",
            "libelle": "Orthèse de genou",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "eq333333-0001-4ccc-1c30-000000000001",
            "ref_categorie_id": "i1a2b3c4-0003-4e99-1c90-333333333331",
            "code": "EQP_CHAISE_ROULANTE",
            "libelle": "Chaise roulante",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "eq333333-0002-4ccc-1c30-000000000002",
            "ref_categorie_id": "i1a2b3c4-0003-4e99-1c90-333333333331",
            "code": "EQP_LIT_MEDICALISE",
            "libelle": "Lit médicalisé",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "eq444444-0001-4ddd-1d40-000000000001",
            "ref_categorie_id": "i1a2b3c4-0004-4e99-1c90-444444444441",
            "code": "EQP_STENT_CORONAIRE",
            "libelle": "Stent coronaire (DMI)",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "pr111111-0001-4aaa-0a10-000000000001",
            "ref_categorie_id": "j1a2b3c4-0001-4eaa-0da0-111111111120",
            "code": "PREV_BILAN_ANNUEL",
            "libelle": "Bilan de santé annuel",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "pr222222-0001-4bbb-0b20-000000000001",
            "ref_categorie_id": "j1a2b3c4-0002-4eaa-0da0-222222222222",
            "code": "PREV_DETARTRAGE",
            "libelle": "Détartrage préventif",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "pr222222-0002-4bbb-0b20-000000000002",
            "ref_categorie_id": "j1a2b3c4-0002-4eaa-0da0-222222222222",
            "code": "PREV_SCELLEMENT_SILLONS",
            "libelle": "Scellement des sillons",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "pr333333-0001-4ccc-0c30-000000000001",
            "ref_categorie_id": "j1a2b3c4-0003-4eaa-0da0-333333333332",
            "code": "PREV_SEVRAGE_TABAGIQUE",
            "libelle": "Programme de sevrage tabagique",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "pr444444-0001-4ddd-0d40-000000000001",
            "ref_categorie_id": "j1a2b3c4-0004-4eaa-0da0-444444444442",
            "code": "PREV_VACC_TETANOS",
            "libelle": "Vaccination tétanos",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "2dae3c92-01ec-4732-865f-34f2bef3384e",
            "ref_categorie_id": "eca403c7-fd69-4eb4-b19f-03d968171458",
            "code": "CONSULT_MED_DPTAM",
            "libelle": "Consultation ou visite d'un médecin adhérant à l'un des DPTAM",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "3f19fe24-0df2-426e-b5fb-55d5c5a9024a",
            "ref_categorie_id": "eca403c7-fd69-4eb4-b19f-03d968171458",
            "code": "CONSULT_MED_NON_DPTAM",
            "libelle": "Consultation ou visite d'un médecin non adhérant à l'un des DPTAM",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "1228fc77-206a-4d6f-bf1c-36fe37804acb",
            "ref_categorie_id": "eca403c7-fd69-4eb4-b19f-03d968171458",
            "code": "SEANCE_ACC_PSY",
            "libelle": "Séances d'accompagnement psychologique réalisées par un psychologue et prises en charge par la Sécurité sociale",
            "allow_surco": true,
            "ordre": 3
        },
        {
            "id": "6af6b854-818e-479a-98a4-5e8143fc6ebb",
            "ref_categorie_id": "eca403c7-fd69-4eb4-b19f-03d968171458",
            "code": "ACTES_TECHNIQUE_DPTAM",
            "libelle": "Actes techniques médicaux et actes de chirurgie pratiqués par un médecin adhérant à l'un des DPTAM",
            "allow_surco": true,
            "ordre": 4
        },
        {
            "id": "c6dcbe23-8ec3-4cbd-9ee0-1e9df335b69f",
            "ref_categorie_id": "eca403c7-fd69-4eb4-b19f-03d968171458",
            "code": "ACTES_TECHNIQUE_NON_DPTAM",
            "libelle": "Actes techniques médicaux et actes de chirurgie pratiqués par un médecin non adhérant à l'un des DPTAM",
            "allow_surco": true,
            "ordre": 5
        },
        {
            "id": "84108dba-fe1d-409c-a5c3-039b993957a5",
            "ref_categorie_id": "f4ea2e83-7705-41f8-ab3b-edd047c0917e",
            "code": "ACTES_IMAGERIE_DPTAM",
            "libelle": "Actes d’imagerie, échographie et doppler de médecins adhérents à l’un des DPTAM",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "1e5ec871-5ce3-491f-a6f3-3f8d48917ab1",
            "ref_categorie_id": "f4ea2e83-7705-41f8-ab3b-edd047c0917e",
            "code": "ACTES_IMAGERIE_NON_DPTAM",
            "libelle": "Actes d’imagerie, échographie et doppler de médecins non adhérents à l’un des DPTAM",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "26583b01-2d03-4532-a43e-3bd773e4cd69",
            "ref_categorie_id": "038d5c32-bf4d-4c26-ac2c-ed1c827ea2da",
            "code": "SS_PRIS_EN_CHARGE",
            "libelle": "Pris en charge par la sécurité sociale",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "f66d204a-48bb-43db-b008-b926b133652b",
            "ref_categorie_id": "cd081014-9ded-4952-a7eb-86ac13442858",
            "code": "ACTES_PRATIQUES_PAR_AUX_MEDICAUX",
            "libelle": "Actes pratiqués par les auxiliaires médicaux : les infirmiers, les masseurs kinésithérapeutes, les orthophonistes, les\n" + "orthoptistes et les pédicures-podologues",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "445c9a44-93d6-4f8f-b412-0d3ba0a38d02",
            "ref_categorie_id": "d536d258-c264-4644-9767-e185eb30149c",
            "code": "MEDICAMENTS_PRIS_EN_CHARGE_SS_65_30_15",
            "libelle": "Médicament pris en charge par la Sécurité sociale à 65%, 30% et 15%",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "128b1c8d-e6dd-4169-99a2-d4ebbbbeb20e",
            "ref_categorie_id": "d536d258-c264-4644-9767-e185eb30149c",
            "code": "VACCINS_NON_PRIS_EN_CHARGE",
            "libelle": "Vaccins non pris en charge par la Sécurité sociale et prescrits par un médecin dans les conditions prévues par leur\n" + "autorisation de mise sur le marché",
            "allow_surco": true,
            "ordre": 2
        },
        {
            "id": "128b1c8d-e6dd-4169-99a2-d4ebbbbeb20e",
            "ref_categorie_id": "dc5f600a-c704-4d01-94c5-e470882aff03",
            "code": "MEDICAMENTS_HOMEOPHATIQUES",
            "libelle": "Médicaments homéopathiques prescrits par un médecin (limite annuelle par bénéficiaire)",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "f42d9bab-3dfb-4f42-9ddb-548ef4162e7d",
            "ref_categorie_id": "4dbcb1cb-a041-4702-bd7d-92bf6ce9db08",
            "code": "FRAIS_TRANSPORT_SS",
            "libelle": "Frais de transport (remboursés par la Sécurité sociale)",
            "allow_surco": true,
            "ordre": 1
        },
        {
            "id": "86a5fb0d-e2c8-49f5-bfc7-5657d8a62004",
            "ref_categorie_id": "92fa1115-5b00-44bc-8748-2543ace54f36",
            "code": "APPAREILLAGE_PROTHESE_PRODUITS_PRESTATIONS",
            "libelle": "Appareillages, prothèses, produits et prestations, non pris en charge au titre des postes prothèses dentaires, auditives et\n" + "optiques",
            "allow_surco": true,
            "ordre": 1
        }
    ],
    offres_v1: [
        {
            "id": "94f62383-04b5-42d6-16cf-0d1e2f3a4b15",
            "code": "INTERPROF",
            libelle: "Interprofessionnelle"
        }
    ],
    catalogues_v1: [],
    groupe_actes_v1: [],
    groupe_actes_membre_v1: [],
    groupe_valeur_v1: []
};
}),
"[project]/src/providers/AppDataProvider.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AppDataProvider",
    ()=>AppDataProvider,
    "useCatModules",
    ()=>useCatModules,
    "useGroupActMembre",
    ()=>useGroupActMembre,
    "useGroupActes",
    ()=>useGroupActes,
    "useGroupValeur",
    ()=>useGroupValeur,
    "useGroupeUIState",
    ()=>useGroupeUIState,
    "useRefActs",
    ()=>useRefActs,
    "useRefCatalogues",
    ()=>useRefCatalogues,
    "useRefCategories",
    ()=>useRefCategories,
    "useRefModules",
    ()=>useRefModules,
    "useRefNiveau",
    ()=>useRefNiveau,
    "useRefNiveauSets",
    ()=>useRefNiveauSets,
    "useRefOffers",
    ()=>useRefOffers,
    "useUISettings",
    ()=>useUISettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/providers/MultiStorageProvider.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$settings$2f$default$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/settings/default.js [app-ssr] (ecmascript)");
'use client';
;
;
;
// util: pick léger
const pick = (obj, keys)=>keys.reduce((acc, k)=>k in obj ? (acc[k] = obj[k], acc) : acc, {});
// on découpe defaultSettings en 3 blocs : settings UI, ref_modules_v1, offres
function sourcesFromDefault(ds) {
    const UI_KEYS = [
        'version',
        'theme',
        'locale',
        'density',
        'apiBaseUrl',
        'showBeta'
    ];
    const ui = pick(ds, UI_KEYS);
    return {
        settings: {
            default: ui,
            version: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$settings$2f$default$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SETTINGS_VERSION"]
        },
        ref_niveau_sets_v1: {
            default: ds.ref_niveau_sets_v1 ?? []
        },
        ref_niveaux_v1: {
            default: ds.ref_niveaux_v1 ?? []
        },
        ref_modules_v1: {
            default: ds.ref_modules_v1 ?? []
        },
        ref_categories_v1: {
            default: ds.ref_categories_v1 ?? []
        },
        ref_acts_v1: {
            default: ds.ref_acts_v1 ?? []
        },
        offres_v1: {
            default: ds.offres_v1 ?? []
        },
        catalogues_v1: {
            default: ds.catalogues_v1 ?? []
        },
        groupe_actes_membre_v1: {
            default: ds.groupe_actes_membre_v1 ?? []
        },
        groupe_valeur_v1: {
            default: ds.groupe_valeur_v1 ?? []
        },
        groupe_actes_v1: {
            default: ds.groupe_actes_v1 ?? []
        },
        cat_modules_v1: {
            default: ds.cat_modules_v1 ?? []
        },
        groupe_ui_state_v1: {
            default: ds.groupe_ui_state_v1 ?? {}
        }
    };
}
function AppDataProvider({ children }) {
    const devOverwrite = process.env.NEXT_PUBLIC_DEV_OVERWRITE === '1';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MultiStorageProvider"], {
        namespace: "app:",
        overwriteOnLoad: devOverwrite,
        clearNamespaceBeforeOverwrite: devOverwrite,
        sources: sourcesFromDefault(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$settings$2f$default$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultSettings"]),
        children: children
    }, void 0, false, {
        fileName: "[project]/src/providers/AppDataProvider.jsx",
        lineNumber: 35,
        columnNumber: 9
    }, this);
}
function useUISettings() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        settings: data.settings,
        setSettings: (v)=>set('settings', v),
        patchSettings: (p)=>patch('settings', p),
        resetSettings: ()=>resetKey('settings')
    };
}
function useRefModules() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refModules: data.ref_modules_v1,
        setRefModules: (v)=>set('ref_modules_v1', v),
        patchRefModules: (p)=>patch('ref_modules_v1', p),
        resetRefModules: ()=>resetKey('ref_modules_v1')
    };
}
function useRefCategories() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refCategories: data.ref_categories_v1,
        setRefCategories: (v)=>set('ref_categories_v1', v),
        patchRefCategories: (p)=>patch('ref_categories_v1', p),
        resetRefCategories: ()=>resetKey('ref_categories_v1')
    };
}
function useRefActs() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refActs: data.ref_acts_v1,
        setRefActs: (v)=>set('ref_acts_v1', v),
        patchRefActs: (p)=>patch('ref_acts_v1', p),
        resetRefActs: ()=>resetKey('ref_acts_v1')
    };
}
function useRefOffers() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refOffers: data.offres_v1,
        setRefOffers: (v)=>set('offres_v1', v),
        patchRefOffers: (p)=>patch('offres_v1', p),
        resetRefOffers: ()=>resetKey('offres_v1')
    };
}
function useRefCatalogues() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refCatalogues: data.catalogues_v1,
        setRefCatalogues: (v)=>set('catalogues_v1', v),
        patchRefCatalogues: (p)=>patch('catalogues_v1', p),
        resetRefCatalogues: ()=>resetKey('catalogues_v1')
    };
}
function useRefNiveau() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refNiveau: data.ref_niveaux_v1,
        setRefNiveau: (v)=>set('ref_niveaux_v1', v),
        patchRefNiveau: (p)=>patch('ref_niveaux_v1', p),
        resetRefNiveau: ()=>resetKey('ref_niveaux_v1')
    };
}
function useRefNiveauSets() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refNiveauSets: data.ref_niveau_sets_v1 || [],
        setRefNiveauSets: (v)=>set('ref_niveau_sets_v1', v),
        patchRefNiveauSets: (p)=>patch('ref_niveau_sets_v1', p),
        resetRefNiveauSets: ()=>resetKey('ref_niveau_sets_v1')
    };
}
function useGroupActMembre() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refGroupActMembre: data.groupe_actes_membre_v1,
        setRefGroupActMembre: (v)=>set('groupe_actes_membre_v1', v),
        patchRefGroupActMembre: (p)=>patch('groupe_actes_membre_v1', p),
        resetRefGroupActMembre: ()=>resetKey('groupe_actes_membre_v1')
    };
}
function useGroupValeur() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refGroupValeur: data.groupe_valeur_v1,
        setRefGroupValeur: (v)=>set('groupe_valeur_v1', v),
        patchRefGroupValeur: (p)=>patch('groupe_valeur_v1', p),
        resetRefGroupValeur: ()=>resetKey('groupe_valeur_v1')
    };
}
function useGroupActes() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        refGroupActes: data.groupe_actes_v1,
        setRefGroupActes: (v)=>set('groupe_actes_v1', v),
        patchRefGroupActes: (p)=>patch('groupe_actes_v1', p),
        resetRefGroupActes: ()=>resetKey('groupe_actes_v1')
    };
}
function useCatModules() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    const value = Array.isArray(data.cat_modules_v1) ? data.cat_modules_v1 : [];
    return {
        catModules: value,
        setCatModules: (next)=>{
            const resolved = typeof next === 'function' ? next(value) : next;
            // garde-fou : on évite d’écrire autre chose qu’un tableau
            set('cat_modules_v1', Array.isArray(resolved) ? resolved : []);
        },
        patchCatModules: (p)=>patch('cat_modules_v1', p),
        resetCatModules: ()=>resetKey('cat_modules_v1')
    };
}
function useGroupeUIState() {
    const { data, set, patch, resetKey } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$MultiStorageProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMultiStorage"])();
    return {
        uiState: data.groupe_ui_state_v1 || {},
        setUIState: (v)=>set('groupe_ui_state_v1', v),
        patchUIState: (p)=>patch('groupe_ui_state_v1', p),
        resetGroupeUIState: ()=>resetKey('groupe_ui_state_v1')
    };
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__087ac67d._.js.map