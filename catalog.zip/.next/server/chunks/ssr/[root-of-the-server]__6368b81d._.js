module.exports = [
"[project]/.next-internal/server/app/catalogues/[catalogueId]/configure/inline/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/src/app/loading.jsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/loading.jsx [app-rsc] (ecmascript)"));
}),
"[project]/src/app/catalogues/[catalogueId]/configure/inline/page.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// ⛔️ surtout PAS 'use client' ici
__turbopack_context__.s([
    "default",
    ()=>Page,
    "generateStaticParams",
    ()=>generateStaticParams
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-rsc] (ecmascript)");
;
;
;
// On charge le composant client sans SSR
const ClientInlinePage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx [app-rsc] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
async function generateStaticParams() {
    // On ne pré-génère aucun catalogue spécifique (mode SPA)
    return [];
// Si un jour tu as une seed au build:
// const seed = (await import('@/data/catalogues.seed.json')).default || []
// return seed.map(c => ({ catalogueId: c.id }))
}
function Page({ params }) {
    // On passe l’ID *vu dans l’URL* comme secours (utile si le provider charge après)
    const initialCatalogueId = params?.catalogueId || '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ClientInlinePage, {
        initialCatalogueId: initialCatalogueId
    }, void 0, false, {
        fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/page.jsx",
        lineNumber: 19,
        columnNumber: 12
    }, this);
}
}),
"[project]/src/app/catalogues/[catalogueId]/configure/inline/page.jsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/catalogues/[catalogueId]/configure/inline/page.jsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__6368b81d._.js.map