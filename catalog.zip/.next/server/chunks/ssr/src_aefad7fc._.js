module.exports = [
"[project]/src/hooks/useGroupData.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sanitizeGroupes",
    ()=>sanitizeGroupes,
    "sanitizeGvaleurs",
    ()=>sanitizeGvaleurs,
    "sanitizeMembres",
    ()=>sanitizeMembres,
    "useGroupStore",
    ()=>useGroupStore,
    "uuid",
    ()=>uuid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
function uuid() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
    return 'id-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}
const safeLS = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : null;
const lsGet = (k, fallback = [])=>{
    if ("TURBOPACK compile-time truthy", 1) return fallback;
    //TURBOPACK unreachable
    ;
};
const lsSet = (k, v)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
};
function sanitizeGroupes(arr, catalogueMap, moduleMap) {
    if (!Array.isArray(arr)) return [];
    const out = [];
    for (const raw of arr){
        if (!raw) continue;
        const g = {
            id: raw.id || uuid(),
            catalogue_id: raw.catalogue_id,
            ref_module_id: raw.ref_module_id,
            nom: String(raw.nom || '').trim(),
            priorite: Number.isFinite(Number(raw.priorite)) ? Number(raw.priorite) : 100,
            cat_order: Array.isArray(raw.cat_order) ? raw.cat_order : raw.cat_order ?? [],
            // 🔑 NOUVEAU : ordre (peut être null → fallback tri)
            ordre: Number.isFinite(Number(raw.ordre)) ? Number(raw.ordre) : null
        };
        if (!g.catalogue_id || !catalogueMap?.has(g.catalogue_id)) continue;
        if (!g.ref_module_id || !moduleMap?.has(g.ref_module_id)) continue;
        if (!g.nom) continue;
        out.push(g);
    }
    // tri “doux” : ordre d'abord s'il existe, sinon priorite puis nom
    return out.sort((a, b)=>(a.ordre ?? 1e9) - (b.ordre ?? 1e9) || (a.priorite ?? 0) - (b.priorite ?? 0) || a.nom.localeCompare(b.nom));
}
function sanitizeMembres(arr) {
    if (!Array.isArray(arr)) return [];
    const byGroup = new Map();
    for (const raw of arr || []){
        if (!raw || !raw.groupe_id || !raw.act_id) continue;
        const gid = raw.groupe_id;
        if (!byGroup.has(gid)) byGroup.set(gid, []);
        byGroup.get(gid).push({
            groupe_id: gid,
            act_id: raw.act_id,
            ordre: Number.isFinite(Number(raw.ordre)) ? Number(raw.ordre) : Infinity
        });
    }
    const out = [];
    for (const [gid, list] of byGroup){
        list.sort((a, b)=>(a.ordre || 1e9) - (b.ordre || 1e9));
        list.forEach((m, i)=>out.push({
                ...m,
                ordre: i + 1
            }));
    }
    return out;
}
function sanitizeGvaleurs(arr) {
    if (!Array.isArray(arr)) return [];
    const out = [];
    const seen = new Set();
    for (const raw of arr || []){
        if (!raw) continue;
        const kind = String(raw.kind || 'base').toLowerCase() === 'surco' ? 'surco' : 'base';
        const v = {
            id: raw.id || uuid(),
            groupe_id: raw.groupe_id,
            act_id: raw.act_id,
            niveau_id: raw.niveau_id,
            kind,
            mode: raw.mode || 'texte_libre',
            base: raw.base || 'inconnu',
            taux: isFinite(Number(raw.taux)) ? Number(raw.taux) : null,
            montant: isFinite(Number(raw.montant)) ? Number(raw.montant) : null,
            unite: raw.unite || 'inconnu',
            plafond_montant: isFinite(Number(raw.plafond_montant)) ? Number(raw.plafond_montant) : null,
            plafond_unite: raw.plafond_unite || null,
            periodicite: raw.periodicite || null,
            condition_json: raw.condition_json ?? null,
            expression: raw.expression || '',
            commentaire: raw.commentaire || ''
        };
        if (!v.groupe_id || !v.act_id || !v.niveau_id) continue;
        const k = `${v.groupe_id}::${v.act_id}::${v.niveau_id}::${v.kind}`;
        if (seen.has(k)) continue;
        seen.add(k);
        out.push(v);
    }
    return out;
}
function useGroupStore(refs, options = {}) {
    const { catalogueMap, moduleMap } = refs || {};
    const { ns = 'global' } = options;
    const keyG = `grp:${ns}:groupes`;
    const keyM = `grp:${ns}:membres`;
    const keyV = `grp:${ns}:gvaleurs`;
    const [rawG, setRawG] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [rawM, setRawM] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [rawV, setRawV] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const bootedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    // hydrate au mount (LS ou vide)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setRawG(lsGet(keyG, []));
        setRawM(lsGet(keyM, []));
        setRawV(lsGet(keyV, []));
        bootedRef.current = true;
    }, [
        keyG,
        keyM,
        keyV
    ]);
    // valeurs dérivées
    const groupes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>sanitizeGroupes(rawG, catalogueMap, moduleMap), [
        rawG,
        catalogueMap,
        moduleMap
    ]);
    const membres = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>sanitizeMembres(rawM), [
        rawM
    ]);
    const gvaleurs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>sanitizeGvaleurs(rawV), [
        rawV
    ]);
    // setters (jamais pendant le render)
    const setGroupes = (next)=>setRawG((prev)=>{
            const value = typeof next === 'function' ? next(prev) : next;
            const clean = sanitizeGroupes(value, catalogueMap, moduleMap);
            if (bootedRef.current) lsSet(keyG, clean);
            return clean;
        });
    const setMembres = (next)=>setRawM((prev)=>{
            const value = typeof next === 'function' ? next(prev) : next;
            const clean = sanitizeMembres(value);
            if (bootedRef.current) lsSet(keyM, clean);
            return clean;
        });
    const setGvaleurs = (next)=>setRawV((prev)=>{
            const value = typeof next === 'function' ? next(prev) : next;
            const clean = sanitizeGvaleurs(value);
            if (bootedRef.current) lsSet(keyV, clean);
            return clean;
        });
    // helpers
    const membersByGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const by = new Map();
        for (const m of membres){
            if (!by.has(m.groupe_id)) by.set(m.groupe_id, new Set());
            by.get(m.groupe_id).add(m.act_id);
        }
        return by;
    }, [
        membres
    ]);
    const memberOrderByGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const by = new Map();
        for (const m of membres){
            if (!by.has(m.groupe_id)) by.set(m.groupe_id, new Map());
            by.get(m.groupe_id).set(m.act_id, m.ordre || 1e9);
        }
        return by;
    }, [
        membres
    ]);
    return {
        groupes,
        setGroupes,
        membres,
        setMembres,
        gvaleurs,
        setGvaleurs,
        membersByGroup,
        memberOrderByGroup
    };
}
}),
"[project]/src/components/catalogues/CatalogueHeader.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CatalogueHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
'use client';
;
function CatalogueHeader({ offer, catalogue, onBack, onSwitchMode }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-wrap items-center justify-between gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-2xl font-bold",
                        children: [
                            offer?.code,
                            " — ",
                            offer?.libelle
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalogues/CatalogueHeader.jsx",
                        lineNumber: 6,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "opacity-70",
                        children: [
                            "Catalogue : ",
                            [
                                catalogue?.risque,
                                catalogue?.annee,
                                catalogue?.version
                            ].filter(Boolean).join(' · ')
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalogues/CatalogueHeader.jsx",
                        lineNumber: 9,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/catalogues/CatalogueHeader.jsx",
                lineNumber: 5,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "join",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "btn join-item",
                        onClick: onSwitchMode,
                        children: "↔ Mode modal"
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalogues/CatalogueHeader.jsx",
                        lineNumber: 14,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "btn join-item",
                        onClick: onBack,
                        children: "← Retour liste"
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalogues/CatalogueHeader.jsx",
                        lineNumber: 15,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/catalogues/CatalogueHeader.jsx",
                lineNumber: 13,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalogues/CatalogueHeader.jsx",
        lineNumber: 4,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/catalogues/ModulesSelector.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModulesSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
'use client';
;
function ModulesSelector({ modules, selectedSet, groupsCountByModule, onToggle, onSelectAll, onClearAll }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "card bg-base-100 shadow-sm",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "card-body p-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-semibold",
                            children: "Modules inclus dans ce catalogue"
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                            lineNumber: 14,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "join",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "btn btn-sm join-item",
                                    onClick: onSelectAll,
                                    children: "Tout inclure"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                                    lineNumber: 16,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "btn btn-sm join-item",
                                    onClick: onClearAll,
                                    children: "Tout retirer"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                                    lineNumber: 17,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                            lineNumber: 15,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                    lineNumber: 13,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-2 flex flex-wrap gap-2",
                    children: modules.map((m)=>{
                        const on = selectedSet.has(m.id);
                        const hasGroups = (groupsCountByModule.get(m.id) || 0) > 0;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: `btn btn-sm ${on ? 'btn-primary' : 'btn-outline'}`,
                            onClick: ()=>onToggle(m.id),
                            title: hasGroups ? 'Des groupes existent pour ce module' : '',
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-mono",
                                    children: m.libelle
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                                    lineNumber: 33,
                                    columnNumber: 33
                                }, this),
                                hasGroups ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "badge badge-xs ml-2",
                                    children: "grp"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                                    lineNumber: 34,
                                    columnNumber: 46
                                }, this) : null
                            ]
                        }, m.id, true, {
                            fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                            lineNumber: 26,
                            columnNumber: 29
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
                    lineNumber: 21,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
            lineNumber: 12,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/catalogues/ModulesSelector.jsx",
        lineNumber: 11,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/catalogues/ModuleOrderList.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModuleOrderList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
'use client';
;
function ModuleOrderList({ includedRows, moduleMap, groupsCountByModule, onMove }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "font-semibold mb-2",
                children: "Ordre d’affichage (onglets)"
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                lineNumber: 10,
                columnNumber: 13
            }, this),
            includedRows.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "alert alert-info",
                children: "Sélectionne des modules ci-dessus pour les réordonner."
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                lineNumber: 13,
                columnNumber: 17
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: includedRows.map((row, idx)=>{
                    const mod = moduleMap.get(row.ref_module_id);
                    const isFirst = idx === 0;
                    const isLast = idx === includedRows.length - 1;
                    const groups = groupsCountByModule.get(row.ref_module_id) || 0;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3 border border-base-300 rounded-box p-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "join",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: "btn btn-xs join-item",
                                        disabled: isFirst,
                                        onClick: ()=>onMove(row.ref_module_id, 'up'),
                                        title: "Monter",
                                        children: "▲"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                                        lineNumber: 25,
                                        columnNumber: 37
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "btn btn-xs btn-ghost join-item w-10 justify-center",
                                        children: row.ordre
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                                        lineNumber: 34,
                                        columnNumber: 37
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: "btn btn-xs join-item",
                                        disabled: isLast,
                                        onClick: ()=>onMove(row.ref_module_id, 'down'),
                                        title: "Descendre",
                                        children: "▼"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                                        lineNumber: 35,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                                lineNumber: 24,
                                columnNumber: 33
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "truncate opacity-70",
                                children: mod?.libelle || '—'
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                                lineNumber: 47,
                                columnNumber: 33
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ml-auto flex items-center gap-2",
                                children: groups > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "badge",
                                    children: [
                                        groups,
                                        " grp"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                                    lineNumber: 50,
                                    columnNumber: 52
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                                lineNumber: 49,
                                columnNumber: 33
                            }, this)
                        ]
                    }, row.id, true, {
                        fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                        lineNumber: 23,
                        columnNumber: 29
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                lineNumber: 15,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "opacity-60 text-xs mt-2",
                children: "L’ordre ci-dessus détermine l’ordre des onglets de configuration."
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
                lineNumber: 58,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalogues/ModuleOrderList.jsx",
        lineNumber: 9,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/catalogues/ModuleTabs.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModuleTabs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
function ModuleTabs({ modules, activeId, onChange, renderPanel }) {
    const tabsId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useId"])();
    const name = `mod_tabs_${tabsId}`;
    if (!modules || modules.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "alert alert-info",
            children: "Sélectionne au moins un module pour commencer à créer des groupes."
        }, void 0, false, {
            fileName: "[project]/src/components/catalogues/ModuleTabs.jsx",
            lineNumber: 9,
            columnNumber: 16
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "tablist",
        className: "tabs tabs-lift mt-2",
        children: modules.map((m, i)=>{
            const checked = activeId ? activeId === m.id : i === 0;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "radio",
                        role: "tab",
                        name: name,
                        "aria-label": m.code,
                        className: "tab",
                        checked: checked,
                        onChange: ()=>onChange(m.id)
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalogues/ModuleTabs.jsx",
                        lineNumber: 18,
                        columnNumber: 25
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        role: "tabpanel",
                        className: "tab-content bg-base-100 border-base-300 p-4",
                        children: renderPanel(m)
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalogues/ModuleTabs.jsx",
                        lineNumber: 27,
                        columnNumber: 25
                    }, this)
                ]
            }, m.id, true, {
                fileName: "[project]/src/components/catalogues/ModuleTabs.jsx",
                lineNumber: 17,
                columnNumber: 21
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/src/components/catalogues/ModuleTabs.jsx",
        lineNumber: 13,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/common/ToastInline.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ToastInline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
'use client';
;
function ToastInline({ toast }) {
    if (!toast) return null;
    const kind = toast.type === 'success' ? 'alert-success' : toast.type === 'error' ? 'alert-error' : 'alert-info';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "toast",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `alert ${kind}`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: toast.msg
            }, void 0, false, {
                fileName: "[project]/src/components/common/ToastInline.jsx",
                lineNumber: 12,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/common/ToastInline.jsx",
            lineNumber: 11,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/common/ToastInline.jsx",
        lineNumber: 10,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/catalogues/inline/InlineGroupEditor.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InlineGroupEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
function InlineGroupEditor({ module, catalogueId, categoriesByModule, actsByCategory, initial, onSave, onCancel, disabledActIds }) {
    const [groupe, setGroupe] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>initial?.groupe || {
            id: null,
            catalogue_id: catalogueId,
            ref_module_id: module.id,
            nom: '',
            priorite: 100
        });
    const disabledSet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Set(disabledActIds || []), [
        disabledActIds
    ]);
    const [selectedActs, setSelectedActs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>initial?.membersArr || []);
    // Sécurité : si disabledSet change, on retire d'éventuelles ids devenues indisponibles
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setSelectedActs((prev)=>prev.filter((id)=>!disabledSet.has(id)));
    }, [
        disabledSet
    ]);
    // Catégories du module triées
    const catsRefSorted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(categoriesByModule.get(module.id) || []).slice().sort((a, b)=>(a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code)), [
        categoriesByModule,
        module.id
    ]);
    const selectedSet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Set(selectedActs), [
        selectedActs
    ]);
    function toggleAct(actId) {
        // Par principe, ignore si tenté sur un acte masqué (ne devrait pas arriver)
        if (disabledSet.has(actId)) return;
        setSelectedActs((prev)=>prev.includes(actId) ? prev.filter((id)=>id !== actId) : [
                ...prev,
                actId
            ]);
    }
    function toggleCategory(actsInCat, add) {
        // actsInCat est déjà filtré (on lui passe la liste visible)
        const ids = actsInCat.map((a)=>a.id);
        setSelectedActs((prev)=>{
            if (add) {
                const set = new Set(prev);
                return [
                    ...prev,
                    ...ids.filter((id)=>!set.has(id))
                ];
            }
            return prev.filter((id)=>!ids.includes(id));
        });
    }
    function submit() {
        const nom = String(groupe.nom || '').trim();
        if (!nom) return alert('Nom requis');
        if (selectedActs.length === 0) return alert('Sélectionnez au moins un acte disponible');
        onSave({
            groupe,
            selectedActs
        });
    }
    // Nombre d'actes disponibles (toutes catégories confondues)
    const availableActsCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return catsRefSorted.reduce((n, cat)=>{
            const allActs = actsByCategory.get(cat.id) || [];
            const visible = allActs.filter((a)=>!disabledSet.has(a.id));
            return n + visible.length;
        }, 0);
    }, [
        catsRefSorted,
        actsByCategory,
        disabledSet
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border border-base-300 rounded-box p-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "floating-label",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        "Nom du groupe ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-error",
                                            children: "*"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                            lineNumber: 88,
                                            columnNumber: 45
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                    lineNumber: 88,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    className: "input input-bordered w-full",
                                    value: groupe.nom,
                                    onChange: (e)=>setGroupe((g)=>({
                                                ...g,
                                                nom: e.target.value
                                            })),
                                    placeholder: "Ex: Soins courants – Base"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                    lineNumber: 89,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                            lineNumber: 87,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-end gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "btn btn-primary",
                                    onClick: submit,
                                    children: "Enregistrer"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                    lineNumber: 108,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "btn",
                                    onClick: onCancel,
                                    children: "Annuler"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                    lineNumber: 109,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                            lineNumber: 107,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                    lineNumber: 86,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                lineNumber: 85,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "card bg-base-200",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "card-body p-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "font-semibold mb-2",
                            children: "Sélection des actes"
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                            lineNumber: 117,
                            columnNumber: 21
                        }, this),
                        availableActsCount === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "alert alert-warning my-2",
                            children: "Tous les actes de ce module sont déjà utilisés dans ce catalogue."
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                            lineNumber: 119,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2 max-h-[50vh] overflow-auto pr-1",
                            children: catsRefSorted.map((cat)=>{
                                const allActs = actsByCategory.get(cat.id) || [];
                                // ⛔️ Solution A : on MASQUE ceux déjà utilisés
                                const acts = allActs.filter((a)=>!disabledSet.has(a.id));
                                if (acts.length === 0) return null;
                                const total = acts.length;
                                const selectedCnt = acts.reduce((n, a)=>n + (selectedSet.has(a.id) ? 1 : 0), 0);
                                const allInCat = selectedCnt === total && total > 0;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border border-base-300 rounded-box",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between p-2 bg-base-300",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "opacity-70",
                                                            children: cat.libelle || '—'
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                            lineNumber: 140,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "badge badge-sm",
                                                            children: [
                                                                selectedCnt,
                                                                "/",
                                                                total
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                            lineNumber: 141,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                    lineNumber: 138,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "join",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: "btn btn-xs join-item",
                                                        onClick: ()=>toggleCategory(acts, !allInCat),
                                                        disabled: total === 0,
                                                        title: total === 0 ? 'Aucun acte disponible dans cette catégorie' : '',
                                                        children: allInCat ? 'Tout retirer' : 'Tout ajouter'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                        lineNumber: 144,
                                                        columnNumber: 45
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                    lineNumber: 143,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                            lineNumber: 137,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-2",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
                                                children: acts.map((a)=>{
                                                    const checked = selectedSet.has(a.id);
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: `flex items-center gap-2 p-2 rounded-box border ${checked ? 'border-primary' : 'border-base-300'}`,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "checkbox",
                                                                className: "checkbox checkbox-sm",
                                                                checked: checked,
                                                                onChange: ()=>toggleAct(a.id)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                                lineNumber: 164,
                                                                columnNumber: 57
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "min-w-0",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "text-xs opacity-70 truncate",
                                                                    children: a.libelle || '—'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                                    lineNumber: 172,
                                                                    columnNumber: 61
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                                lineNumber: 170,
                                                                columnNumber: 57
                                                            }, this)
                                                        ]
                                                    }, a.id, true, {
                                                        fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                        lineNumber: 160,
                                                        columnNumber: 53
                                                    }, this);
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                                lineNumber: 156,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                            lineNumber: 155,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, cat.id, true, {
                                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                                    lineNumber: 136,
                                    columnNumber: 33
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                            lineNumber: 123,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                    lineNumber: 116,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
                lineNumber: 115,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalogues/inline/InlineGroupEditor.jsx",
        lineNumber: 83,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReadonlyGroupMatrix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
function CellView({ v }) {
    const hasV = (v?.value || '').trim().length > 0;
    const hasE = (v?.expression || '').trim().length > 0;
    if (!hasV && !hasE) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "opacity-40",
        children: "—"
    }, void 0, false, {
        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
        lineNumber: 8,
        columnNumber: 32
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-8",
        children: [
            hasV && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "font-mono text-sm break-words",
                children: v.value
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                lineNumber: 11,
                columnNumber: 22
            }, this),
            hasE && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs opacity-70 break-words",
                title: v.expression,
                children: v.expression
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                lineNumber: 12,
                columnNumber: 22
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
        lineNumber: 10,
        columnNumber: 9
    }, this);
}
function ReadonlyGroupMatrix({ editable = false, group, module, niveaux, categoriesByModule, actsByCategory, membres, gvaleurs, onSave, onCancel }) {
    // ===== base data
    const catsBase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(categoriesByModule.get(module.id) || []).slice().sort((a, b)=>(a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code)), [
        categoriesByModule,
        module.id
    ]);
    const membresRows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(membres || []).filter((m)=>m.groupe_id === group.id).sort((a, b)=>(a.ordre || 1e9) - (b.ordre || 1e9)), [
        membres,
        group.id
    ]);
    const valMapInitial = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const m = new Map();
        for (const v of gvaleurs || []){
            if (v.groupe_id !== group.id) continue;
            m.set(`${v.act_id}::${v.niveau_id}::${v.kind}`, {
                value: v?.commentaire || '',
                expression: v?.expression || ''
            });
        }
        return m;
    }, [
        gvaleurs,
        group.id
    ]);
    const toValObj = (actId, nivId, kind)=>valMapInitial.get(`${actId}::${nivId}::${kind}`) || {
            value: '',
            expression: ''
        };
    // ===== local UI state
    const initialCatOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const stored = Array.isArray(group?.cat_order) ? group.cat_order : [];
        if (stored.length === 0) return catsBase.map((c)=>c.id);
        const byId = new Set(catsBase.map((c)=>c.id));
        return stored.filter((id)=>byId.has(id)).concat(catsBase.filter((c)=>!stored.includes(c.id)).map((c)=>c.id));
    }, [
        catsBase,
        group?.cat_order
    ]);
    const [catOrder, setCatOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialCatOrder);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>setCatOrder(initialCatOrder), [
        initialCatOrder
    ]);
    const [actOrder, setActOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>membresRows.map((m)=>m.act_id));
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>setActOrder(membresRows.map((m)=>m.act_id)), [
        membresRows
    ]);
    const [valuesByAct, setValuesByAct] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        const out = {};
        for (const m of membresRows){
            const aId = m.act_id;
            out[aId] = out[aId] || {};
            for (const n of niveaux || []){
                const base = toValObj(aId, n.id, 'base');
                const surc = toValObj(aId, n.id, 'surco');
                if (base.value || base.expression || surc.value || surc.expression) {
                    out[aId][n.id] = {
                        baseVal: base,
                        surcoVal: surc
                    };
                }
            }
        }
        return out;
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const next = {};
        for (const m of membresRows){
            const aId = m.act_id;
            next[aId] = next[aId] || {};
            for (const n of niveaux || []){
                const base = toValObj(aId, n.id, 'base');
                const surc = toValObj(aId, n.id, 'surco');
                if (base.value || base.expression || surc.value || surc.expression) {
                    next[aId][n.id] = {
                        baseVal: base,
                        surcoVal: surc
                    };
                }
            }
        }
        setValuesByAct(next);
    }, [
        valMapInitial,
        membresRows,
        niveaux
    ]);
    const membersSet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Set(membresRows.map((m)=>m.act_id)), [
        membresRows
    ]);
    // ===== actions (si editable)
    function findActCategory(actId) {
        for (const c of catsBase){
            const acts = actsByCategory.get(c.id) || [];
            if (acts.some((a)=>a.id === actId)) return c.id;
        }
        return null;
    }
    function visibleActsInCat(catId, order) {
        const acts = (actsByCategory.get(catId) || []).filter((a)=>membersSet.has(a.id));
        return acts.slice().sort((a, b)=>{
            const oa = order.indexOf(a.id);
            const ob = order.indexOf(b.id);
            if (oa !== ob) return oa - ob;
            const ra = a.ordre || 0, rb = b.ordre || 0;
            return ra - rb || a.code.localeCompare(b.code);
        }).map((a)=>a.id);
    }
    function moveCategory(catId, dir) {
        if (!editable) return;
        setCatOrder((prev)=>{
            const idx = prev.indexOf(catId);
            const tgt = dir === 'up' ? idx - 1 : idx + 1;
            if (idx < 0 || tgt < 0 || tgt >= prev.length) return prev;
            const arr = prev.slice();
            [arr[idx], arr[tgt]] = [
                arr[tgt],
                arr[idx]
            ];
            return arr;
        });
    }
    function moveAct(actId, dir) {
        if (!editable) return;
        setActOrder((prev)=>{
            const idx = prev.indexOf(actId);
            if (idx < 0) return prev;
            const catId = findActCategory(actId);
            if (!catId) return prev;
            const actsInCat = visibleActsInCat(catId, prev);
            const posInCat = actsInCat.indexOf(actId);
            const tgtInCat = dir === 'up' ? posInCat - 1 : posInCat + 1;
            if (posInCat < 0 || tgtInCat < 0 || tgtInCat >= actsInCat.length) return prev;
            const a = prev.indexOf(actsInCat[posInCat]);
            const b = prev.indexOf(actsInCat[tgtInCat]);
            const arr = prev.slice();
            [arr[a], arr[b]] = [
                arr[b],
                arr[a]
            ];
            return arr;
        });
    }
    // edition cellule
    const [editing, setEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null); // { actId, nivId, kind, value, expression }
    function startEdit(actId, nivId, kind) {
        if (!editable) return;
        const pair = valuesByAct?.[actId]?.[nivId] || {
            baseVal: {},
            surcoVal: {}
        };
        const cur = (kind === 'base' ? pair.baseVal : pair.surcoVal) || {};
        setEditing({
            actId,
            nivId,
            kind,
            value: cur.value || '',
            expression: cur.expression || ''
        });
    }
    function saveEdit() {
        if (!editing) return;
        const { actId, nivId, kind, value, expression } = editing;
        setValuesByAct((prev)=>{
            const next = {
                ...prev || {}
            };
            next[actId] = next[actId] || {};
            next[actId][nivId] = next[actId][nivId] || {
                baseVal: {},
                surcoVal: {}
            };
            const key = kind === 'base' ? 'baseVal' : 'surcoVal';
            next[actId][nivId][key] = {
                value,
                expression
            };
            return next;
        });
        setEditing(null);
    }
    function cancelEdit() {
        setEditing(null);
    }
    function onCellKeyDown(e) {
        if (e.key === 'Escape') {
            e.preventDefault();
            cancelEdit();
        }
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            saveEdit();
        }
    }
    // ===== submit
    function submitAll() {
        if (!editable) return;
        const catOrderSelected = catOrder.slice();
        const displayActIds = [];
        for (const catId of catOrderSelected){
            const ids = visibleActsInCat(catId, actOrder);
            displayActIds.push(...ids);
        }
        const orderByAct = {};
        displayActIds.forEach((id, i)=>orderByAct[id] = i + 1);
        onSave?.({
            catOrderSelected,
            orderByAct,
            valuesByAct
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: "table",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            rowSpan: 2,
                                            className: "align-bottom",
                                            style: {
                                                minWidth: 260
                                            },
                                            children: "Garantie"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                            lineNumber: 216,
                                            columnNumber: 25
                                        }, this),
                                        niveaux.map((n)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                colSpan: 2,
                                                className: "text-center",
                                                children: n.libelle
                                            }, n.id, false, {
                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                lineNumber: 218,
                                                columnNumber: 29
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                    lineNumber: 215,
                                    columnNumber: 21
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: niveaux.map((n)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    className: "text-center",
                                                    children: "Base"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                    lineNumber: 224,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    className: "text-center",
                                                    children: "Surco"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                    lineNumber: 225,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, `sub-${n.id}`, true, {
                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                            lineNumber: 223,
                                            columnNumber: 29
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                    lineNumber: 221,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                            lineNumber: 214,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: [
                                catOrder.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        colSpan: 1 + niveaux.length * 2,
                                        className: "text-center opacity-60",
                                        children: "—"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                        lineNumber: 233,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                    lineNumber: 233,
                                    columnNumber: 25
                                }, this),
                                catOrder.map((id)=>catsBase.find((c)=>c.id === id)).filter(Boolean).map((cat)=>{
                                    const actsRaw = actsByCategory.get(cat.id) || [];
                                    const acts = actsRaw.filter((a)=>membersSet.has(a.id)).sort((a, b)=>{
                                        const oa = actOrder.indexOf(a.id);
                                        const ob = actOrder.indexOf(b.id);
                                        if (oa !== ob) return oa - ob;
                                        const ra = a.ordre || 0, rb = b.ordre || 0;
                                        return ra - rb || a.code.localeCompare(b.code);
                                    });
                                    if (acts.length === 0) return null;
                                    const isFirst = catOrder[0] === cat.id;
                                    const isLast = catOrder[catOrder.length - 1] === cat.id;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "bg-base-200",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    colSpan: 1 + niveaux.length * 2,
                                                    className: "text-left",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "opacity-70",
                                                                children: cat.libelle || '—'
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                lineNumber: 259,
                                                                columnNumber: 45
                                                            }, this),
                                                            editable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "ml-auto join",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        className: "btn btn-xs join-item",
                                                                        disabled: isFirst,
                                                                        onClick: ()=>moveCategory(cat.id, 'up'),
                                                                        title: "Monter la catégorie",
                                                                        "aria-label": "Monter la catégorie",
                                                                        children: "▲"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                        lineNumber: 262,
                                                                        columnNumber: 53
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        className: "btn btn-xs join-item",
                                                                        disabled: isLast,
                                                                        onClick: ()=>moveCategory(cat.id, 'down'),
                                                                        title: "Descendre la catégorie",
                                                                        "aria-label": "Descendre la catégorie",
                                                                        children: "▼"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                        lineNumber: 268,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                lineNumber: 261,
                                                                columnNumber: 49
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                        lineNumber: 257,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                    lineNumber: 256,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                lineNumber: 255,
                                                columnNumber: 33
                                            }, this),
                                            acts.map((a)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "table-pin-cols",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2 w-full",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex-1 min-w-0",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "opacity-70 truncate",
                                                                            children: a.libelle || '—'
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                            lineNumber: 286,
                                                                            columnNumber: 53
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                        lineNumber: 284,
                                                                        columnNumber: 49
                                                                    }, this),
                                                                    editable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "join",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                className: "btn btn-xs join-item",
                                                                                onClick: ()=>moveAct(a.id, 'up'),
                                                                                children: "▲"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                lineNumber: 290,
                                                                                columnNumber: 57
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                className: "btn btn-xs join-item",
                                                                                onClick: ()=>moveAct(a.id, 'down'),
                                                                                children: "▼"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                lineNumber: 291,
                                                                                columnNumber: 57
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                        lineNumber: 289,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                lineNumber: 283,
                                                                columnNumber: 45
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                            lineNumber: 282,
                                                            columnNumber: 41
                                                        }, this),
                                                        niveaux.map((n)=>{
                                                            const pair = valuesByAct?.[a.id]?.[n.id] || {
                                                                baseVal: {},
                                                                surcoVal: {}
                                                            };
                                                            const isEditingBase = !!editing && editing.actId === a.id && editing.nivId === n.id && editing.kind === 'base';
                                                            const isEditingSurc = !!editing && editing.actId === a.id && editing.nivId === n.id && editing.kind === 'surco';
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        onDoubleClick: ()=>startEdit(a.id, n.id, 'base'),
                                                                        title: editable ? 'Double-clique pour éditer' : '',
                                                                        children: editable && isEditingBase ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "space-y-2",
                                                                            onKeyDown: onCellKeyDown,
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    className: "input input-sm input-bordered w-full font-mono",
                                                                                    placeholder: "value",
                                                                                    autoFocus: true,
                                                                                    value: editing.value,
                                                                                    onChange: (e)=>setEditing((s)=>({
                                                                                                ...s,
                                                                                                value: e.target.value
                                                                                            }))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                    lineNumber: 311,
                                                                                    columnNumber: 65
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    className: "input input-sm input-bordered w-full",
                                                                                    placeholder: "expression",
                                                                                    value: editing.expression,
                                                                                    onChange: (e)=>setEditing((s)=>({
                                                                                                ...s,
                                                                                                expression: e.target.value
                                                                                            }))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                    lineNumber: 318,
                                                                                    columnNumber: 65
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "join",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-xs btn-primary join-item",
                                                                                            onClick: saveEdit,
                                                                                            children: "Enregistrer"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                            lineNumber: 325,
                                                                                            columnNumber: 69
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-xs join-item",
                                                                                            onClick: cancelEdit,
                                                                                            children: "Annuler"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                            lineNumber: 326,
                                                                                            columnNumber: 69
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                    lineNumber: 324,
                                                                                    columnNumber: 65
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                            lineNumber: 310,
                                                                            columnNumber: 61
                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CellView, {
                                                                            v: pair.baseVal
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                            lineNumber: 330,
                                                                            columnNumber: 61
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                        lineNumber: 305,
                                                                        columnNumber: 53
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                        onDoubleClick: ()=>startEdit(a.id, n.id, 'surco'),
                                                                        title: editable ? 'Double-clique pour éditer' : '',
                                                                        children: editable && isEditingSurc ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "space-y-2",
                                                                            onKeyDown: onCellKeyDown,
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    className: "input input-sm input-bordered w-full font-mono",
                                                                                    placeholder: "value",
                                                                                    autoFocus: true,
                                                                                    value: editing.value,
                                                                                    onChange: (e)=>setEditing((s)=>({
                                                                                                ...s,
                                                                                                value: e.target.value
                                                                                            }))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                    lineNumber: 341,
                                                                                    columnNumber: 65
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    className: "input input-sm input-bordered w-full",
                                                                                    placeholder: "expression",
                                                                                    value: editing.expression,
                                                                                    onChange: (e)=>setEditing((s)=>({
                                                                                                ...s,
                                                                                                expression: e.target.value
                                                                                            }))
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                    lineNumber: 348,
                                                                                    columnNumber: 65
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "join",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-xs btn-primary join-item",
                                                                                            onClick: saveEdit,
                                                                                            children: "Enregistrer"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                            lineNumber: 355,
                                                                                            columnNumber: 69
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-xs join-item",
                                                                                            onClick: cancelEdit,
                                                                                            children: "Annuler"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                            lineNumber: 356,
                                                                                            columnNumber: 69
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                                    lineNumber: 354,
                                                                                    columnNumber: 65
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                            lineNumber: 340,
                                                                            columnNumber: 61
                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CellView, {
                                                                            v: pair.surcoVal
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                            lineNumber: 360,
                                                                            columnNumber: 61
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                        lineNumber: 335,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, `${a.id}-${n.id}`, true, {
                                                                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                                lineNumber: 303,
                                                                columnNumber: 49
                                                            }, this);
                                                        })
                                                    ]
                                                }, a.id, true, {
                                                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                                    lineNumber: 281,
                                                    columnNumber: 37
                                                }, this))
                                        ]
                                    }, cat.id, true, {
                                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                                        lineNumber: 254,
                                        columnNumber: 29
                                    }, this);
                                })
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                            lineNumber: 231,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                    lineNumber: 213,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                lineNumber: 212,
                columnNumber: 13
            }, this),
            editable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-end gap-2",
                children: [
                    onCancel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: "btn",
                        onClick: onCancel,
                        children: "Fermer"
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                        lineNumber: 377,
                        columnNumber: 34
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: "btn btn-primary",
                        onClick: submitAll,
                        children: "Enregistrer la grille"
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                        lineNumber: 378,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
                lineNumber: 376,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx",
        lineNumber: 204,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/lib/utils/CatalogueInline.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// utils/catalogueInline.js
__turbopack_context__.s([
    "buildMembersSet",
    ()=>buildMembersSet,
    "normalizeCell",
    ()=>normalizeCell,
    "prefillFromStores",
    ()=>prefillFromStores
]);
function buildMembersSet(group, membres) {
    const set = new Set();
    for (const m of membres)if (m.groupe_id === group.id) set.add(m.act_id);
    return set;
}
function prefillFromStores(g, membres, gvaleurs, niveaux) {
    const membersRows = (membres || []).filter((m)=>m.groupe_id === g.id).sort((a, b)=>(a.ordre || 1e9) - (b.ordre || 1e9));
    const membersArr = membersRows.map((m)=>m.act_id);
    const toMini = (v)=>({
            value: v?.commentaire ?? '',
            expression: v?.expression ?? ''
        });
    const valuesByAct = {};
    for (const actId of membersArr){
        valuesByAct[actId] = {};
        for (const n of niveaux || []){
            const base = (gvaleurs || []).find((v)=>v.groupe_id === g.id && v.act_id === actId && v.niveau_id === n.id && v.kind === 'base');
            const surc = (gvaleurs || []).find((v)=>v.groupe_id === g.id && v.act_id === actId && v.niveau_id === n.id && v.kind === 'surco');
            if (base || surc) {
                valuesByAct[actId][n.id] = {
                    baseVal: toMini(base),
                    surcoVal: toMini(surc)
                };
            }
        }
    }
    return {
        groupe: {
            ...g
        },
        membersArr,
        valuesByAct
    };
}
function normalizeCell(gid, actId, nivId, kind, mini) {
    const rid = typeof crypto !== 'undefined' && crypto?.randomUUID ? crypto.randomUUID() : 'id-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    return {
        id: rid,
        groupe_id: gid,
        act_id: actId,
        niveau_id: nivId,
        kind,
        // normalisation générique (tu pourras spécialiser plus tard)
        mode: 'texte_libre',
        base: 'inconnu',
        taux: null,
        montant: null,
        unite: 'inconnu',
        plafond_montant: null,
        plafond_unite: null,
        periodicite: null,
        condition_json: null,
        expression: mini?.expression || '',
        commentaire: mini?.value || ''
    };
}
}),
"[project]/src/components/catalogues/ModulePanelContainer.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ModulePanelContainer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useGroupData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useGroupData.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$inline$2f$InlineGroupEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalogues/inline/InlineGroupEditor.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$inline$2f$ReadonlyGroupMatrix$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalogues/inline/ReadonlyGroupMatrix.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$CatalogueInline$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils/CatalogueInline.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/providers/AppDataProvider.jsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function ModulePanelContainer({ module, catalogueId, refNiveau, refNiveauSets, selectedNiveauSetId, onChangeNiveauSet, categoriesByModule, actsByCategory, actMap, showToast, refs }) {
    const { groupes, setGroupes, membres, setMembres, gvaleurs, setGvaleurs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useGroupData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGroupStore"])(refs, {
        ns: catalogueId
    });
    const { uiState, patchUIState } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGroupeUIState"])();
    // Filtrer les niveaux du set sélectionné
    const niveauxEnabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const all = (refNiveau || []).filter((n)=>!!n.is_enabled);
        // Si le set est choisi, on filtre strictement dessus
        const bySet = selectedNiveauSetId ? all.filter((n)=>n.ref_set_id === selectedNiveauSetId) : all;
        // Fallback : si le set ne retourne rien, on garde "all" pour ne pas casser l’UI
        const list = bySet.length > 0 ? bySet : all;
        return list.slice().sort((a, b)=>(a.ordre || 0) - (b.ordre || 0));
    }, [
        refNiveau,
        selectedNiveauSetId
    ]);
    // changement de set: choix UI purge (optionnelle) des valeurs existantes du module
    function handleChangeSet(setId) {
        if (setId === selectedNiveauSetId) return;
        const targetLevelIds = new Set((refNiveau || []).filter((n)=>!!n.is_enabled && n.ref_set_id === setId).map((n)=>n.id));
        if (setId && targetLevelIds.size === 0) {
            showToast('error', "Ce set ne contient aucun niveau actif — aucun changement appliqué.");
            return;
        }
        // ❌ plus de purge ici : on garde toutes les valeurs en LS
        onChangeNiveauSet?.(setId);
        showToast('success', 'Catégorie de niveaux appliquée au module');
    }
    // 🔎 Tri avec ordre → priorite → nom (au cas où un groupe n’a pas encore d’ordre)
    const myGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(groupes || []).filter((g)=>g.catalogue_id === catalogueId && g.ref_module_id === module.id).sort((a, b)=>(a.ordre ?? 1e9) - (b.ordre ?? 1e9) || (a.priorite ?? 0) - (b.priorite ?? 0) || a.nom.localeCompare(b.nom)), [
        groupes,
        catalogueId,
        module.id
    ]);
    const catGroupIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Set((groupes || []).filter((g)=>g.catalogue_id === catalogueId).map((g)=>g.id)), [
        groupes,
        catalogueId
    ]);
    // ✅ Tous les act_id déjà utilisés par n'importe quel groupe de ce catalogue
    const usedActIdsInCatalogue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const s = new Set();
        for (const m of membres || []){
            if (catGroupIds.has(m.groupe_id)) s.add(m.act_id);
        }
        return s;
    }, [
        membres,
        catGroupIds
    ]);
    // 👉 si certains groupes n’ont pas d’ordre, on les indexe 1..n (effet, pas pendant le render)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (myGroups.length === 0) return;
        const missing = myGroups.some((g)=>!Number.isFinite(Number(g.ordre)));
        if (!missing) return;
        setGroupes((prev)=>{
            // recalcul uniquement pour ce module
            const mine = (prev || []).filter((g)=>g.catalogue_id === catalogueId && g.ref_module_id === module.id).sort((a, b)=>(a.ordre ?? 1e9) - (b.ordre ?? 1e9) || (a.priorite ?? 0) - (b.priorite ?? 0) || a.nom.localeCompare(b.nom));
            const withOrder = new Map(mine.map((g, i)=>[
                    g.id,
                    i + 1
                ]));
            return (prev || []).map((g)=>g.catalogue_id === catalogueId && g.ref_module_id === module.id ? {
                    ...g,
                    ordre: withOrder.get(g.id)
                } : g);
        });
    }, [
        myGroups.length,
        catalogueId,
        module.id,
        setGroupes
    ]); // dépendances OK
    const [createOpen, setCreateOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [actPickerFor, setActPickerFor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    function setLocked(gid, locked) {
        const curr = uiState[gid] || {};
        patchUIState({
            [gid]: {
                ...curr,
                locked: !!locked
            }
        });
    }
    // ===== helpers ordre
    function nextOrderForModule(list = myGroups) {
        const max = list.reduce((acc, g)=>Math.max(acc, Number.isFinite(Number(g.ordre)) ? g.ordre : 0), 0);
        return max + 1;
    }
    function reindexOrders1toN(prev) {
        const mine = (prev || []).filter((g)=>g.catalogue_id === catalogueId && g.ref_module_id === module.id).sort((a, b)=>(a.ordre ?? 1e9) - (b.ordre ?? 1e9) || (a.priorite ?? 0) - (b.priorite ?? 0) || a.nom.localeCompare(b.nom));
        const index = new Map(mine.map((g, i)=>[
                g.id,
                i + 1
            ]));
        return (prev || []).map((g)=>g.catalogue_id === catalogueId && g.ref_module_id === module.id ? {
                ...g,
                ordre: index.get(g.id)
            } : g);
    }
    function moveGroup(gid, dir) {
        setGroupes((prev)=>{
            const mine = (prev || []).filter((g)=>g.catalogue_id === catalogueId && g.ref_module_id === module.id).sort((a, b)=>(a.ordre ?? 1e9) - (b.ordre ?? 1e9) || a.nom.localeCompare(b.nom));
            const idx = mine.findIndex((g)=>g.id === gid);
            const tgt = dir === 'up' ? idx - 1 : idx + 1;
            if (idx < 0 || tgt < 0 || tgt >= mine.length) return prev;
            const A = mine[idx];
            const B = mine[tgt];
            return reindexOrders1toN((prev || []).map((g)=>{
                if (g.id === A.id) return {
                    ...g,
                    ordre: B.ordre
                };
                if (g.id === B.id) return {
                    ...g,
                    ordre: A.ordre
                };
                return g;
            }));
        });
    }
    // === création
    function createGroup({ groupe, selectedActs }) {
        const gid = groupe.id || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useGroupData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["uuid"])();
        const payload = {
            id: gid,
            catalogue_id: catalogueId,
            ref_module_id: module.id,
            nom: String(groupe.nom || '').trim(),
            priorite: Number(groupe.priorite) || 100,
            // 🔑 ordre : fin de liste du module
            ordre: nextOrderForModule(),
            cat_order: (categoriesByModule.get(module.id) || []).slice().sort((a, b)=>(a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code)).map((c)=>c.id)
        };
        setGroupes([
            ...groupes || [],
            payload
        ]);
        const actsRefSorted = selectedActs.map((id)=>actMap.get(id)).filter(Boolean).sort((a, b)=>(a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code)).map((a)=>a.id);
        const nextMembers = actsRefSorted.map((actId, i)=>({
                groupe_id: gid,
                act_id: actId,
                ordre: i + 1
            }));
        setMembres([
            ...membres || [],
            ...nextMembers
        ]);
        setLocked(gid, false);
        showToast('success', 'Groupe créé — configure la grille');
        setCreateOpen(false);
    }
    // === maj actes
    function updateActsForGroup(gid, { groupe, selectedActs }) {
        setGroupes((prev)=>prev.map((g)=>g.id === gid ? {
                    ...g,
                    nom: String(groupe.nom || '').trim(),
                    priorite: Number(groupe.priorite) || 100
                } : g));
        const current = (membres || []).filter((m)=>m.groupe_id === gid).map((m)=>m.act_id);
        const keep = selectedActs.filter((id)=>current.includes(id));
        const add = selectedActs.filter((id)=>!current.includes(id));
        const removed = current.filter((id)=>!selectedActs.includes(id));
        setGvaleurs((prev)=>prev.filter((v)=>v.groupe_id !== gid || !removed.includes(v.act_id)));
        const currentRows = (membres || []).filter((m)=>m.groupe_id === gid).sort((a, b)=>(a.ordre || 1e9) - (b.ordre || 1e9));
        const keepSorted = currentRows.filter((r)=>keep.includes(r.act_id)).map((r)=>r.act_id);
        const addSorted = add.map((id)=>actMap.get(id)).filter(Boolean).sort((a, b)=>(a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code)).map((a)=>a.id);
        const finalOrder = [
            ...keepSorted,
            ...addSorted
        ];
        const others = (membres || []).filter((m)=>m.groupe_id !== gid);
        const nextMembers = finalOrder.map((actId, i)=>({
                groupe_id: gid,
                act_id: actId,
                ordre: i + 1
            }));
        setMembres([
            ...others,
            ...nextMembers
        ]);
        showToast('success', 'Actes du groupe mis à jour');
        setActPickerFor(null);
    }
    // === sauvegarde grille
    function saveGrid(g, { catOrderSelected, orderByAct, valuesByAct }) {
        // 1) cat_order
        setGroupes((prev)=>prev.map((x)=>x.id === g.id ? {
                    ...x,
                    cat_order: Array.isArray(catOrderSelected) && catOrderSelected.length > 0 ? catOrderSelected : x.cat_order || []
                } : x));
        // 2) membres (réordonner)
        setMembres((prev)=>{
            const others = prev.filter((m)=>m.groupe_id !== g.id);
            const mine = prev.filter((m)=>m.groupe_id === g.id).sort((a, b)=>(a.ordre || 1e9) - (b.ordre || 1e9));
            if (mine.length === 0) return prev;
            const byId = new Map(mine.map((m)=>[
                    m.act_id,
                    m
                ]));
            const covered = new Set();
            const orderedFromPayload = Object.keys(orderByAct || {}).filter((actId)=>byId.has(actId)).sort((a, b)=>(orderByAct[a] ?? 1e9) - (orderByAct[b] ?? 1e9));
            orderedFromPayload.forEach((id)=>covered.add(id));
            const leftovers = mine.filter((m)=>!covered.has(m.act_id)).sort((a, b)=>(a.ordre || 1e9) - (b.ordre || 1e9)).map((m)=>m.act_id);
            const finalOrder = [
                ...orderedFromPayload,
                ...leftovers
            ];
            const reordered = finalOrder.map((actId, i)=>{
                const row = byId.get(actId);
                return {
                    ...row,
                    ordre: i + 1
                };
            });
            return [
                ...others,
                ...reordered
            ];
        });
        // 3) valeurs
        if (valuesByAct && Object.keys(valuesByAct).length > 0) {
            setGvaleurs((prev)=>{
                const rest = prev.filter((v)=>v.groupe_id !== g.id);
                const rows = [];
                for (const [actId, perLevel] of Object.entries(valuesByAct || {})){
                    for (const [nivId, pair] of Object.entries(perLevel || {})){
                        const baseVal = pair?.baseVal || {};
                        const surcoVal = pair?.surcoVal || {};
                        const hasBase = baseVal.value?.trim()?.length || baseVal.expression?.trim()?.length;
                        const hasSurc = surcoVal.value?.trim()?.length || surcoVal.expression?.trim()?.length;
                        if (hasBase) rows.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$CatalogueInline$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["normalizeCell"])(g.id, actId, nivId, 'base', baseVal));
                        if (hasSurc) rows.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$CatalogueInline$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["normalizeCell"])(g.id, actId, nivId, 'surco', surcoVal));
                    }
                }
                return [
                    ...rest,
                    ...rows
                ];
            });
        }
        setLocked(g.id, true);
        showToast('success', 'Grille enregistrée');
        if (actPickerFor === g.id) setActPickerFor(null);
    }
    function requestDelete(g) {
        if (!confirm('Supprimer ce groupe ?')) return;
        setGroupes((prev)=>{
            const kept = (prev || []).filter((x)=>x.id !== g.id);
            return reindexOrders1toN(kept);
        });
        setMembres((membres || []).filter((m)=>m.groupe_id !== g.id));
        setGvaleurs((gvaleurs || []).filter((v)=>v.groupe_id !== g.id));
        if (actPickerFor === g.id) setActPickerFor(null);
        showToast('success', 'Groupe supprimé');
    }
    // ===== UI
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold",
                        children: [
                            "Module : ",
                            module?.libelle
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                        lineNumber: 324,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "form-control min-w-[220px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "label py-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "label-text text-xs opacity-70",
                                    children: "Catégorie de niveaux"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                    lineNumber: 330,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                lineNumber: 329,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                className: "select select-bordered select-sm",
                                value: selectedNiveauSetId || '',
                                onChange: (e)=>handleChangeSet(e.target.value || null),
                                children: (refNiveauSets || []).filter((s)=>s.is_enabled !== false).sort((a, b)=>(a.ordre ?? 0) - (b.ordre ?? 0) || a.code.localeCompare(b.code)).map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: s.id,
                                        children: [
                                            s.code,
                                            " — ",
                                            s.libelle
                                        ]
                                    }, s.id, true, {
                                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                        lineNumber: 341,
                                        columnNumber: 33
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                lineNumber: 332,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                        lineNumber: 328,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "join",
                        children: [
                            !createOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "btn btn-primary join-item",
                                onClick: ()=>setCreateOpen(true),
                                children: "+ Nouveau groupe"
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                lineNumber: 349,
                                columnNumber: 25
                            }, this),
                            createOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "btn btn-ghost join-item",
                                onClick: ()=>setCreateOpen(false),
                                children: "Annuler"
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                lineNumber: 354,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                        lineNumber: 347,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                lineNumber: 323,
                columnNumber: 13
            }, this),
            myGroups.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "card bg-base-100 shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "card-body p-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "font-semibold mb-2",
                            children: "Ordre des groupes (dans ce module)"
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                            lineNumber: 365,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2",
                            children: myGroups.map((g, idx)=>{
                                const isFirst = idx === 0;
                                const isLast = idx === myGroups.length - 1;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3 border border-base-300 rounded-box p-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "join",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: "btn btn-xs join-item",
                                                    disabled: isFirst,
                                                    onClick: ()=>moveGroup(g.id, 'up'),
                                                    title: "Monter",
                                                    "aria-label": "Monter",
                                                    children: "▲"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                                    lineNumber: 374,
                                                    columnNumber: 45
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "btn btn-xs btn-ghost join-item w-10 justify-center",
                                                    children: g.ordre ?? idx + 1
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                                    lineNumber: 384,
                                                    columnNumber: 45
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: "btn btn-xs join-item",
                                                    disabled: isLast,
                                                    onClick: ()=>moveGroup(g.id, 'down'),
                                                    title: "Descendre",
                                                    "aria-label": "Descendre",
                                                    children: "▼"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                                    lineNumber: 387,
                                                    columnNumber: 45
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                            lineNumber: 373,
                                            columnNumber: 41
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "badge badge-outline",
                                            children: g.nom
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                            lineNumber: 398,
                                            columnNumber: 41
                                        }, this)
                                    ]
                                }, g.id, true, {
                                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                    lineNumber: 371,
                                    columnNumber: 37
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                            lineNumber: 366,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "opacity-60 text-xs mt-2",
                            children: "L’ordre ci-dessus détermine l’affichage des cartes de groupe pour ce module."
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                            lineNumber: 404,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                    lineNumber: 364,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                lineNumber: 363,
                columnNumber: 17
            }, this),
            createOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$inline$2f$InlineGroupEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                module: module,
                catalogueId: catalogueId,
                categoriesByModule: categoriesByModule,
                actsByCategory: actsByCategory,
                onSave: createGroup,
                onCancel: ()=>setCreateOpen(false),
                disabledActIds: usedActIdsInCatalogue
            }, "creator", false, {
                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                lineNumber: 413,
                columnNumber: 17
            }, this),
            myGroups.length === 0 && !createOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "alert alert-info",
                children: "Aucun groupe pour ce module. Clique sur « Nouveau groupe »."
            }, void 0, false, {
                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                lineNumber: 427,
                columnNumber: 17
            }, this),
            myGroups.map((g)=>{
                const pref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2f$CatalogueInline$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["prefillFromStores"])(g, membres, gvaleurs, niveauxEnabled);
                const locked = !!uiState[g.id]?.locked;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "card bg-base-100 shadow-md relative group",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "card-body p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3 mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-lg font-semibold",
                                        children: [
                                            "Groupe : ",
                                            g.nom
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                        lineNumber: 438,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "ml-auto join",
                                        children: [
                                            !locked && actPickerFor === g.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "btn btn-sm join-item",
                                                onClick: ()=>setActPickerFor(null),
                                                children: "Fermer actes"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                                lineNumber: 442,
                                                columnNumber: 41
                                            }, this),
                                            locked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "btn btn-sm btn-info join-item opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity",
                                                "aria-label": "Modifier la grille",
                                                onClick: ()=>setLocked(g.id, false),
                                                children: "✎ Edition"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                                lineNumber: 448,
                                                columnNumber: 41
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: "btn btn-sm join-item",
                                                        onClick: ()=>setActPickerFor(g.id),
                                                        children: "Choisir actes"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                                        lineNumber: 457,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: "btn btn-sm btn-error join-item",
                                                        onClick: ()=>requestDelete(g),
                                                        children: "Supprimer"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                                        lineNumber: 461,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, void 0, true)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                        lineNumber: 440,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                lineNumber: 437,
                                columnNumber: 29
                            }, this),
                            !locked && actPickerFor === g.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$inline$2f$InlineGroupEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    module: module,
                                    catalogueId: catalogueId,
                                    categoriesByModule: categoriesByModule,
                                    actsByCategory: actsByCategory,
                                    initial: pref,
                                    onSave: (payload)=>updateActsForGroup(g.id, payload),
                                    onCancel: ()=>setActPickerFor(null)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                    lineNumber: 473,
                                    columnNumber: 37
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                lineNumber: 472,
                                columnNumber: 33
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$inline$2f$ReadonlyGroupMatrix$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                editable: !locked,
                                group: g,
                                module: module,
                                niveaux: niveauxEnabled,
                                categoriesByModule: categoriesByModule,
                                actsByCategory: actsByCategory,
                                membres: membres,
                                gvaleurs: gvaleurs,
                                onSave: (payload)=>saveGrid(g, payload),
                                onCancel: ()=>setLocked(g.id, true)
                            }, void 0, false, {
                                fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                                lineNumber: 486,
                                columnNumber: 29
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                        lineNumber: 436,
                        columnNumber: 25
                    }, this)
                }, g.id, false, {
                    fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
                    lineNumber: 435,
                    columnNumber: 21
                }, this);
            })
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalogues/ModulePanelContainer.jsx",
        lineNumber: 321,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ClientInlinePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/providers/AppDataProvider.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useGroupData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useGroupData.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$CatalogueHeader$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalogues/CatalogueHeader.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModulesSelector$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalogues/ModulesSelector.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModuleOrderList$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalogues/ModuleOrderList.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModuleTabs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalogues/ModuleTabs.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$ToastInline$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/ToastInline.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModulePanelContainer$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalogues/ModulePanelContainer.jsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
function ClientInlinePage({ initialCatalogueId = '' }) {
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>setMounted(true), []);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    // ⚠️ on reste en statique: l’ID vient de la querystring, avec fallback depuis le wrapper server
    const catalogueId = String(searchParams.get('catalogueId') || initialCatalogueId || '');
    // Référentiels
    const { refOffers } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRefOffers"])();
    const { refCatalogues } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRefCatalogues"])();
    const { refModules } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRefModules"])();
    const { refCategories } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRefCategories"])();
    const { refActs } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRefActs"])();
    const { refNiveau } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRefNiveau"])();
    const { refNiveauSets } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRefNiveauSets"])();
    const { catModules, setCatModules } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$providers$2f$AppDataProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCatModules"])();
    // petit helper: premier set activé
    const firstEnabledSet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(refNiveauSets || []).filter((s)=>s.is_enabled !== false).sort((a, b)=>(a.ordre ?? 0) - (b.ordre ?? 0))[0] || null, [
        refNiveauSets
    ]);
    function getSetIdForModule(modId) {
        const row = (catModules || []).find((cm)=>cm.catalogue_id === catalogueId && cm.ref_module_id === modId);
        return row?.niveau_set_id || firstEnabledSet?.id || null;
    }
    function setSetIdForModule(modId, setId) {
        setCatModules((prev)=>prev.map((cm)=>cm.catalogue_id === catalogueId && cm.ref_module_id === modId ? {
                    ...cm,
                    niveau_set_id: setId
                } : cm));
    }
    // Maps
    const offerMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Map(refOffers.map((o)=>[
                o.id,
                o
            ])), [
        refOffers
    ]);
    const catalogueMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Map(refCatalogues.map((c)=>[
                c.id,
                c
            ])), [
        refCatalogues
    ]);
    const moduleMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Map(refModules.map((m)=>[
                m.id,
                m
            ])), [
        refModules
    ]);
    const headerCat = catalogueMap.get(catalogueId);
    const offerId = headerCat?.offre_id || '';
    const headerOffer = offerMap.get(offerId);
    // redirections/erreurs simples
    if (!catalogueId) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6 max-w-3xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "alert alert-warning",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Aucun ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-mono",
                                children: "catalogueId"
                            }, void 0, false, {
                                fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                                lineNumber: 74,
                                columnNumber: 33
                            }, this),
                            " fourni dans l’URL."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                        lineNumber: 74,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                    lineNumber: 73,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "btn",
                        onClick: ()=>router.push('/catalogues'),
                        children: "← Retour à la liste"
                    }, void 0, false, {
                        fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                        lineNumber: 77,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                    lineNumber: 76,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
            lineNumber: 72,
            columnNumber: 13
        }, this);
    }
    if (!headerCat) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6 max-w-3xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "alert alert-error",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Catalogue introuvable pour l’ID ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-mono",
                                children: catalogueId
                            }, void 0, false, {
                                fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                                lineNumber: 86,
                                columnNumber: 59
                            }, this),
                            "."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                        lineNumber: 86,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                    lineNumber: 85,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "btn",
                        onClick: ()=>router.push('/catalogues'),
                        children: "← Retour à la liste"
                    }, void 0, false, {
                        fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                        lineNumber: 89,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                    lineNumber: 88,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
            lineNumber: 84,
            columnNumber: 13
        }, this);
    }
    // Catégories/Actes indexés (tri référentiel)
    const categoriesByModule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const by = new Map();
        for (const c of refCategories){
            if (!by.has(c.ref_module_id)) by.set(c.ref_module_id, []);
            by.get(c.ref_module_id).push(c);
        }
        for (const [, arr] of by)arr.sort((a, b)=>(a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code));
        return by;
    }, [
        refCategories
    ]);
    const actsByCategory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const by = new Map();
        for (const a of refActs){
            if (!by.has(a.ref_categorie_id)) by.set(a.ref_categorie_id, []);
            by.get(a.ref_categorie_id).push(a);
        }
        for (const [, arr] of by)arr.sort((a, b)=>(a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code));
        return by;
    }, [
        refActs
    ]);
    const actMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Map(refActs.map((a)=>[
                a.id,
                a
            ])), [
        refActs
    ]);
    // Stores groupements : objet stable pour éviter la réinit
    const storeRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            catalogueMap,
            moduleMap
        }), [
        catalogueMap,
        moduleMap
    ]);
    const { groupes } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useGroupData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGroupStore"])(storeRefs);
    // Modules inclus
    const includedRows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (!catalogueId) return [];
        return (catModules || []).filter((cm)=>cm.catalogue_id === catalogueId).sort((a, b)=>(a.ordre ?? 0) - (b.ordre ?? 0) || (moduleMap.get(a.ref_module_id)?.code || '').localeCompare(moduleMap.get(b.ref_module_id)?.code || ''));
    }, [
        catModules,
        catalogueId,
        moduleMap
    ]);
    const selectedModuleIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new Set(includedRows.map((r)=>r.ref_module_id)), [
        includedRows
    ]);
    const includedModules = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>includedRows.map((r)=>moduleMap.get(r.ref_module_id)).filter(Boolean), [
        includedRows,
        moduleMap
    ]);
    const groupsCountByModule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const map = new Map();
        for (const g of groupes){
            if (g.catalogue_id !== catalogueId) continue;
            map.set(g.ref_module_id, 1 + (map.get(g.ref_module_id) || 0));
        }
        return map;
    }, [
        groupes,
        catalogueId
    ]);
    // Tab actif
    const [activeModuleId, setActiveModuleId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!catalogueId) return;
        if (includedModules.length === 0) {
            setActiveModuleId('');
            return;
        }
        if (!includedModules.find((m)=>m.id === activeModuleId)) {
            setActiveModuleId(includedModules[0].id);
        }
    }, [
        catalogueId,
        includedModules,
        activeModuleId
    ]);
    // Toast
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    function showToast(type, msg) {
        setToast({
            type,
            msg
        });
        setTimeout(()=>setToast(null), 2200);
    }
    // Helpers catModules
    function reindexCatModules(nextAll) {
        const [kept, rows] = nextAll.reduce((acc, cm)=>{
            if (cm.catalogue_id === catalogueId) acc[1].push(cm);
            else acc[0].push(cm);
            return acc;
        }, [
            [],
            []
        ]);
        const reindexed = rows.slice().sort((a, b)=>(a.ordre ?? 0) - (b.ordre ?? 0)).map((r, i)=>({
                ...r,
                ordre: i + 1
            }));
        return [
            ...kept,
            ...reindexed
        ];
    }
    function moveModule(modId, dir) {
        if (!catalogueId) return;
        const idx = includedRows.findIndex((r)=>r.ref_module_id === modId);
        const target = dir === 'up' ? idx - 1 : idx + 1;
        if (idx < 0 || target < 0 || target >= includedRows.length) return;
        const a = includedRows[idx], b = includedRows[target];
        setCatModules((prev)=>reindexCatModules(prev.map((cm)=>{
                if (cm.id === a.id) return {
                    ...cm,
                    ordre: b.ordre
                };
                if (cm.id === b.id) return {
                    ...cm,
                    ordre: a.ordre
                };
                return cm;
            })));
    }
    function nextOrdreForCatalogue() {
        return includedRows.length + 1;
    }
    function toggleModule(modId) {
        if (!catalogueId) return;
        const isSelected = selectedModuleIds.has(modId);
        if (isSelected) {
            const cnt = groupsCountByModule.get(modId) || 0;
            if (cnt > 0 && !confirm(`Des groupes (${cnt}) existent sur ce module. Le masquer ?`)) return;
            const next = (catModules || []).filter((cm)=>!(cm.catalogue_id === catalogueId && cm.ref_module_id === modId));
            setCatModules(reindexCatModules(next));
            if (activeModuleId === modId) setActiveModuleId('');
        } else {
            const mod = moduleMap.get(modId);
            const row = {
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useGroupData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["uuid"])(),
                catalogue_id: catalogueId,
                ref_module_id: modId,
                code: mod?.code || '',
                libelle: mod?.libelle || '',
                ordre: nextOrdreForCatalogue(),
                is_enabled: true,
                niveau_set_id: firstEnabledSet?.id || null
            };
            setCatModules(reindexCatModules([
                ...catModules || [],
                row
            ]));
            if (!activeModuleId) setActiveModuleId(modId);
        }
    }
    function selectAllModules() {
        if (!catalogueId) return;
        setCatModules((prev)=>{
            const selected = new Set(prev.filter((x)=>x.catalogue_id === catalogueId).map((x)=>x.ref_module_id));
            const adds = refModules.filter((m)=>!selected.has(m.id)).map((m, i)=>({
                    id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useGroupData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["uuid"])(),
                    catalogue_id: catalogueId,
                    ref_module_id: m.id,
                    code: m.code,
                    libelle: m.libelle || '',
                    ordre: selected.size + i + 1,
                    is_enabled: true
                }));
            return reindexCatModules([
                ...prev,
                ...adds
            ]);
        });
    }
    function clearAllModules() {
        if (!catalogueId) return;
        const totalGroups = (groupes || []).filter((g)=>g.catalogue_id === catalogueId).length;
        if (totalGroups > 0 && !confirm(`Ce catalogue contient ${totalGroups} groupe(s). Les modules seront masqués dans l'UI (données conservées). Continuer ?`)) return;
        setCatModules((catModules || []).filter((cm)=>cm.catalogue_id !== catalogueId));
        setActiveModuleId('');
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log('storeRefs identity (should not change)', storeRefs);
    }, [
        storeRefs
    ]);
    if (!mounted) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "skeleton h-8 w-64 mb-4"
                }, void 0, false, {
                    fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                    lineNumber: 287,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "skeleton h-5 w-96 mb-2"
                }, void 0, false, {
                    fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                    lineNumber: 288,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "skeleton h-5 w-80"
                }, void 0, false, {
                    fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                    lineNumber: 289,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
            lineNumber: 286,
            columnNumber: 13
        }, this);
    }
    console.log(storeRefs);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-4 md:p-6 lg:p-8 space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$CatalogueHeader$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                offer: headerOffer,
                catalogue: headerCat,
                onBack: ()=>router.push('/catalogues'),
                onSwitchMode: ()=>router.push(`/catalogues/${catalogueId}/configurer`)
            }, void 0, false, {
                fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                lineNumber: 297,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModulesSelector$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                modules: refModules,
                selectedSet: selectedModuleIds,
                groupsCountByModule: groupsCountByModule,
                onToggle: toggleModule,
                onSelectAll: selectAllModules,
                onClearAll: clearAllModules
            }, void 0, false, {
                fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                lineNumber: 304,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModuleOrderList$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                includedRows: includedRows,
                moduleMap: moduleMap,
                groupsCountByModule: groupsCountByModule,
                onMove: moveModule
            }, void 0, false, {
                fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                lineNumber: 313,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModuleTabs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                modules: includedModules,
                activeId: activeModuleId,
                onChange: setActiveModuleId,
                renderPanel: (m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalogues$2f$ModulePanelContainer$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        module: m,
                        catalogueId: catalogueId,
                        refNiveau: refNiveau,
                        refNiveauSets: refNiveauSets,
                        selectedNiveauSetId: getSetIdForModule(m.id),
                        onChangeNiveauSet: (setId)=>setSetIdForModule(m.id, setId),
                        categoriesByModule: categoriesByModule,
                        actsByCategory: actsByCategory,
                        actMap: actMap,
                        showToast: showToast,
                        refs: storeRefs
                    }, void 0, false, {
                        fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                        lineNumber: 325,
                        columnNumber: 21
                    }, void 0)
            }, void 0, false, {
                fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                lineNumber: 320,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$ToastInline$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                toast: toast
            }, void 0, false, {
                fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
                lineNumber: 341,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx",
        lineNumber: 296,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=src_aefad7fc._.js.map