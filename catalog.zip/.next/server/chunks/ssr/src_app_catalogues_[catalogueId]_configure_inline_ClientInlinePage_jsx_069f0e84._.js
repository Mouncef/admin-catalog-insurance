module.exports = [
"[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx [app-rsc] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_app_catalogues_[catalogueId]_configure_inline_ClientInlinePage_jsx_da6a57d5._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/catalogues/[catalogueId]/configure/inline/ClientInlinePage.jsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}),
];