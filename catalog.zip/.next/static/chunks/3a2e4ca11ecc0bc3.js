__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/d21bb6aa8dd2832e.js",
  "static/chunks/turbopack-37b204783ffc5393.js"
])
