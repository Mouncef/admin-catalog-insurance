__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/d21bb6aa8dd2832e.js",
  "static/chunks/turbopack-10194b05623cdba7.js"
])
