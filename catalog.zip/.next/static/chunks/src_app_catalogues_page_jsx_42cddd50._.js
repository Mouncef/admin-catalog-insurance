(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_catalogues_page_jsx_e5c846c5._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_34ccba96._.js"
],
    source: "dynamic"
});
