'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRefModules, useRefCategories, useRefActs } from '@/providers/AppDataProvider'
import { sanitizeUpperKeep } from '@/lib/utils/StringUtil'
import { SquarePen, Trash2 } from "lucide-react";

/**
 * Page Next.js (JSX) — Référentiel des ACTES
 * Schéma: ref_acte { id, ref_categorie_id, code, libelle, allow_surco (bool), ordre }
 * Dépend des catégories (et donc modules).
 *
 * Persistance via AppDataProvider (localStorage sous-jacent):
 *   - Modules:      'app:ref_modules_v1'
 *   - Catégories:   'app:ref_categories_v1'
 *   - Actes:        'app:ref_acts_v1'
 *
 * Emplacement suggéré: app/acts/page.jsx
 */
export default function ActsPage() {
    const LS_MODS = 'app:ref_modules_v1'
    const LS_CATS = 'app:ref_categories_v1'
    const LS_ACTS = 'app:ref_acts_v1'

    const { refModules } = useRefModules()
    const { refCategories } = useRefCategories()
    const { refActs, setRefActs } = useRefActs()

    const [mounted, setMounted] = useState(false)
    const [moduleFilter, setModuleFilter] = useState('all') // 'all' | moduleId
    const [categoryFilter, setCategoryFilter] = useState('all') // 'all' | categoryId
    const [query, setQuery] = useState('')
    const [sortAsc, setSortAsc] = useState(true)
    const [toast, setToast] = useState(null) // {type:'success'|'error'|'info', msg}

    const upsertDialogRef = useRef(null)
    const deleteDialogRef = useRef(null)
    const importInputRef = useRef(null)

    const [editing, setEditing] = useState(null) // acte en édition
    const [candidateDelete, setCandidateDelete] = useState(null)

    useEffect(() => { setMounted(true) }, [])

    // ===== Utils =====
    function uuid() {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID()
        return 'id-' + Math.random().toString(36).slice(2) + Date.now().toString(36)
    }

    function showToast(type, msg) {
        setToast({ type, msg })
        setTimeout(() => setToast(null), 2500)
    }

    const moduleMap = useMemo(() => new Map(refModules.map((m) => [m.id, m])), [refModules])
    const categoryMap = useMemo(() => new Map(refCategories.map((c) => [c.id, c])), [refCategories])
    const categoriesByModule = useMemo(() => {
        const by = new Map()
        for (const c of refCategories) {
            if (!by.has(c.ref_module_id)) by.set(c.ref_module_id, [])
            by.get(c.ref_module_id).push(c)
        }
        for (const [, arr] of by) arr.sort((a, b) => a.ordre - b.ordre || a.code.localeCompare(b.code))
        return by
    }, [refCategories])

    // keeps code unique per category + reindex ordre per category
    function sanitizeActs(arr) {
        const byCat = new Map()
        for (const raw of arr || []) {
            if (!raw) continue
            const cat = categoryMap.get(raw.ref_categorie_id)
            if (!cat) continue // ignore orphelines
            const item = {
                id: raw.id || uuid(),
                ref_categorie_id: raw.ref_categorie_id,
                code: String(raw.code || '').trim(),
                libelle: String(raw.libelle || '').trim(),
                allow_surco: typeof raw.allow_surco === 'boolean' ? raw.allow_surco : true,
                ordre: Number.isFinite(Number(raw.ordre)) ? Number(raw.ordre) : undefined,
            }
            if (!byCat.has(item.ref_categorie_id)) byCat.set(item.ref_categorie_id, [])
            byCat.get(item.ref_categorie_id).push(item)
        }

        const result = []
        for (const [catId, list] of byCat) {
            // unicité de code (CI) dans la catégorie
            const seen = new Set()
            list.sort((a, b) => (a.ordre ?? 1e9) - (b.ordre ?? 1e9) || a.code.localeCompare(b.code))
            const cleaned = []
            for (const it of list) {
                if (!it.code) continue
                let code = it.code
                let k = code.toLowerCase()
                if (seen.has(k)) {
                    let n = 2
                    let cand = `${code}-${n}`
                    while (seen.has(cand.toLowerCase())) { n++; cand = `${code}-${n}` }
                    code = cand; k = code.toLowerCase()
                }
                seen.add(k)
                cleaned.push({ ...it, code })
            }
            cleaned.forEach((a, i) => result.push({ ...a, ordre: i + 1 }))
        }
        return result
    }

    function nextOrdreForCategory(catId) {
        if (!catId) return 1
        const count = refActs.filter((a) => a.ref_categorie_id === catId).length
        return count + 1
    }

    // ===== Sélecteurs =====
    // Ajuster le filtre catégorie lorsqu'on change de module
    useEffect(() => {
        if (moduleFilter === 'all') {
            setCategoryFilter('all')
            return
        }
        const cats = categoriesByModule.get(moduleFilter) || []
        if (cats.length === 0) setCategoryFilter('all')
        else if (categoryFilter !== 'all' && cats.every(c => c.id !== categoryFilter)) setCategoryFilter('all')
    }, [moduleFilter, categoriesByModule])

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase()

        // console.log(categoryMap.get("a1b2c3d4-0001-4e11-9a10-111111111111"))
        console.log(refActs)
        let base = refActs
            .filter((a) => {
                console.log(a)
                const cat = categoryMap.get(a.ref_categorie_id)
                if (!cat) return false
                if (moduleFilter !== 'all' && cat.ref_module_id !== moduleFilter) return false
                if (categoryFilter !== 'all' && a.ref_categorie_id !== categoryFilter) return false
                return true
            })
        // tri multi-niveaux
        base = base.sort((a, b) => {
            const ca = categoryMap.get(a.ref_categorie_id)
            const cb = categoryMap.get(b.ref_categorie_id)
            const ma = moduleMap.get(ca?.ref_module_id)
            const mb = moduleMap.get(cb?.ref_module_id)

            if (moduleFilter === 'all') {
                const sMod = (ma?.code || '').localeCompare(mb?.code || '')
                if (sMod !== 0) return sMod
            }
            if (categoryFilter === 'all') {
                const sCat = (ca?.ordre || 0) - (cb?.ordre || 0) || (ca?.code || '').localeCompare(cb?.code || '')
                if (sCat !== 0) return sCat
            }
            return (sortAsc ? 1 : -1) * ((a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code))
        })

        if (!q) return base
        return base.filter((a) => (
            a.code.toLowerCase().includes(q) || (a.libelle || '').toLowerCase().includes(q)
        ))
    }, [refActs, moduleFilter, categoryFilter, query, sortAsc, categoryMap, moduleMap])

    // ===== CRUD =====
    function openCreate() {
        // Pré-sélection en fonction des filtres
        let defaultModuleId = moduleFilter !== 'all' ? moduleFilter : (refModules[0]?.id || '')
        let defaultCategoryId = categoryFilter !== 'all' ? categoryFilter : ''
        if (!defaultCategoryId) {
            const cats = categoriesByModule.get(defaultModuleId) || []
            defaultCategoryId = cats[0]?.id || ''
        }
        setEditing({ id: null, ref_categorie_id: defaultCategoryId, code: '', libelle: '', allow_surco: true, ordre: nextOrdreForCategory(defaultCategoryId) })
        upsertDialogRef.current?.showModal()
    }

    function openEdit(act) {
        setEditing({ ...act })
        upsertDialogRef.current?.showModal()
    }

    function submitUpsert(e) {
        e?.preventDefault?.()
        if (!editing) return

        const ref_categorie_id = String(editing.ref_categorie_id || '')
        const cat = categoryMap.get(ref_categorie_id)
        if (!ref_categorie_id || !cat) return showToast('error', 'Catégorie requise')

        const code = (editing.code || '').trim()
        if (!code) return showToast('error', 'Le code est requis')
        if (code.length > 80) return showToast('error', 'Code ≤ 80 caractères')

        const existsSameCode = refActs.find((a) =>
            a.ref_categorie_id === ref_categorie_id && a.code.toLowerCase() === code.toLowerCase() && a.id !== editing.id
        )
        if (existsSameCode) return showToast('error', `Le code "${code}" existe déjà dans cette catégorie`)

        const libelle = (editing.libelle || '').trim()
        const allow_surco = Boolean(editing.allow_surco)
        const ordre = Number.isFinite(Number(editing.ordre)) ? Number(editing.ordre) : nextOrdreForCategory(ref_categorie_id)

        if (!editing.id) {
            const created = { id: uuid(), ref_categorie_id, code, libelle, allow_surco, ordre }
            const next = sanitizeActs([...refActs, created])
            setRefActs(next)
            showToast('success', 'Acte créé')
        } else {
            const nextArr = refActs.map((a) => (a.id === editing.id ? { ...a, ref_categorie_id, code, libelle, allow_surco, ordre } : a))
            const next = sanitizeActs(nextArr)
            setRefActs(next)
            showToast('success', 'Acte mis à jour')
        }

        upsertDialogRef.current?.close()
        setEditing(null)
    }

    function requestDelete(act) {
        setCandidateDelete(act)
        deleteDialogRef.current?.showModal()
    }

    function confirmDelete() {
        if (!candidateDelete) return
        const next = sanitizeActs(refActs.filter((a) => a.id !== candidateDelete.id))
        setRefActs(next)
        showToast('success', 'Acte supprimé')
        deleteDialogRef.current?.close()
        setCandidateDelete(null)
    }

    function cancelDelete() {
        deleteDialogRef.current?.close()
        setCandidateDelete(null)
    }

    function move(act, dir) {
        // Réordonne uniquement à l'intérieur de la même catégorie
        const currentCat = act.ref_categorie_id
        const siblings = filtered.filter((a) => a.ref_categorie_id === currentCat).sort((a, b) => a.ordre - b.ordre)
        const ids = siblings.map((s) => s.id)
        const idx = ids.indexOf(act.id)
        if (idx < 0) return
        const targetIdx = dir === 'up' ? idx - 1 : idx + 1
        if (targetIdx < 0 || targetIdx >= ids.length) return

        const idA = ids[idx]
        const idB = ids[targetIdx]
        const next = [...refActs]
        const a = next.find((x) => x.id === idA)
        const b = next.find((x) => x.id === idB)
        if (!a || !b) return
        if (a.ref_categorie_id !== b.ref_categorie_id) return

        const tmp = a.ordre
        a.ordre = b.ordre
        b.ordre = tmp
        setRefActs(sanitizeActs(next))
    }

    // ===== Import/Export (optionnels) =====
    function exportJSON() {
        const data = JSON.stringify(refActs, null, 2)
        const blob = new Blob([data], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = 'ref_acts.json'
        a.click()
        URL.revokeObjectURL(url)
    }

    function triggerImport() { importInputRef.current?.click() }

    function onImportFileChange(e) {
        const file = e.target.files?.[0]
        if (!file) return
        const reader = new FileReader()
        reader.onload = () => {
            try {
                const incoming = JSON.parse(String(reader.result))
                if (!Array.isArray(incoming)) throw new Error('JSON attendu: tableau d\'actes')
                const merged = mergeKeepingUniquePerCategory(refActs, incoming)
                setRefActs(sanitizeActs(merged))
                showToast('success', 'Import réussi')
            } catch (err) {
                console.error(err)
                showToast('error', 'Import invalide: ' + (err?.message || 'erreur inconnue'))
            } finally {
                e.target.value = ''
            }
        }
        reader.readAsText(file)
    }

    function mergeKeepingUniquePerCategory(existing, incoming) {
        // key = catId::codeLower
        const keyOf = (a) => `${a.ref_categorie_id || ''}::${String(a.code || '').trim().toLowerCase()}`
        const map = new Map(existing.map((a) => [keyOf(a), a]))
        for (const raw of incoming) {
            if (!raw) continue
            const item = {
                id: raw.id || uuid(),
                ref_categorie_id: raw.ref_categorie_id,
                code: String(raw.code || '').trim(),
                libelle: String(raw.libelle || '').trim(),
                allow_surco: typeof raw.allow_surco === 'boolean' ? raw.allow_surco : true,
                ordre: Number.isFinite(Number(raw.ordre)) ? Number(raw.ordre) : undefined,
            }
            if (!item.ref_categorie_id || !categoryMap.has(item.ref_categorie_id) || !item.code) continue
            map.set(keyOf(item), { ...map.get(keyOf(item)), ...item })
        }
        return Array.from(map.values())
    }

    function resetAll() {
        if (!confirm('Supprimer tous les actes stockés ?')) return
        setRefActs([])
        showToast('info', 'Liste vidée')
    }

    if (!mounted) {
        return (
            <div className="p-6">
                <div className="skeleton h-8 w-64 mb-4"></div>
                <div className="skeleton h-5 w-96 mb-2"></div>
                <div className="skeleton h-5 w-80"></div>
            </div>
        )
    }

    if (refModules.length === 0) {
        return (
            <div className="p-6">
                <div className="alert alert-warning max-w-2xl">
                    <span>Aucun module trouvé. Crée d'abord des modules (<span className="font-mono">{LS_MODS}</span>), puis des catégories (<span className="font-mono">{LS_CATS}</span>), avant d'ajouter des actes.</span>
                </div>
            </div>
        )
    }

    if (refCategories.length === 0) {
        return (
            <div className="p-6">
                <div className="alert alert-warning max-w-2xl">
                    <span>Aucune catégorie trouvée. Crée d'abord des catégories (<span className="font-mono">{LS_CATS}</span>).</span>
                </div>
            </div>
        )
    }

    // Catégories visibles en fonction du filtre module
    const visibleCategories = moduleFilter === 'all'
        ? refCategories
        : (categoriesByModule.get(moduleFilter) || [])

    console.log(filtered)
    return (
        <div className="p-4 md:p-6 lg:p-8 space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between gap-2">
                <h1 className="text-2xl font-bold">Référentiel — Actes</h1>
                <div className="flex gap-2">
                    <button className="btn btn-primary" onClick={openCreate}>+ Nouvel acte</button>
                    <div className="join">
                        {/* <button className="btn join-item" onClick={exportJSON}>Export JSON</button> */}
                        {/* <button className="btn join-item" onClick={triggerImport}>Import JSON</button> */}
                        {/* <input ref={importInputRef} type="file" accept="application/json" className="hidden" onChange={onImportFileChange} /> */}
                    </div>
                    <button className="btn btn-ghost" onClick={resetAll}>Réinitialiser</button>
                </div>
            </div>

            {/* Toolbar */}
            <div className="flex flex-col xl:flex-row xl:items-center gap-2">
                <label className="floating-label w-full sm:w-64">
                    <span>Filtrer par module</span>
                    <select className="select select-bordered" value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)}>
                        <option value="all">Tous les modules</option>
                        {refModules.map((m) => (
                            <option key={m.id} value={m.id}>{m.code} — {m.libelle || '—'}</option>
                        ))}
                    </select>
                </label>

                <label className="floating-label w-full sm:w-72">
                    <span>Filtrer par catégorie</span>
                    <select className="select select-bordered" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
                        <option value="all">Toutes les catégories</option>
                        {visibleCategories.map((c) => (
                            <option key={c.id} value={c.id}>{c.code} — {c.libelle || '—'}</option>
                        ))}
                    </select>
                </label>

                <label className="floating-label w-full xl:w-96 xl:ml-2">
                    <span>Rechercher</span>
                    <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        type="text"
                        className="input input-bordered w-full font-mono"
                        placeholder="code/libellé…"
                    />
                </label>

                <div className="xl:ml-auto flex items-center gap-2">
                    <span className="text-sm opacity-70">Tri par ordre</span>
                    <input type="checkbox" className="toggle" checked={sortAsc} onChange={() => setSortAsc((v) => !v)} />
                </div>
            </div>

            {/* Content */}
            <div className="card bg-base-100 shadow-md">
                <div className="card-body p-0">
                    <div className="overflow-x-auto">
                        <table className="table table-zebra">
                            <thead>
                            <tr>
                                <th style={{ width: 140 }}>Module</th>
                                <th style={{ width: 200 }}>Catégorie</th>
                                <th style={{ width: 90 }}>Ordre</th>
                                <th>Code</th>
                                <th>Libellé</th>
                                <th style={{ width: 110 }}>Surco ?</th>
                                <th className="text-right" style={{ width: 220 }}>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            {filtered.length === 0 && (
                                <tr>
                                    <td colSpan={7}>
                                        <div className="p-6 text-center opacity-70">Aucun acte. Cliquez sur « Nouvel acte » pour commencer.</div>
                                    </td>
                                </tr>
                            )}
                            {filtered.map((a) => {
                                const cat = categoryMap.get(a.ref_categorie_id)
                                const mod = moduleMap.get(cat?.ref_module_id)
                                return (
                                    <tr key={a.id}>
                                        <td>
                                            <div className="badge badge-outline">{mod ? (mod.code || '—') : '—'}</div>
                                        </td>
                                        <td>
                                            <div className="badge badge-ghost">{cat ? (cat.code || '—') : '—'}</div>
                                        </td>
                                        <td>
                                            <div className="join">
                                                <button className="btn btn-xs join-item" onClick={() => move(a, 'up')} title="Monter">▲</button>
                                                <span className="join-item btn btn-xs btn-ghost">{a.ordre}</span>
                                                <button className="btn btn-xs join-item" onClick={() => move(a, 'down')} title="Descendre">▼</button>
                                            </div>
                                        </td>
                                        <td><div className="font-mono font-medium">{a.code}</div></td>
                                        <td className="max-w-[520px]"><div className="truncate" title={a.libelle}>{a.libelle || <span className="opacity-50">—</span>}</div></td>
                                        <td>
                                            {a.allow_surco ? (
                                                <span className="badge badge-success">Oui</span>
                                            ) : (
                                                <span className="badge">Non</span>
                                            )}
                                        </td>
                                        <td className="text-right">
                                            <div className="join justify-end">
                                                <button className="btn btn-sm join-item" onClick={() => openEdit(a)}>
                                                    <SquarePen size={16} />
                                                </button>
                                                <button className="btn btn-sm btn-error join-item" onClick={() => requestDelete(a)}>
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                )
                            })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* Dialog: Create/Update */}
            <dialog ref={upsertDialogRef} className="modal">
                <div className="modal-box w-11/12 max-w-4xl">
                    <h3 className="font-bold text-lg">{editing?.id ? 'Modifier un acte' : 'Nouvel acte'}</h3>
                    <fieldset className="fieldset bg-base-200 border-base-300 rounded-box border p-4">
                        <form className="mt-4" onSubmit={submitUpsert}>
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">

                                {/* Row 1 */}
                                <label className="floating-label md:col-span-4">
                                    <span>Module <span className="text-error">*</span></span>
                                    <select
                                        className="select select-bordered w-full"
                                        value={ categoryMap.get(editing?.ref_categorie_id || '')?.ref_module_id || (moduleFilter === 'all' ? '' : moduleFilter) }
                                        onChange={(e) => {
                                            const newModId = e.target.value
                                            const cats = categoriesByModule.get(newModId) || []
                                            const newCatId = cats[0]?.id || ''
                                            setEditing((v) => ({ ...v, ref_categorie_id: newCatId, ordre: nextOrdreForCategory(newCatId) }))
                                        }}
                                        required
                                    >
                                        <option value="" disabled>Choisir un module…</option>
                                        {refModules.map((m) => (
                                            <option key={m.id} value={m.id}>{m.code} — {m.libelle || '—'}</option>
                                        ))}
                                    </select>
                                </label>

                                <label className="floating-label md:col-span-8">
                                    <span>Catégorie <span className="text-error">*</span></span>
                                    <select
                                        className="select select-bordered w-full"
                                        value={editing?.ref_categorie_id ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, ref_categorie_id: e.target.value, ordre: nextOrdreForCategory(e.target.value) }))}
                                        required
                                    >
                                        <option value="" disabled>Choisir une catégorie…</option>
                                        {(categoriesByModule.get(categoryMap.get(editing?.ref_categorie_id || '')?.ref_module_id)
                                            || categoriesByModule.get(moduleFilter) || refCategories)
                                            .map((c) => (
                                                <option key={c.id} value={c.id}>{c.code} — {c.libelle || '—'}</option>
                                            ))}
                                    </select>
                                </label>

                                {/* Row 2 */}
                                <label className="floating-label md:col-span-8">
                                    <span>Libellé</span>
                                    <input
                                        type="text"
                                        className="input input-bordered w-full"
                                        value={editing?.libelle ?? ''}
                                        onChange={(e) =>
                                            setEditing((v) => ({ ...v, libelle: e.target.value, code: sanitizeUpperKeep(e.target.value) }))
                                        }
                                        placeholder="Ex: Détartrage, Couronne céramo-métal…"
                                    />
                                </label>

                                <label className="floating-label md:col-span-4">
                                    <span>Ordre</span>
                                    <input
                                        type="number"
                                        min={1}
                                        className="input input-bordered w-full"
                                        value={editing?.ordre ?? ''}
                                        onChange={(e) =>
                                            setEditing((v) => ({ ...v, ordre: e.target.value === '' ? '' : Number(e.target.value) }))
                                        }
                                        placeholder="1"
                                    />
                                </label>

                                {/* Row 3 */}
                                <label className="floating-label md:col-span-8">
                                    <span>Code <span className="text-error">*</span></span>
                                    <input
                                        type="text"
                                        className="input input-bordered w-full font-mono"
                                        value={editing?.code ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, code: e.target.value }))}
                                        placeholder="EX: DETARTRAGE, COURONNE_CM…"
                                        maxLength={80}
                                        required
                                    />
                                </label>

                                <div className="md:col-span-4">
                                    {/* Toggle compact, aligné à droite */}
                                    <label className="label h-12 px-3 border border-base-300 rounded-box bg-base-100 flex justify-between items-center">
                                        <span className="label-text">Autoriser surcomplémentaire</span>
                                        <input
                                            type="checkbox"
                                            className="toggle"
                                            checked={!!editing?.allow_surco}
                                            onChange={(e) => setEditing((v) => ({ ...v, allow_surco: e.target.checked }))}
                                        />
                                    </label>
                                </div>

                            </div>

                            <div className="modal-action mt-6">
                                <button
                                    type="button"
                                    className="btn btn-ghost"
                                    onClick={() => { upsertDialogRef.current?.close(); setEditing(null) }}
                                >
                                    Annuler
                                </button>
                                <button type="submit" className="btn btn-primary">Enregistrer</button>
                            </div>
                        </form>
                    </fieldset>
                </div>
                <form method="dialog" className="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>

            {/* Dialog: Delete confirm */}
            <dialog ref={deleteDialogRef} className="modal">
                <div className="modal-box">
                    <h3 className="font-bold text-lg">Supprimer l'acte ?</h3>
                    <p className="py-2">Cette action est irréversible.</p>
                    <div className="bg-base-200 rounded p-3 font-mono">
                        {candidateDelete ? (
                            <>
                                <div><span className="opacity-70">Catégorie:</span> {categoryMap.get(candidateDelete.ref_categorie_id)?.code || '—'}</div>
                                <div><span className="opacity-70">Code:</span> {candidateDelete.code}</div>
                                <div><span className="opacity-70">Libellé:</span> {candidateDelete.libelle || '—'}</div>
                            </>
                        ) : '—'}
                    </div>
                    <div className="modal-action">
                        <button className="btn" onClick={cancelDelete}>Annuler</button>
                        <button className="btn btn-error" onClick={confirmDelete}>Supprimer</button>
                    </div>
                </div>
                <form method="dialog" className="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>

            {/* Toast */}
            {toast && (
                <div className="toast">
                    <div className={`alert ${toast.type === 'success' ? 'alert-success' : toast.type === 'error' ? 'alert-error' : 'alert-info'}`}>
                        <span>{toast.msg}</span>
                    </div>
                </div>
            )}

            {/* Footer helper */}
            <div className="opacity-60 text-xs">
                <span className="font-mono">localStorage</span> clés: <span className="font-mono">{LS_MODS}</span> (modules), <span className="font-mono">{LS_CATS}</span> (catégories), <span className="font-mono">{LS_ACTS}</span> (actes) — {refActs.length} actes
            </div>
        </div>
    )
}
