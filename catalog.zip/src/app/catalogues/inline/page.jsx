'use client'

import { Fragment, useEffect, useId, useMemo, useRef, useState } from 'react'
import {
    useRefOffers,
    useRefCatalogues,
    useRefModules,
    useRefCategories,
    useRefActs,
    useRefNiveau,
    useCatModules,
    useGroupeUIState,
} from '@/providers/AppDataProvider'
import { useGroupStore, uuid } from '@/hooks/useGroupData'

export default function CatalogueInlineEditorPage() {
    // Référentiels
    const { refOffers } = useRefOffers()
    const { refCatalogues } = useRefCatalogues()
    const { refModules } = useRefModules()
    const { refCategories } = useRefCategories()
    const { refActs } = useRefActs()
    const { refNiveau } = useRefNiveau()
    const { catModules, setCatModules } = useCatModules()

    const catModulesArr = useMemo(() => (Array.isArray(catModules) ? catModules : []), [catModules])

    // Maps & dérivés
    const offerMap = useMemo(() => new Map(refOffers.map(o => [o.id, o])), [refOffers])
    const catalogueMap = useMemo(() => new Map(refCatalogues.map(c => [c.id, c])), [refCatalogues])
    const moduleMap = useMemo(() => new Map(refModules.map(m => [m.id, m])), [refModules])

    const categoriesByModule = useMemo(() => {
        const by = new Map()
        for (const c of refCategories) {
            if (!by.has(c.ref_module_id)) by.set(c.ref_module_id, [])
            by.get(c.ref_module_id).push(c)
        }
        for (const [, arr] of by)
            arr.sort((a, b) => (a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code))
        return by
    }, [refCategories])

    const actsByCategory = useMemo(() => {
        const by = new Map()
        for (const a of refActs) {
            if (!by.has(a.ref_categorie_id)) by.set(a.ref_categorie_id, [])
            by.get(a.ref_categorie_id).push(a)
        }
        for (const [, arr] of by)
            arr.sort((a, b) => (a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code))
        return by
    }, [refActs])

    // Store groupes/membres/valeurs
    const refs = { catalogueMap, moduleMap }
    const { groupes, setGroupes, membres, setMembres, gvaleurs, setGvaleurs, memberOrderByGroup } =
        useGroupStore(refs)

    // Sélection Offre / Catalogue
    const [offerId, setOfferId] = useState('')
    const [catalogueId, setCatalogueId] = useState('')
    const cataloguesOfOffer = useMemo(
        () => (offerId ? refCatalogues.filter(c => c.offre_id === offerId) : []),
        [offerId, refCatalogues]
    )

    // Modules inclus
    const includedRows = useMemo(() => {
        if (!catalogueId) return []
        return catModulesArr
            .filter(cm => cm.catalogue_id === catalogueId)
            .sort(
                (a, b) =>
                    (a.ordre ?? 0) - (b.ordre ?? 0) ||
                    (moduleMap.get(a.ref_module_id)?.code || '').localeCompare(
                        moduleMap.get(b.ref_module_id)?.code || ''
                    )
            )
    }, [catModulesArr, catalogueId, moduleMap])

    const selectedModuleIds = useMemo(() => new Set(includedRows.map(r => r.ref_module_id)), [includedRows])
    const includedModules = useMemo(
        () => includedRows.map(r => moduleMap.get(r.ref_module_id)).filter(Boolean),
        [includedRows, moduleMap]
    )

    // Onglet module actif
    const [activeModuleId, setActiveModuleId] = useState('')
    const tabsId = useId()
    const moduleTabsName = `mod_tabs_${tabsId}`

    useEffect(() => {
        if (!catalogueId) return
        if (includedModules.length === 0) {
            setActiveModuleId('')
            return
        }
        if (!includedModules.some(m => m.id === activeModuleId)) {
            setActiveModuleId(includedModules[0].id)
        }
    }, [catalogueId, includedModules, activeModuleId])

    // Groupes par module pour badge compteur
    const groupsCountByModule = useMemo(() => {
        const map = new Map()
        for (const g of groupes) {
            if (g.catalogue_id !== catalogueId) continue
            map.set(g.ref_module_id, 1 + (map.get(g.ref_module_id) || 0))
        }
        return map
    }, [groupes, catalogueId])

    // Helpers modules
    function reindexCatModules(nextAll) {
        const [kept, rows] = nextAll.reduce(
            (acc, cm) => {
                if (cm.catalogue_id === catalogueId) acc[1].push(cm)
                else acc[0].push(cm)
                return acc
            },
            [[], []]
        )
        const reindexed = rows
            .slice()
            .sort((a, b) => (a.ordre ?? 0) - (b.ordre ?? 0))
            .map((r, i) => ({ ...r, ordre: i + 1 }))
        return [...kept, ...reindexed]
    }

    function nextOrdreForCatalogue() {
        return includedRows.length + 1
    }

    function toggleModule(modId) {
        if (!catalogueId) return
        const isSelected = selectedModuleIds.has(modId)
        if (isSelected) {
            const cnt = groupsCountByModule.get(modId) || 0
            if (cnt > 0 && !confirm(`Des groupes (${cnt}) existent sur ce module. Le masquer ?`)) return
            const next = catModulesArr.filter(cm => !(cm.catalogue_id === catalogueId && cm.ref_module_id === modId))
            setCatModules(reindexCatModules(next))
            if (activeModuleId === modId) setActiveModuleId('')
        } else {
            const mod = moduleMap.get(modId)
            const row = {
                id: uuid(),
                catalogue_id: catalogueId,
                ref_module_id: modId,
                code: mod?.code || '',
                libelle: mod?.libelle || '',
                ordre: nextOrdreForCatalogue(),
                is_enabled: true,
            }
            setCatModules(reindexCatModules([...catModulesArr, row]))
            if (!activeModuleId) setActiveModuleId(modId)
        }
    }

    function moveModule(modId, dir) {
        if (!catalogueId) return
        const idx = includedRows.findIndex(r => r.ref_module_id === modId)
        const target = dir === 'up' ? idx - 1 : idx + 1
        if (idx < 0 || target < 0 || target >= includedRows.length) return
        const a = includedRows[idx],
            b = includedRows[target]
        setCatModules(
            reindexCatModules(
                catModulesArr.map(cm => {
                    if (cm.id === a.id) return { ...cm, ordre: b.ordre }
                    if (cm.id === b.id) return { ...cm, ordre: a.ordre }
                    return cm
                })
            )
        )
    }

    function selectAllModules() {
        if (!catalogueId) return
        const selected = new Set(catModulesArr.filter(x => x.catalogue_id === catalogueId).map(x => x.ref_module_id))
        const adds = refModules
            .filter(m => !selected.has(m.id))
            .map((m, i) => ({
                id: uuid(),
                catalogue_id: catalogueId,
                ref_module_id: m.id,
                code: m.code,
                libelle: m.libelle || '',
                ordre: selected.size + i + 1,
                is_enabled: true,
            }))
        setCatModules(reindexCatModules([...catModulesArr, ...adds]))
    }

    function clearAllModules() {
        if (!catalogueId) return
        const totalGroups = groupes.filter(g => g.catalogue_id === catalogueId).length
        if (
            totalGroups > 0 &&
            !confirm(
                `Ce catalogue contient ${totalGroups} groupe(s). Les modules seront masqués (données conservées). Continuer ?`
            )
        )
            return
        setCatModules(catModulesArr.filter(cm => cm.catalogue_id !== catalogueId))
        setActiveModuleId('')
    }

    // 1) Choisir l'offre
    if (!offerId) {
        return (
            <div className="p-6 max-w-3xl">
                <h1 className="text-2xl font-bold mb-4">Configurer un catalogue (éditeur fluide)</h1>
                <label className="floating-label w-full">
                    <span>Choisir une offre</span>
                    <select className="select select-bordered w-full" value={offerId} onChange={e => setOfferId(e.target.value)}>
                        <option value="" disabled>
                            — Sélectionner —
                        </option>
                        {refOffers.map(o => (
                            <option key={o.id} value={o.id}>
                                {o.code} — {o.libelle || '—'}
                            </option>
                        ))}
                    </select>
                </label>
                <div className="opacity-70 text-sm mt-2">Étape 1/3</div>
            </div>
        )
    }

    // 2) Choisir le catalogue
    if (!catalogueId) {
        return (
            <div className="p-6 max-w-3xl">
                <h1 className="text-2xl font-bold mb-4">Offre: {offerMap.get(offerId)?.code}</h1>
                <label className="floating-label w-full">
                    <span>Choisir un catalogue</span>
                    <select
                        className="select select-bordered w-full"
                        value={catalogueId}
                        onChange={e => setCatalogueId(e.target.value)}
                    >
                        <option value="" disabled>
                            — Sélectionner —
                        </option>
                        {cataloguesOfOffer.map(c => (
                            <option key={c.id} value={c.id}>
                                {[c.risque, c.annee, c.version].filter(Boolean).join(' · ')}
                            </option>
                        ))}
                    </select>
                </label>
                <div className="mt-4">
                    <button className="btn" onClick={() => setOfferId('')}>
                        ← Changer d'offre
                    </button>
                </div>
                <div className="opacity-70 text-sm mt-2">Étape 2/3</div>
            </div>
        )
    }

    const headerCat = catalogueMap.get(catalogueId)
    const headerOffer = offerMap.get(offerId)

    return (
        <div className="p-4 md:p-6 lg:p-8 space-y-4">
            {/* Header */}
            <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                    <h1 className="text-2xl font-bold">
                        {headerOffer?.code} — {headerOffer?.libelle}
                    </h1>
                    <div className="opacity-70">
                        Catalogue: {[headerCat?.risque, headerCat?.annee, headerCat?.version].filter(Boolean).join(' · ')}
                    </div>
                </div>
                <div className="join">
                    <button className="btn join-item" onClick={() => setCatalogueId('')}>
                        Changer de catalogue
                    </button>
                    <button className="btn join-item" onClick={() => setOfferId('')}>
                        Changer d'offre
                    </button>
                </div>
            </div>

            {/* Modules inclus */}
            <div className="card bg-base-100 shadow-sm">
                <div className="card-body p-4">
                    <div className="flex items-center justify-between gap-2">
                        <h2 className="text-lg font-semibold">Modules (inline)</h2>
                        <div className="join">
                            <button className="btn btn-sm join-item" onClick={selectAllModules}>
                                Tout inclure
                            </button>
                            <button className="btn btn-sm join-item" onClick={clearAllModules}>
                                Tout retirer
                            </button>
                        </div>
                    </div>

                    {/* Toggle + réordonnancement */}
                    <div className="mt-3 flex flex-wrap gap-2">
                        {refModules.map(m => {
                            const on = selectedModuleIds.has(m.id)
                            const hasGroups = (groupsCountByModule.get(m.id) || 0) > 0
                            return (
                                <div key={m.id} className="group inline-flex items-center gap-1">
                                    <button
                                        type="button"
                                        className={`btn btn-sm ${on ? 'btn-primary' : 'btn-outline'}`}
                                        onClick={() => toggleModule(m.id)}
                                        title={hasGroups ? 'Des groupes existent pour ce module' : ''}
                                    >
                                        <span className="font-mono">{m.code}</span>
                                        {hasGroups ? <span className="badge badge-xs ml-2">grp</span> : null}
                                    </button>
                                    {on && (
                                        <span className="opacity-0 group-hover:opacity-100 transition-opacity join">
                      <button type="button" className="btn btn-xs join-item" onClick={() => moveModule(m.id, 'up')} title="Monter">
                        ▲
                      </button>
                      <button type="button" className="btn btn-xs join-item" onClick={() => moveModule(m.id, 'down')} title="Descendre">
                        ▼
                      </button>
                    </span>
                                    )}
                                </div>
                            )
                        })}
                    </div>

                    <div className="opacity-60 text-xs mt-2">L’ordre ci-dessus détermine l’ordre des onglets.</div>
                </div>
            </div>

            {/* Onglets modules */}
            {includedModules.length === 0 ? (
                <div className="alert alert-info">Sélectionne au moins un module pour gérer les groupes.</div>
            ) : (
                <div className="tabs tabs-lift mt-2">
                    {includedModules.map((m, i) => {
                        const checked = activeModuleId ? activeModuleId === m.id : i === 0
                        const rows = groupes
                            .filter(g => g.catalogue_id === catalogueId && g.ref_module_id === m.id)
                            .sort((a, b) => (a.priorite || 0) - (b.priorite || 0) || a.nom.localeCompare(b.nom))

                        return (
                            <Fragment key={m.id}>
                                <label className="tab">
                                    <input type="radio" name={moduleTabsName} checked={checked} onChange={() => setActiveModuleId(m.id)} />
                                    {m.code}
                                </label>
                                <div className="tab-content bg-base-100 border-base-300 p-4">
                                    <ModuleInlineBoard
                                        module={m}
                                        catalogueId={catalogueId}
                                        groupes={rows} // filtré pour l’affichage
                                        allGroupes={groupes} // liste complète pour les mutations
                                        niveaux={refNiveau}
                                        categoriesByModule={categoriesByModule}
                                        actsByCategory={actsByCategory}
                                        membres={membres}
                                        setMembres={setMembres}
                                        gvaleurs={gvaleurs}
                                        setGvaleurs={setGvaleurs}
                                        setGroupes={setGroupes}
                                        memberOrderByGroup={memberOrderByGroup}
                                    />
                                </div>
                            </Fragment>
                        )
                    })}
                </div>
            )}
        </div>
    )
}

/* =========================
   Board inline par module
========================= */
function ModuleInlineBoard({
                               module,
                               catalogueId,
                               groupes,
                               allGroupes,
                               niveaux,
                               categoriesByModule,
                               actsByCategory,
                               membres,
                               setMembres,
                               gvaleurs,
                               setGvaleurs,
                               setGroupes,
                               memberOrderByGroup,
                           }) {
    const { uiState, setUIState } = useGroupeUIState()

    const niveauxEnabled = useMemo(
        () => (niveaux || []).filter(n => !!n.is_enabled).sort((a, b) => (a.ordre || 0) - (b.ordre || 0)),
        [niveaux]
    )

    function createGroup() {
        const subset = (allGroupes || []).filter(x => x.catalogue_id === catalogueId && x.ref_module_id === module.id)
        const nextPrio = (subset.length ? Math.max(...subset.map(x => x.priorite ?? 100)) : 100) + 1
        const g = { id: uuid(), catalogue_id: catalogueId, ref_module_id: module.id, nom: 'Nouveau groupe', priorite: nextPrio }
        setGroupes([...(allGroupes || []), g])
    }

    function renameGroup(gid, name) {
        setGroupes((allGroupes || []).map(g => (g.id === gid ? { ...g, nom: name } : g)))
    }

    function shiftPriority(gid, delta) {
        const subset = (allGroupes || [])
            .filter(x => x.catalogue_id === catalogueId && x.ref_module_id === module.id)
            .sort((a, b) => (a.priorite || 0) - (b.priorite || 0) || a.nom.localeCompare(b.nom))

        const idx = subset.findIndex(g => g.id === gid)
        const j = idx + delta
        if (idx < 0 || j < 0 || j >= subset.length) return

        const a = subset[idx],
            b = subset[j]
        const pa = a.priorite ?? 100,
            pb = b.priorite ?? 100

        setGroupes((allGroupes || []).map(g => {
            if (g.id === a.id) return { ...g, priorite: pb }
            if (g.id === b.id) return { ...g, priorite: pa }
            return g
        }))
    }

    function deleteGroup(g) {
        if (!confirm('Supprimer ce groupe ?')) return
        setGroupes((allGroupes || []).filter(x => x.id !== g.id))
        setMembres(membres.filter(m => m.groupe_id !== g.id))
        setGvaleurs((gvaleurs || []).filter(v => v.groupe_id !== g.id))
        // purge état UI persistant
        setUIState(prev => {
            const n = { ...(prev || {}) }
            delete n[g.id]
            return n
        })
    }

    return (
        <div className="space-y-3">
            <div className="flex items-center justify-between">
                <div className="font-semibold">
                    Groupes du module <span className="badge badge-outline ml-2">{module.code}</span>
                </div>
                <button className="btn btn-primary btn-sm" onClick={createGroup}>
                    + Ajouter un groupe
                </button>
            </div>

            {groupes.length === 0 && <div className="alert alert-info">Aucun groupe. Crée ton premier groupe.</div>}

            <div className="grid grid-cols-1 gap-3">
                {groupes.map(g => (
                    <GroupCard
                        key={g.id}
                        group={g}
                        module={module}
                        niveaux={niveauxEnabled}
                        categoriesByModule={categoriesByModule}
                        actsByCategory={actsByCategory}
                        membres={membres}
                        setMembres={setMembres}
                        gvaleurs={gvaleurs}
                        setGvaleurs={setGvaleurs}
                        onRename={renameGroup}
                        onShiftUp={() => shiftPriority(g.id, -1)}
                        onShiftDown={() => shiftPriority(g.id, +1)}
                        onDelete={() => deleteGroup(g)}
                        memberOrderByGroup={memberOrderByGroup}
                    />
                ))}
            </div>
        </div>
    )
}

/* =========================
   Carte de groupe (inline)
========================= */
function GroupCard({
                       group,
                       module,
                       niveaux,
                       categoriesByModule,
                       actsByCategory,
                       membres,
                       setMembres,
                       gvaleurs,
                       setGvaleurs,
                       onRename,
                       onShiftUp,
                       onShiftDown,
                       onDelete,
                       memberOrderByGroup,
                   }) {
    const nameRef = useRef(null)

    // --- États UI locaux persistants ---
    const { uiState, setUIState } = useGroupeUIState()
    const gUI = uiState?.[group.id] || { locked: false, acts: [] }
    const locked = !!gUI.locked
    const validatedActs = useMemo(() => new Set(gUI.acts || []), [gUI.acts])

    // UI locaux non persistants
    const [query, setQuery] = useState('')
    const [editingCell, setEditingCell] = useState(null) // { actId, nivId, kind: 'base'|'surco' }
    const [draft, setDraft] = useState({ value: '', expression: '' })

    // Membres du groupe courant
    const groupMembers = useMemo(
        () => (membres || []).filter(m => m.groupe_id === group.id),
        [membres, group.id]
    )

    // Pour désactiver le bouton dans le dropdown et les checks rapides
    const membersSet = useMemo(() => new Set(groupMembers.map(m => m.act_id)), [groupMembers])

    // Catégories du module courant
    const cats = useMemo(() => categoriesByModule.get(module.id) || [], [categoriesByModule, module.id])

    // Map acteId -> acte (construit UNIQUEMENT à partir des catégories du module courant)
    const actById = useMemo(() => {
        const m = new Map()
        for (const c of cats) {
            const arr = actsByCategory.get(c.id) || []
            for (const a of arr) m.set(a.id, a)
        }
        return m
    }, [cats, actsByCategory])

    // Tri pour les membres (ordre personnalisable par store)
    const orderMap = useMemo(
        () => memberOrderByGroup.get(group.id) || new Map(),
        [memberOrderByGroup, group.id, membres]
    )

    // Membres groupés par catégorie (affichage)
    const membersByCat = useMemo(() => {
        const by = new Map()
        for (const mem of groupMembers) {
            const a = actById.get(mem.act_id)
            if (!a) continue // si l’acte ne fait pas partie du module courant, on ignore
            const catId = a.ref_categorie_id
            if (!by.has(catId)) by.set(catId, [])
            by.get(catId).push(a)
        }
        for (const [, arr] of by) {
            arr.sort((a, b) => {
                const oa = orderMap.get(a.id) ?? 1e9
                const ob = orderMap.get(b.id) ?? 1e9
                if (oa !== ob) return oa - ob
                const ra = a.ordre || 0,
                    rb = b.ordre || 0
                return ra - rb || a.code.localeCompare(b.code)
            })
        }
        return by
    }, [groupMembers, actById, orderMap])

    // valeurs indexées (affichage texte)
    const valMap = useMemo(() => {
        const m = new Map()
        for (const v of gvaleurs || []) {
            if (v.groupe_id !== group.id) continue
            m.set(`${v.act_id}::${v.niveau_id}::${v.kind}`, {
                value: v?.commentaire || '',
                expression: v?.expression || '',
            })
        }
        return m
    }, [gvaleurs, group.id])

    function cellVal(actId, nivId, kind) {
        return valMap.get(`${actId}::${nivId}::${kind}`) || { value: '', expression: '' }
    }

    // ====== édition cellule ======
    function startEdit(actId, nivId, kind) {
        const cur = cellVal(actId, nivId, kind)
        setEditingCell({ actId, nivId, kind })
        setDraft({ value: cur.value, expression: cur.expression })
    }

    function cancelEdit() {
        setEditingCell(null)
        setDraft({ value: '', expression: '' })
    }

    function saveEdit() {
        if (!editingCell) return
        const { actId, nivId, kind } = editingCell
        setGvaleurs(prev => {
            const others = (prev || []).filter(
                x => !(x.groupe_id === group.id && x.act_id === actId && x.niveau_id === nivId && x.kind === kind)
            )
            const existing = (prev || []).find(
                x => x.groupe_id === group.id && x.act_id === actId && x.niveau_id === nivId && x.kind === kind
            )
            const base =
                existing || {
                    id: uuid(),
                    groupe_id: group.id,
                    act_id: actId,
                    niveau_id: nivId,
                    kind,
                    mode: 'texte_libre',
                    base: 'inconnu',
                    taux: null,
                    montant: null,
                    unite: 'inconnu',
                    plafond_montant: null,
                    plafond_unite: null,
                    periodicite: null,
                    condition_json: null,
                    expression: '',
                    commentaire: '',
                }
            const next = { ...base, commentaire: draft.value, expression: draft.expression }
            return [...others, next]
        })
        cancelEdit()
    }

    // ====== niveaux (chips) ======
    function hasLevel(actId, nivId) {
        return !!(gvaleurs || []).find(v => v.groupe_id === group.id && v.act_id === actId && v.niveau_id === nivId)
    }

    function toggleLevel(actId, nivId) {
        if (locked || validatedActs.has(actId)) return
        const exists = hasLevel(actId, nivId)
        if (exists) {
            setGvaleurs(prev =>
                (prev || []).filter(v => !(v.groupe_id === group.id && v.act_id === actId && v.niveau_id === nivId))
            )
        } else {
            // Ajout des 2 cellules (base/surco)
            setGvaleurs(prev => [
                ...(prev || []),
                {
                    id: uuid(),
                    groupe_id: group.id,
                    act_id: actId,
                    niveau_id: nivId,
                    kind: 'base',
                    mode: 'texte_libre',
                    base: 'inconnu',
                    taux: null,
                    montant: null,
                    unite: 'inconnu',
                    plafond_montant: null,
                    plafond_unite: null,
                    periodicite: null,
                    condition_json: null,
                    expression: '',
                    commentaire: '',
                },
                {
                    id: uuid(),
                    groupe_id: group.id,
                    act_id: actId,
                    niveau_id: nivId,
                    kind: 'surco',
                    mode: 'texte_libre',
                    base: 'inconnu',
                    taux: null,
                    montant: null,
                    unite: 'inconnu',
                    plafond_montant: null,
                    plafond_unite: null,
                    periodicite: null,
                    condition_json: null,
                    expression: '',
                    commentaire: '',
                },
            ])

            // Ouvrir l'éditeur immédiatement sur la cellule "base"
            setTimeout(() => {
                setEditingCell({ actId, nivId, kind: 'base' })
                setDraft({ value: '', expression: '' })
            }, 0)
        }
    }

    // ====== actes (ajout, ordre, suppression) ======
    function addAct(actId) {
        if (locked || validatedActs.has(actId)) return
        if (membersSet.has(actId)) return

        // 1) ajouter le membre avec un id
        const last = Math.max(0, ...groupMembers.map(m => m.ordre || 0))
        const member = { id: uuid(), groupe_id: group.id, act_id: actId, ordre: last + 1 }
        setMembres(prev => [...(prev || []), member])

        // 2) activer automatiquement le 1er niveau (pour que la ligne soit visible + cellules éditables)
        const firstLevel = niveaux?.[0]
        if (firstLevel) {
            const nivId = firstLevel.id
            setGvaleurs(prev => [
                ...(prev || []),
                {
                    id: uuid(),
                    groupe_id: group.id,
                    act_id: actId,
                    niveau_id: nivId,
                    kind: 'base',
                    mode: 'texte_libre',
                    base: 'inconnu',
                    taux: null,
                    montant: null,
                    unite: 'inconnu',
                    plafond_montant: null,
                    plafond_unite: null,
                    periodicite: null,
                    condition_json: null,
                    expression: '',
                    commentaire: '',
                },
                {
                    id: uuid(),
                    groupe_id: group.id,
                    act_id: actId,
                    niveau_id: nivId,
                    kind: 'surco',
                    mode: 'texte_libre',
                    base: 'inconnu',
                    taux: null,
                    montant: null,
                    unite: 'inconnu',
                    plafond_montant: null,
                    plafond_unite: null,
                    periodicite: null,
                    condition_json: null,
                    expression: '',
                    commentaire: '',
                },
            ])

            // ouvrir directement l’éditeur sur la cellule "base"
            setTimeout(() => {
                setEditingCell({ actId, nivId, kind: 'base' })
                setDraft({ value: '', expression: '' })
            }, 0)
        }
    }

    function moveAct(actId, dir) {
        if (locked || validatedActs.has(actId)) return
        const list = groupMembers.slice().sort((a, b) => (a.ordre || 1e9) - (b.ordre || 1e9))
        const idx = list.findIndex(x => x.act_id === actId)
        const j = dir === 'up' ? idx - 1 : idx + 1
        if (idx < 0 || j < 0 || j >= list.length) return
        const a = list[idx],
            b = list[j]
        setMembres(
            membres.map(m => {
                if (m.groupe_id !== group.id) return m
                if (m.act_id === a.act_id) return { ...m, ordre: b.ordre }
                if (m.act_id === b.act_id) return { ...m, ordre: a.ordre }
                return m
            })
        )
    }

    // ====== validation acte & groupe ======
    const updateUI = partial => setUIState({ ...(uiState || {}), [group.id]: { ...gUI, ...partial } })
    const setLockedPersist = v => updateUI({ locked: !!v })
    const setActValidated = (actId, on) => {
        const s = new Set(gUI.acts || [])
        on ? s.add(actId) : s.delete(actId)
        updateUI({ acts: [...s] })
    }

    function toggleActValidated(actId) {
        if (locked) return
        const on = !validatedActs.has(actId)
        setActValidated(actId, on)
        if (editingCell?.actId === actId) cancelEdit()
    }

    function toggleLockGroup() {
        setLockedPersist(!locked)
        cancelEdit()
    }

    function removeAct(actId) {
        if (locked) return
        setMembres(membres.filter(m => !(m.groupe_id === group.id && m.act_id === actId)))
        setGvaleurs(prev => (prev || []).filter(v => !(v.groupe_id === group.id && v.act_id === actId)))
        if (validatedActs.has(actId)) setActValidated(actId, false)
    }

    // Petit rendu pour les valeurs
    function RenderVal({ v }) {
        const hasV = (v.value || '').trim().length > 0
        const hasE = (v.expression || '').trim().length > 0
        if (!hasV && !hasE) return <span className="opacity-30">—</span>
        return (
            <div className="min-h-8">
                {hasV && <div className="font-mono text-xs break-words">{v.value}</div>}
                {hasE && (
                    <div className="text-[11px] opacity-70 break-words" title={v.expression}>
                        {v.expression}
                    </div>
                )}
            </div>
        )
    }

    // Préparer une liste de catégories à afficher (uniquement celles qui ont des actes membres)
    const displayCats = useMemo(() => {
        return cats.filter(c => (membersByCat.get(c.id) || []).length > 0)
    }, [cats, membersByCat])

    const totalActs = useMemo(
        () => Array.from(membersByCat.values()).reduce((s, arr) => s + arr.length, 0),
        [membersByCat]
    )

    return (
        <div className="card bg-base-100 shadow group">
            <div className="card-body p-4 space-y-3">
                {/* Header groupe */}
                <div className="flex items-center gap-2">
                    <input
                        ref={nameRef}
                        className="input input-sm input-bordered w-full"
                        value={group.nom}
                        onChange={e => onRename(group.id, e.target.value)}
                        readOnly={locked}
                    />
                    {locked && <span className="badge badge-success">Groupe validé</span>}
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity join">
            <button className="btn btn-xs join-item" onClick={onShiftUp} title="Monter le groupe" disabled={locked}>
              ▲
            </button>
            <button className="btn btn-xs join-item" onClick={onShiftDown} title="Descendre le groupe" disabled={locked}>
              ▼
            </button>
          </span>
                    <button className="btn btn-xs" onClick={toggleLockGroup}>
                        {locked ? 'Réouvrir le groupe' : 'Valider le groupe ✅'}
                    </button>
                    <button className="btn btn-xs btn-error" onClick={onDelete} title="Supprimer" disabled={locked}>
                        Suppr
                    </button>
                </div>

                {/* Bandeau actions rapides */}
                <div className="flex items-center gap-2">
                    {/* Ajouter un acte (dropdown) */}
                    <div className={`dropdown ${locked ? 'pointer-events-none opacity-60' : ''}`}>
                        <div tabIndex={0} role="button" className="btn btn-sm">
                            + Ajouter un acte
                        </div>
                        <div tabIndex={0} className="dropdown-content z-20 card card-compact bg-base-100 p-2 shadow w-96">
                            <div className="p-2">
                                <input
                                    className="input input-sm input-bordered w-full"
                                    placeholder="Filtrer (code/libellé/catégorie)"
                                    value={query}
                                    onChange={e => setQuery(e.target.value)}
                                />
                            </div>
                            <ul className="menu menu-sm max-h-80 overflow-auto">
                                {cats.map(cat => {
                                    const acts = (actsByCategory.get(cat.id) || []).filter(a => {
                                        if (!query.trim()) return true
                                        const q = query.trim().toLowerCase()
                                        return (
                                            a.code.toLowerCase().includes(q) ||
                                            (a.libelle || '').toLowerCase().includes(q) ||
                                            (cat.code || '').toLowerCase().includes(q)
                                        )
                                    })
                                    if (acts.length === 0) return null
                                    return (
                                        <li key={cat.id}>
                                            <h3 className="menu-title">
                                                {cat.code} — {cat.libelle || '—'}
                                            </h3>
                                            <ul>
                                                {acts.map(a => (
                                                    <li key={a.id}>
                                                        <button
                                                            className="justify-between"
                                                            onClick={() => {
                                                                addAct(a.id)
                                                                setTimeout(() => {
                                                                    if (document.activeElement) document.activeElement.blur()
                                                                }, 0)
                                                            }}
                                                            disabled={membersSet.has(a.id)}
                                                            title={membersSet.has(a.id) ? 'Déjà dans le groupe' : 'Ajouter'}
                                                        >
                                                            <span className="font-mono">{a.code}</span>
                                                            <span className="opacity-70">{a.libelle || '—'}</span>
                                                        </button>
                                                    </li>
                                                ))}
                                            </ul>
                                        </li>
                                    )
                                })}
                            </ul>
                        </div>
                    </div>

                    <div className="opacity-60 text-xs">Survolez la carte pour afficher les actions (tri, suppression).</div>
                </div>

                {/* Tableau inline (acts x niveaux) */}
                <div className="overflow-x-auto">
                    <table className="table">
                        <thead className="table-pin-rows">
                        <tr>
                            <th rowSpan={2} className="align-bottom table-pin-cols" style={{ minWidth: 260 }}>
                                Garantie
                            </th>
                            {niveaux.map(n => (
                                <th key={n.id} colSpan={2} className="text-center">
                                    {n.code}
                                </th>
                            ))}
                        </tr>
                        <tr>
                            {niveaux.map(n => (
                                <Fragment key={`sub-${n.id}`}>
                                    <th className="text-center">Base</th>
                                    <th className="text-center">Surco</th>
                                </Fragment>
                            ))}
                        </tr>
                        </thead>
                        <tbody className="table-pin-rows">
                        {totalActs === 0 ? (
                            <tr>
                                <td className="text-center opacity-60" colSpan={1 + 2 * niveaux.length}>
                                    Aucun acte dans ce groupe. Ajoutez-en via « + Ajouter un acte ».
                                </td>
                            </tr>
                        ) : (
                            displayCats.map(cat => {
                                const acts = membersByCat.get(cat.id) || []
                                return (
                                    <Fragment key={cat.id}>
                                        <tr className="bg-base-200">
                                            <th colSpan={1 + niveaux.length * 2} className="text-left">
                                                <span className="badge badge-outline mr-2">{cat.code}</span>
                                                <span className="opacity-70">{cat.libelle || '—'}</span>
                                            </th>
                                        </tr>

                                        {acts.map(a => {
                                            const isActLocked = locked || validatedActs.has(a.id)
                                            return (
                                                <tr key={a.id} className="group/row">
                                                    {/* Colonne acte + actions */}
                                                    <td className="table-pin-cols">
                                                        <div className="flex items-center gap-2">
                                                            <span className="font-mono font-medium">{a.code}</span>
                                                            <span className="opacity-70 truncate">{a.libelle || '—'}</span>
                                                            {validatedActs.has(a.id) && <span className="badge badge-success">Acte validé</span>}
                                                            <span className="ml-auto opacity-0 group-hover/row:opacity-100 transition-opacity join">
                                  <button
                                      className="btn btn-xs join-item"
                                      onClick={() => moveAct(a.id, 'up')}
                                      title="Monter"
                                      disabled={isActLocked}
                                  >
                                    ▲
                                  </button>
                                  <button
                                      className="btn btn-xs join-item"
                                      onClick={() => moveAct(a.id, 'down')}
                                      title="Descendre"
                                      disabled={isActLocked}
                                  >
                                    ▼
                                  </button>
                                  <button className="btn btn-xs join-item" onClick={() => toggleActValidated(a.id)}>
                                    {validatedActs.has(a.id) ? 'Réouvrir acte' : 'Valider acte ✅'}
                                  </button>
                                  <button
                                      className="btn btn-xs btn-ghost join-item"
                                      onClick={() => removeAct(a.id)}
                                      title="Retirer"
                                      disabled={locked}
                                  >
                                    ✕
                                  </button>
                                </span>
                                                        </div>
                                                        {/* Chips niveaux */}
                                                        <div className="flex flex-wrap gap-1 mt-2">
                                                            {niveaux.map(n => {
                                                                const on = hasLevel(a.id, n.id)
                                                                return (
                                                                    <button
                                                                        key={n.id}
                                                                        type="button"
                                                                        className={`btn btn-ghost btn-xs ${on ? 'btn-active' : ''}`}
                                                                        onClick={() => toggleLevel(a.id, n.id)}
                                                                        disabled={isActLocked}
                                                                        title={on ? 'Cliquer pour retirer ce niveau' : 'Cliquer pour activer ce niveau'}
                                                                    >
                                                                        {n.code}
                                                                    </button>
                                                                )
                                                            })}
                                                        </div>
                                                    </td>

                                                    {/* Cellules Base/Surco */}
                                                    {niveaux.map(n => {
                                                        const enabled = hasLevel(a.id, n.id)
                                                        const base = cellVal(a.id, n.id, 'base')
                                                        const surc = cellVal(a.id, n.id, 'surco')

                                                        function RenderVal({ v }) {
                                                            const hasV = (v.value || '').trim().length > 0
                                                            const hasE = (v.expression || '').trim().length > 0
                                                            if (!hasV && !hasE) return <span className="opacity-30">—</span>
                                                            return (
                                                                <div className="min-h-8">
                                                                    {hasV && <div className="font-mono text-xs break-words">{v.value}</div>}
                                                                    {hasE && (
                                                                        <div className="text-[11px] opacity-70 break-words" title={v.expression}>
                                                                            {v.expression}
                                                                        </div>
                                                                    )}
                                                                </div>
                                                            )
                                                        }

                                                        function renderOne(kind, v) {
                                                            const isEditing =
                                                                editingCell &&
                                                                editingCell.actId === a.id &&
                                                                editingCell.nivId === n.id &&
                                                                editingCell.kind === kind

                                                            if (!enabled) return <span className="opacity-30">—</span>
                                                            if (isActLocked) return <RenderVal v={v} />

                                                            return (
                                                                <div className="min-h-10">
                                                                    {isEditing ? (
                                                                        <div className="space-y-1">
                                                                            <input
                                                                                className="input input-xs input-bordered w-full font-mono"
                                                                                placeholder="value"
                                                                                autoFocus
                                                                                value={draft.value}
                                                                                onChange={e => setDraft(d => ({ ...d, value: e.target.value }))}
                                                                                onKeyDown={e => {
                                                                                    if (e.key === 'Escape') cancelEdit()
                                                                                }}
                                                                            />
                                                                            <div className="join">
                                                                                <input
                                                                                    className="input input-xs input-bordered w-full join-item"
                                                                                    placeholder="expression"
                                                                                    value={draft.expression}
                                                                                    onChange={e => setDraft(d => ({ ...d, expression: e.target.value }))}
                                                                                    onKeyDown={e => {
                                                                                        if (e.key === 'Escape') cancelEdit()
                                                                                        if (e.key === 'Enter' && !e.shiftKey) {
                                                                                            e.preventDefault()
                                                                                            saveEdit()
                                                                                        }
                                                                                    }}
                                                                                />
                                                                                <button
                                                                                    type="button"
                                                                                    className="btn btn-xs btn-success join-item"
                                                                                    onClick={saveEdit}
                                                                                    title="Valider"
                                                                                >
                                                                                    ✅
                                                                                </button>
                                                                                <button
                                                                                    type="button"
                                                                                    className="btn btn-xs join-item"
                                                                                    onClick={cancelEdit}
                                                                                    title="Annuler"
                                                                                >
                                                                                    ✖
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    ) : (
                                                                        <div className="flex items-start gap-2">
                                                                            <div className="flex-1">
                                                                                <RenderVal v={v} />
                                                                            </div>
                                                                            <button
                                                                                type="button"
                                                                                className="btn btn-ghost btn-xs"
                                                                                title="Éditer"
                                                                                onClick={() => startEdit(a.id, n.id, kind)}
                                                                            >
                                                                                ✏️
                                                                            </button>
                                                                        </div>
                                                                    )}
                                                                </div>
                                                            )
                                                        }

                                                        return (
                                                            <Fragment key={`${a.id}-${n.id}`}>
                                                                <td>{renderOne('base', base)}</td>
                                                                <td>{renderOne('surco', surc)}</td>
                                                            </Fragment>
                                                        )
                                                    })}
                                                </tr>
                                            )
                                        })}
                                    </Fragment>
                                )
                            })
                        )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

/* =========================
   (Optionnel) Mini éditeur de cellule autonome
========================= */
function CellEditor({ value, onChangeValue, onChangeExpr }) {
    return (
        <div className="space-y-1">
            <input
                className="input input-xs input-bordered w-full font-mono"
                placeholder="value"
                value={value?.value || ''}
                onChange={e => onChangeValue(e.target.value)}
                onKeyDown={e => {
                    if (e.key === 'Escape') e.currentTarget.blur()
                }}
            />
            <input
                className="input input-xs input-bordered w-full"
                placeholder="expression"
                value={value?.expression || ''}
                onChange={e => onChangeExpr(e.target.value)}
                onKeyDown={e => {
                    if (e.key === 'Escape') e.currentTarget.blur()
                }}
            />
        </div>
    )
}
