'use client'

import Link from 'next/link'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useRefOffers, useRefCatalogues } from '@/providers/AppDataProvider'
import {Copy, SquarePen, Trash2, Columns3Cog} from "lucide-react";


/**
 * Page Next.js (JSX) — Administration des CATALOGUES par OFFRE
 * Schéma catalogue:
 *   { id, offre_id, risque (≤50, required), annee (int), version (≤20, required), status, valid_from (YYYY-MM-DD), valid_to (YYYY-MM-DD) }
 * Règle métier recommandée: unicité par (offre_id, risque, annee, version) insensible à la casse.
 *
 * Persistance via AppDataProvider (localStorage sous-jacent):
 *   - Offres:      'app:offres_v1'              (hook: useRefOffers)
 *   - Catalogues:  'app:catalogues_v1'          (hook: useRefCatalogues)
 *
 * Emplacement suggéré: app/catalogues/page.jsx
 */
export default function CataloguesPage() {
    const LS_OFFRES = 'app:offres_v1'
    const LS_CATALOGUES = 'app:catalogues_v1'

    const { refOffers } = useRefOffers()
    const { refCatalogues, setRefCatalogues } = useRefCatalogues()

    const [mounted, setMounted] = useState(false)
    const [offerFilter, setOfferFilter] = useState('all') // 'all' | offreId
    const [query, setQuery] = useState('')
    const [yearFilter, setYearFilter] = useState('all') // 'all' | numeric string
    const [statusFilter, setStatusFilter] = useState('all')
    const [onlyActive, setOnlyActive] = useState(false)
    const [sortNewestFirst, setSortNewestFirst] = useState(true)
    const [toast, setToast] = useState(null) // {type:'success'|'error'|'info', msg}

    const upsertDialogRef = useRef(null)
    const deleteDialogRef = useRef(null)

    const [editing, setEditing] = useState(null) // catalogue en édition
    const [candidateDelete, setCandidateDelete] = useState(null)

    useEffect(() => { setMounted(true) }, [])

    // ===== Utils =====
    function uuid() {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID()
        return 'id-' + Math.random().toString(36).slice(2) + Date.now().toString(36)
    }

    function showToast(type, msg) {
        setToast({ type, msg })
        setTimeout(() => setToast(null), 2500)
    }

    const offerMap = useMemo(() => new Map(refOffers.map((o) => [o.id, o])), [refOffers])

    function normalizeDateStr(s) {
        const t = String(s || '').trim()
        if (!t) return ''
        // autoriser formats YYYY-MM-DD, YYYY/MM/DD
        const d = new Date(t)
        if (isNaN(d.getTime())) return ''
        const yyyy = d.getFullYear()
        const mm = String(d.getMonth() + 1).padStart(2, '0')
        const dd = String(d.getDate()).padStart(2, '0')
        return `${yyyy}-${mm}-${dd}`
    }

    function isActive(c) {
        if (!c) return false
        if (String(c.status || '').toLowerCase() !== 'active') return false
        const today = new Date()
        const fromOk = !c.valid_from || new Date(c.valid_from) <= today
        const toOk = !c.valid_to || new Date(c.valid_to) >= today
        return fromOk && toOk
    }

    // Nettoyage + unicité {offre_id, risque, annee, version}
    function sanitizeCatalogues(arr) {
        const map = new Map()
        for (const raw of arr || []) {
            if (!raw) continue
            const item = {
                id: raw.id || uuid(),
                offre_id: raw.offre_id,
                risque: String(raw.risque || '').trim(),
                annee: Number.isFinite(Number(raw.annee)) ? Number(raw.annee) : undefined,
                version: String(raw.version || '').trim(),
                status: String(raw.status || '').trim(),
                valid_from: normalizeDateStr(raw.valid_from),
                valid_to: normalizeDateStr(raw.valid_to),
            }
            if (!item.offre_id || !offerMap.has(item.offre_id)) continue
            if (!item.risque || !item.version) continue
            const k = `${item.offre_id}::${item.risque.toLowerCase()}::${item.annee ?? ''}::${item.version.toLowerCase()}`
            map.set(k, item)
        }
        return Array.from(map.values())
    }

    // ===== Derived data for filters =====
    const yearsAvailable = useMemo(() => {
        const set = new Set()
        for (const c of refCatalogues) if (Number.isFinite(Number(c.annee))) set.add(Number(c.annee))
        return Array.from(set).sort((a, b) => b - a)
    }, [refCatalogues])

    const statusesAvailable = useMemo(() => {
        const set = new Set()
        for (const c of refCatalogues) {
            const s = String(c.status || '').trim()
            if (s) set.add(s)
        }
        // suggestions par défaut si vide
        const arr = Array.from(set)
        return arr.length ? arr : ['draft', 'active', 'archived']
    }, [refCatalogues])

    // ===== Sélecteur principal =====
    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase()
        let base = refCatalogues
            .filter((c) => offerFilter === 'all' ? true : c.offre_id === offerFilter)
            .filter((c) => yearFilter === 'all' ? true : String(c.annee || '') === String(yearFilter))
            .filter((c) => statusFilter === 'all' ? true : String(c.status || '').toLowerCase() === String(statusFilter).toLowerCase())
            .filter((c) => onlyActive ? isActive(c) : true)

        // recherche plein texte (risque, version, status)
        base = base.filter((c) => {
            if (!q) return true
            return (
                String(c.risque || '').toLowerCase().includes(q) ||
                String(c.version || '').toLowerCase().includes(q) ||
                String(c.status || '').toLowerCase().includes(q)
            )
        })

        // tri multi-niveaux
        base.sort((a, b) => {
            if (offerFilter === 'all') {
                const sa = offerMap.get(a.offre_id)?.code || ''
                const sb = offerMap.get(b.offre_id)?.code || ''
                const s = sa.localeCompare(sb)
                if (s !== 0) return s
            }
            // année desc/asc puis version alpha
            const yearCmp = (Number(b.annee || 0) - Number(a.annee || 0)) * (sortNewestFirst ? 1 : -1)
            if (yearCmp !== 0) return yearCmp
            return (String(a.version || '').localeCompare(String(b.version || ''))) * (sortNewestFirst ? 1 : -1)
        })

        return base
    }, [refCatalogues, offerFilter, yearFilter, statusFilter, onlyActive, query, sortNewestFirst, offerMap])

    // ===== CRUD =====
    function openCreate() {
        const defaultOfferId = offerFilter !== 'all' ? offerFilter : (refOffers[0]?.id || '')
        setEditing({ id: null, offre_id: defaultOfferId, risque: '', annee: new Date().getFullYear(), version: '', status: 'draft', valid_from: '', valid_to: '' })
        upsertDialogRef.current?.showModal()
    }

    function openEdit(row) {
        setEditing({ ...row })
        upsertDialogRef.current?.showModal()
    }

    function submitUpsert(e) {
        e?.preventDefault?.()
        if (!editing) return

        const offre_id = String(editing.offre_id || '')
        if (!offre_id || !offerMap.has(offre_id)) return showToast('error', 'Offre requise')

        const risque = String(editing.risque || '').trim()
        if (!risque) return showToast('error', 'Le risque est requis')
        if (risque.length > 50) return showToast('error', 'Risque ≤ 50 caractères')

        const version = String(editing.version || '').trim()
        if (!version) return showToast('error', 'La version est requise')
        if (version.length > 20) return showToast('error', 'Version ≤ 20 caractères')

        const annee = editing.annee === '' ? undefined : Number(editing.annee)
        if (editing.annee !== '' && !Number.isFinite(annee)) return showToast('error', "L'année doit être un nombre")

        const status = String(editing.status || '').trim()
        const valid_from = normalizeDateStr(editing.valid_from)
        const valid_to = normalizeDateStr(editing.valid_to)

        // Unicité
        const duplicate = refCatalogues.find((c) =>
            c.offre_id === offre_id &&
            String(c.risque).toLowerCase() === risque.toLowerCase() &&
            String(c.version).toLowerCase() === version.toLowerCase() &&
            String(c.annee || '') === String(annee || '') &&
            c.id !== editing.id
        )
        if (duplicate) return showToast('error', 'Un catalogue identique existe déjà pour cette offre')

        if (!editing.id) {
            const created = { id: uuid(), offre_id, risque, annee, version, status, valid_from, valid_to }
            const next = sanitizeCatalogues([...refCatalogues, created])
            setRefCatalogues(next)
            showToast('success', 'Catalogue créé')
        } else {
            const nextArr = refCatalogues.map((c) => (c.id === editing.id ? { ...c, offre_id, risque, annee, version, status, valid_from, valid_to } : c))
            const next = sanitizeCatalogues(nextArr)
            setRefCatalogues(next)
            showToast('success', 'Catalogue mis à jour')
        }

        upsertDialogRef.current?.close()
        setEditing(null)
    }

    function requestDelete(row) {
        setCandidateDelete(row)
        deleteDialogRef.current?.showModal()
    }

    function confirmDelete() {
        if (!candidateDelete) return
        setRefCatalogues(refCatalogues.filter((c) => c.id !== candidateDelete.id))
        showToast('success', 'Catalogue supprimé')
        deleteDialogRef.current?.close()
        setCandidateDelete(null)
    }

    function cancelDelete() {
        deleteDialogRef.current?.close()
        setCandidateDelete(null)
    }

    function duplicateAsNew(row) {
        const copy = { ...row, id: null, version: `${row.version}-COPY` }
        setEditing(copy)
        upsertDialogRef.current?.showModal()
    }

    if (!mounted) {
        return (
            <div className="p-6">
                <div className="skeleton h-8 w-64 mb-4"></div>
                <div className="skeleton h-5 w-96 mb-2"></div>
                <div className="skeleton h-5 w-80"></div>
            </div>
        )
    }

    if (refOffers.length === 0) {
        return (
            <div className="p-6">
                <div className="alert alert-warning max-w-2xl">
                    <span>Aucune offre trouvée. Crée d'abord des offres (<span className="font-mono">{LS_OFFRES}</span>) avant d'ajouter des catalogues.</span>
                </div>
            </div>
        )
    }

    return (
        <div className="p-4 md:p-6 lg:p-8 space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between gap-2">
                <h1 className="text-2xl font-bold">Administration — Catalogues</h1>
                <div className="flex gap-2">
                    <button className="btn btn-primary" onClick={openCreate}>+ Nouveau catalogue</button>
                    {/* Import/Export optionnels ici si besoin */}
                </div>
            </div>

            {/* Toolbar */}
            <div className="flex flex-col xl:flex-row xl:items-center gap-2">
                <label className="floating-label w-full sm:w-64">
                    <span>Filtrer par offre</span>
                    <select className="select select-bordered" value={offerFilter} onChange={(e) => setOfferFilter(e.target.value)}>
                        <option value="all">Toutes les offres</option>
                        {refOffers.map((o) => (
                            <option key={o.id} value={o.id}>{o.code} — {o.libelle || '—'}</option>
                        ))}
                    </select>
                </label>

                <label className="floating-label w-full sm:w-40">
                    <span>Année</span>
                    <select className="select select-bordered" value={yearFilter} onChange={(e) => setYearFilter(e.target.value)}>
                        <option value="all">Toutes</option>
                        {yearsAvailable.map((y) => (
                            <option key={y} value={y}>{y}</option>
                        ))}
                    </select>
                </label>

                <label className="floating-label w-full sm:w-48">
                    <span>Status</span>
                    <select className="select select-bordered" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                        <option value="all">Tous</option>
                        {statusesAvailable.map((s) => (
                            <option key={s} value={s}>{s}</option>
                        ))}
                    </select>
                </label>

                <label className="floating-label w-full xl:w-96 xl:ml-2">
                    <span>Rechercher</span>
                    <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        type="text"
                        className="input input-bordered w-full font-mono"
                        placeholder="risque / version / status…"
                    />
                </label>

                <div className="xl:ml-auto flex items-center gap-4">
                    <label className="label cursor-pointer gap-2">
                        <span className="label-text">Actifs seulement</span>
                        <input type="checkbox" className="toggle" checked={onlyActive} onChange={() => setOnlyActive((v) => !v)} />
                    </label>
                    <label className="label cursor-pointer gap-2">
                        <span className="label-text">Plus récents d'abord</span>
                        <input type="checkbox" className="toggle" checked={sortNewestFirst} onChange={() => setSortNewestFirst((v) => !v)} />
                    </label>
                </div>
            </div>

            {/* Content */}
            <div className="card bg-base-100 shadow-md">
                <div className="card-body p-0">
                    <div className="overflow-x-auto">
                        <table className="table table-zebra">
                            <thead>
                            <tr>
                                <th style={{ width: 160 }}>Offre</th>
                                <th style={{ width: 140 }}>Risque</th>
                                <th style={{ width: 100 }}>Année</th>
                                <th style={{ width: 120 }}>Version</th>
                                <th style={{ width: 120 }}>Status</th>
                                <th style={{ width: 100 }}>Validité</th>
                                <th className="text-right" style={{ width: 50 }}>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            {filtered.length === 0 && (
                                <tr>
                                    <td colSpan={7}>
                                        <div className="p-6 text-center opacity-70">Aucun catalogue. Cliquez sur « Nouveau catalogue » pour commencer.</div>
                                    </td>
                                </tr>
                            )}

                            {filtered.map((c) => {
                                const offer = offerMap.get(c.offre_id)
                                return (
                                    <tr key={c.id}>
                                        <td>
                                            <div className="badge badge-outline">{offer ? (offer.code || '—') : '—'}</div>
                                        </td>
                                        <td><div className="font-mono">{c.risque}</div></td>
                                        <td>{c.annee ?? '—'}</td>
                                        <td><div className="font-mono">{c.version}</div></td>
                                        <td>
                                            {String(c.status || '') ? (
                                                <span className={`badge ${String(c.status).toLowerCase() === 'active' ? 'badge-success' : String(c.status).toLowerCase() === 'archived' ? 'badge-ghost' : ''}`}>{c.status}</span>
                                            ) : (
                                                <span className="badge">—</span>
                                            )}
                                        </td>
                                        <td>
                                            <div className="flex flex-col gap-1">
                                                <span className="text-sm">{c.valid_from || '—'} → {c.valid_to || '—'}</span>
                                                {/*{*/}
                                                {/*    isActive(c) &&*/}
                                                {/*    <span className="badge badge-success badge-sm w-fit">Actif</span>*/}
                                                {/*}*/}
                                            </div>
                                        </td>
                                        <td className="text-right">
                                            <div className="join justify-end">
                                                <button className="btn btn-sm join-item" onClick={() => openEdit(c)}>
                                                    <SquarePen size={16} />
                                                </button>
                                                <button className="btn btn-sm join-item" onClick={() => duplicateAsNew(c)}>
                                                    <Copy size={16} />
                                                </button>

                                                {/* ✅ Redirection directe vers la config du catalogue */}
                                                <Link
                                                    href={`/catalogues/${c.id}/configure`}
                                                    className="btn btn-sm join-item"
                                                >
                                                    <Columns3Cog size={16} />
                                                </Link>
                                                {/* ✅ Redirection directe vers la config du catalogue */}
                                                <Link
                                                    href={`/catalogues/${c.id}/configure/inline?catalogueId=${encodeURIComponent(c.id)}`}
                                                    className="btn btn-sm join-item"
                                                >
                                                    <Columns3Cog size={16} />
                                                </Link>
                                                <button className="btn btn-sm btn-error join-item" onClick={() => requestDelete(c)}>
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                )
                            })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* Dialog: Create/Update */}
            <dialog ref={upsertDialogRef} className="modal">
                <div className="modal-box w-11/12 max-w-4xl">
                    <h3 className="font-bold text-lg">{editing?.id ? 'Modifier un catalogue' : 'Nouveau catalogue'}</h3>
                    <fieldset className="fieldset bg-base-200 border-base-300 rounded-box border p-4">
                        <form className="mt-4" onSubmit={submitUpsert}>
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                                <label className="floating-label md:col-span-5">
                                    <span>Offre <span className="text-error">*</span></span>
                                    <select
                                        className="select select-bordered w-full"
                                        value={editing?.offre_id ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, offre_id: e.target.value }))}
                                        required
                                    >
                                        <option value="" disabled>Choisir une offre…</option>
                                        {refOffers.map((o) => (
                                            <option key={o.id} value={o.id}>{o.code} — {o.libelle || '—'}</option>
                                        ))}
                                    </select>
                                </label>

                                <label className="floating-label md:col-span-3">
                                    <span>Risque <span className="text-error">*</span></span>
                                    <input
                                        type="text"
                                        className="input input-bordered w-full"
                                        value={editing?.risque ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, risque: e.target.value }))}
                                        placeholder="Ex: SANTE, PREVOYANCE…"
                                        maxLength={50}
                                        required
                                    />
                                </label>

                                <label className="floating-label md:col-span-2">
                                    <span>Année</span>
                                    <input
                                        type="number"
                                        min={1900}
                                        max={2100}
                                        className="input input-bordered w-full"
                                        value={editing?.annee ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, annee: e.target.value === '' ? '' : Number(e.target.value) }))}
                                        placeholder={String(new Date().getFullYear())}
                                    />
                                </label>

                                <label className="floating-label md:col-span-2">
                                    <span>Version <span className="text-error">*</span></span>
                                    <input
                                        type="text"
                                        className="input input-bordered w-full font-mono"
                                        value={editing?.version ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, version: e.target.value }))}
                                        placeholder="v1, 1.0, 2025-01…"
                                        maxLength={20}
                                        required
                                    />
                                </label>

                                <label className="floating-label md:col-span-2">
                                    <span>Status</span>
                                    <input
                                        type="text"
                                        className="input input-bordered w-full"
                                        value={editing?.status ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, status: e.target.value }))}
                                        placeholder="draft / active / archived…"
                                    />
                                </label>

                                <label className="floating-label md:col-span-3">
                                    <span>Validité — du</span>
                                    <input
                                        type="date"
                                        className="input input-bordered w-full"
                                        value={editing?.valid_from ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, valid_from: e.target.value }))}
                                    />
                                </label>
                                <label className="floating-label md:col-span-3">
                                    <span>Validité — au</span>
                                    <input
                                        type="date"
                                        className="input input-bordered w-full"
                                        value={editing?.valid_to ?? ''}
                                        onChange={(e) => setEditing((v) => ({ ...v, valid_to: e.target.value }))}
                                    />
                                </label>
                            </div>

                            <div className="modal-action mt-6">
                                <button type="button" className="btn btn-ghost" onClick={() => { upsertDialogRef.current?.close(); setEditing(null) }}>Annuler</button>
                                <button type="submit" className="btn btn-primary">Enregistrer</button>
                            </div>
                        </form>
                    </fieldset>
                </div>
                <form method="dialog" className="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>

            {/* Dialog: Delete confirm */}
            <dialog ref={deleteDialogRef} className="modal">
                <div className="modal-box">
                    <h3 className="font-bold text-lg">Supprimer le catalogue ?</h3>
                    <p className="py-2">Cette action est irréversible.</p>
                    <div className="bg-base-200 rounded p-3 font-mono">
                        {candidateDelete ? (
                            <>
                                <div><span className="opacity-70">Offre:</span> {offerMap.get(candidateDelete.offre_id)?.code || '—'}</div>
                                <div><span className="opacity-70">Risque:</span> {candidateDelete.risque}</div>
                                <div><span className="opacity-70">Année:</span> {candidateDelete.annee ?? '—'}</div>
                                <div><span className="opacity-70">Version:</span> {candidateDelete.version}</div>
                            </>
                        ) : '—'}
                    </div>
                    <div className="modal-action">
                        <button className="btn" onClick={cancelDelete}>Annuler</button>
                        <button className="btn btn-error" onClick={confirmDelete}>Supprimer</button>
                    </div>
                </div>
                <form method="dialog" className="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>

            {/* Toast */}
            {toast && (
                <div className="toast">
                    <div className={`alert ${toast.type === 'success' ? 'alert-success' : toast.type === 'error' ? 'alert-error' : 'alert-info'}`}>
                        <span>{toast.msg}</span>
                    </div>
                </div>
            )}

            {/* Footer helper */}
            <div className="opacity-60 text-xs">
                <span className="font-mono">localStorage</span> clés: <span className="font-mono">{LS_OFFRES}</span> (offres), <span className="font-mono">{LS_CATALOGUES}</span> (catalogues) — {refCatalogues.length} catalogues
            </div>
        </div>
    )
}