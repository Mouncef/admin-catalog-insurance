'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRefOffers, useRefCatalogues, useRefModules, useRefCategories, useRefActs, useRefNiveau } from '@/providers/AppDataProvider'
import { useGroupStore, sanitizeGroupes, sanitizeMembres, sanitizeGvaleurs, uuid } from '@/hooks/useGroupData'
import GroupeModal from '@/components/regroupements/GroupeModal'

export default function RegroupementsPage(){
    // Référentiels via TON provider
    const { refOffers } = useRefOffers()
    const { refCatalogues } = useRefCatalogues()
    const { refModules } = useRefModules()
    const { refCategories } = useRefCategories()
    const { refActs } = useRefActs()
    const { refNiveau } = useRefNiveau()

    // Maps
    const offerMap = useMemo(()=> new Map(refOffers.map(o=>[o.id,o])), [refOffers])
    const catalogueMap = useMemo(()=> new Map(refCatalogues.map(c=>[c.id,c])), [refCatalogues])
    const moduleMap = useMemo(()=> new Map(refModules.map(m=>[m.id,m])), [refModules])
    const niveauMap = useMemo(()=> new Map(refNiveau.map(n=>[n.id,n])), [refNiveau])

    // Dérivés
    const categoriesByModule = useMemo(()=>{
        const by = new Map()
        for (const c of refCategories){
            if (!by.has(c.ref_module_id)) by.set(c.ref_module_id, [])
            by.get(c.ref_module_id).push(c)
        }
        for (const [,arr] of by) arr.sort((a,b)=>(a.ordre||0)-(b.ordre||0) || a.code.localeCompare(b.code))
        return by
    }, [refCategories])
    const actsByCategory = useMemo(()=>{
        const by = new Map()
        for (const a of refActs){
            if (!by.has(a.ref_categorie_id)) by.set(a.ref_categorie_id, [])
            by.get(a.ref_categorie_id).push(a)
        }
        for (const [,arr] of by) arr.sort((a,b)=>(a.ordre||0)-(b.ordre||0) || a.code.localeCompare(b.code))
        return by
    }, [refActs])

    // Store basé MultiStorage
    const refs = { catalogueMap, moduleMap, niveauMap }
    const { groupes, setGroupes, membres, setMembres, gvaleurs, setGvaleurs } = useGroupStore(refs)

    // Filtres
    const [offerFilter, setOfferFilter] = useState('all')
    const [catalogueFilter, setCatalogueFilter] = useState('all')
    const [moduleFilter, setModuleFilter] = useState('all')
    const [query, setQuery] = useState('')

    const upsertDialogRef = useRef(null)
    const [modalPayload, setModalPayload] = useState(null)
    const [toast, setToast] = useState(null)
    const [candidateDelete, setCandidateDelete] = useState(null)

    function showToast(type,msg){ setToast({type,msg}); setTimeout(()=>setToast(null), 2500) }

    useEffect(()=>{ if (offerFilter==='all') setCatalogueFilter('all') }, [offerFilter])

    const filteredGroupes = useMemo(()=>{
        return groupes.filter(g => (offerFilter==='all' ? true : catalogueMap.get(g.catalogue_id)?.offre_id === offerFilter)
            && (catalogueFilter==='all' ? true : g.catalogue_id===catalogueFilter)
            && (moduleFilter==='all' ? true : g.ref_module_id===moduleFilter)
            && (query.trim() ? g.nom.toLowerCase().includes(query.trim().toLowerCase()) : true))
    }, [groupes, offerFilter, catalogueFilter, moduleFilter, query, catalogueMap])

    function openCreate(){
        const defaultCatalogueId = catalogueFilter!=='all' ? catalogueFilter : (refCatalogues[0]?.id || '')
        const defaultModuleId = moduleFilter!=='all' ? moduleFilter : (refModules[0]?.id || '')
        const defaultNiv = refNiveau[0]?.id || ''
        setModalPayload({
            groupe: { id:null, catalogue_id: defaultCatalogueId, ref_module_id: defaultModuleId, nom:'', niveau_id: defaultNiv, priorite: 100 },
            baseVal: { mode:'texte_libre', base:'inconnu', unite:'inconnu', taux:'', montant:'' },
            surcoVal: { mode:'texte_libre', base:'inconnu', unite:'inconnu', taux:'', montant:'' },
            membersSet: new Set(),
        })
        upsertDialogRef.current?.showModal()
    }

    function openEdit(g){
        const base = gvaleurs.find(v=>v.groupe_id===g.id && v.kind==='base')
        const surc = gvaleurs.find(v=>v.groupe_id===g.id && v.kind==='surco')
        const mem  = new Set(membres.filter(m=>m.groupe_id===g.id).map(m=>m.act_id))
        setModalPayload({ groupe:{...g}, baseVal: base?{...base}:{mode:'texte_libre',base:'inconnu',unite:'inconnu'}, surcoVal: surc?{...surc}:{mode:'texte_libre',base:'inconnu',unite:'inconnu'}, membersSet: mem })
        upsertDialogRef.current?.showModal()
    }

    function handleSubmit(payload){
        const g = payload.groupe
        if (!g.catalogue_id || !catalogueMap.has(g.catalogue_id)) return showToast('error','Catalogue requis')
        if (!g.ref_module_id || !moduleMap.has(g.ref_module_id)) return showToast('error','Module requis')
        if (!g.niveau_id || !niveauMap.has(g.niveau_id)) return showToast('error','Niveau requis')
        const nom = String(g.nom||'').trim(); if (!nom) return showToast('error','Nom requis')

        let gid = g.id || uuid()
        const nextGroupes = g.id ? groupes.map(x=> x.id===g.id ? { ...g, id: gid, nom, priorite: Number(g.priorite)||100 } : x)
            : [...groupes, { ...g, id: gid, nom, priorite: Number(g.priorite)||100 }]
        setGroupes(nextGroupes)

        const kept  = membres.filter(m=>m.groupe_id!==gid)
        const added = Array.from(payload.membersSet).map(actId=> ({ groupe_id: gid, act_id: actId }))
        setMembres([...kept, ...added])

        const normalizeVal = (v, kind) => ({
            id: v.id || uuid(), groupe_id: gid, kind,
            mode: v.mode || 'texte_libre', base: v.base || 'inconnu',
            taux: v.taux===''||v.taux===null||typeof v.taux==='undefined'? null:Number(v.taux),
            montant: v.montant===''||v.montant===null||typeof v.montant==='undefined'? null:Number(v.montant),
            unite: v.unite || 'inconnu',
            plafond_montant: v.plafond_montant===''||v.plafond_montant===null||typeof v.plafond_montant==='undefined'? null:Number(v.plafond_montant),
            plafond_unite: v.plafond_unite || null,
            periodicite: v.periodicite || null,
            condition_json: v.condition_json ?? null,
            expression: v.expression || '', commentaire: v.commentaire || ''
        })
        const rest = gvaleurs.filter(v=>v.groupe_id!==gid)
        setGvaleurs([...rest, normalizeVal(payload.baseVal,'base'), normalizeVal(payload.surcoVal,'surco')])

        showToast('success', g.id ? 'Regroupement mis à jour' : 'Regroupement créé')
        upsertDialogRef.current?.close(); setModalPayload(null)
    }

    function requestDelete(g){ setCandidateDelete(g) }
    function confirmDelete(){ if(!candidateDelete) return; setGroupes(groupes.filter(x=>x.id!==candidateDelete.id)); setMembres(membres.filter(m=>m.groupe_id!==candidateDelete.id)); setGvaleurs(gvaleurs.filter(v=>v.groupe_id!==candidateDelete.id)); setCandidateDelete(null); showToast('success','Regroupement supprimé') }

    if (refOffers.length===0 || refCatalogues.length===0 || refModules.length===0 || refCategories.length===0 || refActs.length===0 || refNiveau.length===0){
        return (<div className="p-6"><div className="alert alert-warning">Il manque des données référentielles (offres/catalogues/modules/categories/actes/niveaux).</div></div>)
    }

    return (
        <div className="p-4 md:p-6 lg:p-8 space-y-4">
            <div className="flex items-center justify-between gap-2">
                <h1 className="text-2xl font-bold">Configuration du catalogue — Regroupements d'actes</h1>
                <button className="btn btn-primary" onClick={openCreate}>+ Nouveau regroupement</button>
            </div>

            {/* Toolbar */}
            <Toolbar
                refOffers={refOffers}
                refCatalogues={refCatalogues}
                refModules={refModules}
                offerFilter={offerFilter}
                setOfferFilter={setOfferFilter}
                catalogueFilter={catalogueFilter}
                setCatalogueFilter={setCatalogueFilter}
                moduleFilter={moduleFilter}
                setModuleFilter={setModuleFilter}
                query={query}
                setQuery={setQuery}
            />

            {/* Liste */}
            <List
                rows={filteredGroupes}
                offerMap={offerMap}
                catalogueMap={catalogueMap}
                moduleMap={moduleMap}
                niveauMap={niveauMap}
                onEdit={openEdit}
                onDelete={requestDelete}
            />

            {/* Modal create / edit */}
            {modalPayload && (
                <GroupeModal
                    dialogRef={upsertDialogRef}
                    initial={modalPayload}
                    onSubmit={handleSubmit}
                    onCancel={()=>{ upsertDialogRef.current?.close(); setModalPayload(null) }}
                    catalogues={offerFilter==='all' ? refCatalogues : refCatalogues.filter(c=>c.offre_id===offerFilter)}
                    modules={refModules}
                    niveaux={refNiveau}
                    categoriesByModule={categoriesByModule}
                    actsByCategory={actsByCategory}
                />
            )}

            {/* Delete dialog */}
            {candidateDelete && (
                <div className="modal modal-open">
                    <div className="modal-box">
                        <h3 className="font-bold text-lg">Supprimer le regroupement ?</h3>
                        <p className="py-2">Cette action est irréversible.</p>
                        <div className="bg-base-200 rounded p-3 font-mono">
                            <div><span className="opacity-70">Nom:</span> {candidateDelete.nom}</div>
                        </div>
                        <div className="modal-action">
                            <button className="btn" onClick={()=> setCandidateDelete(null)}>Annuler</button>
                            <button className="btn btn-error" onClick={confirmDelete}>Supprimer</button>
                        </div>
                    </div>
                </div>
            )}

            {toast && (<div className="toast"><div className={`alert ${toast.type==='success' ? 'alert-success' : toast.type==='error' ? 'alert-error' : 'alert-info'}`}><span>{toast.msg}</span></div></div>)}

            <div className="opacity-60 text-xs">MultiStorage keys: <span className="font-mono">app:groupe_actes_v1</span>, <span className="font-mono">app:groupe_actes_membre_v1</span>, <span className="font-mono">app:groupe_valeur_v1</span> — {groupes.length} regroupements</div>
        </div>
    )
}

function Toolbar({ refOffers, refCatalogues, refModules, offerFilter, setOfferFilter, catalogueFilter, setCatalogueFilter, moduleFilter, setModuleFilter, query, setQuery }){
    return (
        <div className="flex flex-col xl:flex-row xl:items-center gap-2">
            <label className="floating-label w-full sm:w-64">
                <span>Offre</span>
                <select className="select select-bordered" value={offerFilter} onChange={(e)=>{ setOfferFilter(e.target.value); setCatalogueFilter('all') }}>
                    <option value="all">Toutes</option>
                    {refOffers.map(o=> <option key={o.id} value={o.id}>{o.code} — {o.libelle||'—'}</option>)}
                </select>
            </label>
            <label className="floating-label w-full sm:w-72">
                <span>Catalogue</span>
                <select className="select select-bordered" value={catalogueFilter} onChange={(e)=> setCatalogueFilter(e.target.value)}>
                    <option value="all">Tous</option>
                    {(offerFilter==='all' ? refCatalogues : refCatalogues.filter(c=>c.offre_id===offerFilter)).map(c => (
                        <option key={c.id} value={c.id}>{[c.risque, c.annee, c.version].filter(Boolean).join(' · ')}</option>
                    ))}
                </select>
            </label>
            <label className="floating-label w-full sm:w-72">
                <span>Module</span>
                <select className="select select-bordered" value={moduleFilter} onChange={(e)=> setModuleFilter(e.target.value)}>
                    <option value="all">Tous</option>
                    {refModules.map(m=> <option key={m.id} value={m.id}>{m.code} — {m.libelle||'—'}</option>)}
                </select>
            </label>
            <label className="floating-label w-full xl:w-96 xl:ml-2">
                <span>Rechercher un regroupement</span>
                <input className="input input-bordered w-full" value={query} onChange={(e)=> setQuery(e.target.value)} placeholder="nom…"/>
            </label>
        </div>
    )
}

function List({ rows, offerMap, catalogueMap, moduleMap, niveauMap, onEdit, onDelete }){
    return (
        <div className="card bg-base-100 shadow-md">
            <div className="card-body p-0">
                <div className="overflow-x-auto">
                    <table className="table table-zebra">
                        <thead>
                        <tr>
                            <th style={{width:160}}>Offre/Catalogue</th>
                            <th style={{width:140}}>Module</th>
                            <th>Nom</th>
                            <th style={{width:140}}>Niveau</th>
                            <th style={{width:120}}>Priorité</th>
                            <th className="text-right" style={{width:260}}>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rows.length===0 && (
                            <tr><td colSpan={6}><div className="p-6 text-center opacity-70">Aucun regroupement. Cliquez sur « Nouveau regroupement ».</div></td></tr>
                        )}
                        {rows.map(g=>{
                            const cat = catalogueMap.get(g.catalogue_id)
                            const off = offerMap.get(cat?.offre_id)
                            return (
                                <tr key={g.id}>
                                    <td>
                                        <div className="text-xs opacity-70">{off?.code || '—'}</div>
                                        <div className="font-mono">{[cat?.risque, cat?.annee, cat?.version].filter(Boolean).join(' · ')}</div>
                                    </td>
                                    <td><div className="badge badge-outline">{moduleMap.get(g.ref_module_id)?.code || '—'}</div></td>
                                    <td className="max-w-[460px]"><div className="truncate" title={g.nom}>{g.nom}</div></td>
                                    <td><div className="badge badge-ghost">{niveauMap.get(g.niveau_id)?.code || '—'}</div></td>
                                    <td>{g.priorite}</td>
                                    <td className="text-right">
                                        <div className="join justify-end">
                                            <button className="btn btn-sm join-item" onClick={()=> onEdit(g)}>Modifier</button>
                                            <button className="btn btn-sm btn-error join-item" onClick={()=> onDelete(g)}>Supprimer</button>
                                        </div>
                                    </td>
                                </tr>
                            )
                        })}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}