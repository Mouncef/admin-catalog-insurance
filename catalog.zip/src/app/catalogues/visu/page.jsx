'use client';

import React, { useEffect, useState } from 'react';
import { ArrowLeft, Eye } from 'lucide-react';
import offreService from "@/lib/api/offreService";

export default function OffreSelector({ onBack, onSelectOffre }) {
    const [offres, setOffres] = useState([]);
    const [selectedOffreId, setSelectedOffreId] = useState('');
    const [loading, setLoading] = useState(true);
    const [errorMsg, setErrorMsg] = useState('');

    const selectedOffre = offres.find((o) => o.id === selectedOffreId);

    const handleViewCatalog = () => {
        if (selectedOffre) onSelectOffre(selectedOffre);
    };

    return (
        <div className="max-w-2xl mx-auto">
            <div className="card bg-base-100 border border-base-300 shadow">
                <div className="card-body">
                    <div className="text-center space-y-1">
                        <h2 className="card-title flex items-center justify-center gap-2">
                            <Eye className="w-6 h-6" />
                            Visualisation du catalogue
                        </h2>
                        <p className="text-base-content/70">
                            Sélectionnez une offre pour afficher son catalogue de garanties
                        </p>
                    </div>

                    {errorMsg && (
                        <div className="alert alert-error mt-4">
                            <span>{errorMsg}</span>
                        </div>
                    )}

                    <div className="mt-6">
                        {loading ? (
                            <div className="text-center py-10">
                                <span className="loading loading-spinner loading-lg mb-3" />
                                <p className="text-base-content/70">Chargement des offres...</p>
                            </div>
                        ) : (
                            <>
                                <div className="form-control w-full">
                                    <label className="label">
                                        <span className="label-text font-medium">Choisir une offre</span>
                                    </label>
                                    <select
                                        className="select select-bordered w-full"
                                        value={selectedOffreId}
                                        onChange={(e) => setSelectedOffreId(e.target.value)}
                                    >
                                        <option value="" disabled>
                                            Sélectionnez une offre...
                                        </option>
                                        {offres.map((offre) => (
                                            <option key={offre.id} value={offre.id}>
                                                {offre.libelle} — {offre.catalogues[0].risque} • {offre.catalogues[0].annee}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                {selectedOffre && (
                                    <div className="card bg-primary/10 border border-primary/20 mt-6">
                                        <div className="card-body p-4">
                                            <div className="space-y-3">
                                                <div>
                                                    <h3 className="font-semibold text-primary">
                                                        {selectedOffre.libelle}
                                                    </h3>
                                                    {selectedOffre.note && (
                                                        <p className="text-sm text-base-content/70 mt-1">
                                                            {selectedOffre.note}
                                                        </p>
                                                    )}
                                                </div>

                                                <div className="flex items-center gap-2 flex-wrap">
                                                    <span className="badge badge-secondary">{selectedOffre.catalogues[0].risque}</span>
                                                    <span className="badge badge-outline">Année {selectedOffre.catalogues[0].annee}</span>
                                                    {selectedOffre.version_label && (
                                                        <span className="badge badge-outline">
                                  {selectedOffre.version_label}
                                </span>
                                                    )}
                                                </div>

                                                {selectedOffre.effective_from && (
                                                    <div className="text-sm text-base-content/70">
                                                        <span className="font-medium">Période:&nbsp;</span>
                                                        {new Date(selectedOffre.effective_from).toLocaleDateString('fr-FR')}
                                                        {selectedOffre.effective_to && (
                                                            <span>
                                    {' '}
                                                                → {new Date(selectedOffre.effective_to).toLocaleDateString('fr-FR')}
                                  </span>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                )}

                                <div className="flex justify-center pt-4">
                                    <button
                                        type="button"
                                        onClick={handleViewCatalog}
                                        disabled={!selectedOffreId}
                                        className="btn btn-primary btn-lg px-8 disabled:btn-disabled"
                                    >
                                        <Eye className="w-4 h-4 mr-2" />
                                        Visualiser le catalogue
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
