'use client'

import { Fragment, useMemo, useRef, useState, useEffect } from 'react'
import {
    useRefOffers,
    useRefCatalogues,
    useRefModules,
    useRefCategories,
    useRefActs,
    useRefNiveau,
    useCatModules,
} from '@/providers/AppDataProvider'
import { useGroupStore } from '@/hooks/useGroupData'

export default function VisualiserCataloguePage() {
    // Référentiels
    const { refOffers } = useRefOffers()
    const { refCatalogues } = useRefCatalogues()
    const { refModules } = useRefModules()
    const { refCategories } = useRefCategories()
    const { refActs } = useRefActs()
    const { refNiveau } = useRefNiveau()
    const { catModules } = useCatModules()

    // Maps
    const offerMap = useMemo(() => new Map(refOffers.map(o => [o.id, o])), [refOffers])
    const catalogueMap = useMemo(() => new Map(refCatalogues.map(c => [c.id, c])), [refCatalogues])
    const moduleMap = useMemo(() => new Map(refModules.map(m => [m.id, m])), [refModules])

    // Groupements par catégorie/module
    const categoriesByModule = useMemo(() => {
        const by = new Map()
        for (const c of refCategories) {
            if (!by.has(c.ref_module_id)) by.set(c.ref_module_id, [])
            by.get(c.ref_module_id).push(c)
        }
        for (const [, arr] of by) arr.sort((a,b)=>(a.ordre||0)-(b.ordre||0) || a.code.localeCompare(b.code))
        return by
    }, [refCategories])

    const actsByCategory = useMemo(() => {
        const by = new Map()
        for (const a of refActs) {
            if (!by.has(a.ref_categorie_id)) by.set(a.ref_categorie_id, [])
            by.get(a.ref_categorie_id).push(a)
        }
        for (const [, arr] of by) arr.sort((a,b)=>(a.ordre||0)-(b.ordre||0) || a.code.localeCompare(b.code))
        return by
    }, [refActs])

    // Store groupes/membres/valeurs
    const refs = { catalogueMap, moduleMap }
    const { groupes, membres, gvaleurs } = useGroupStore(refs)

    // Étapes : Offre -> Catalogue -> Modules visibles
    const [offerId, setOfferId] = useState('')
    const [catalogueId, setCatalogueId] = useState('')
    const cataloguesOfOffer = useMemo(() => offerId ? refCatalogues.filter(c => c.offre_id === offerId) : [], [offerId, refCatalogues])

    // Modules inclus (ordre visuel)
    const includedRows = useMemo(() => {
        if (!catalogueId) return []
        return (catModules || [])
            .filter(cm => cm.catalogue_id === catalogueId)
            .sort((a,b)=>(a.ordre??0)-(b.ordre??0) || (moduleMap.get(a.ref_module_id)?.code||'').localeCompare(moduleMap.get(b.ref_module_id)?.code||''))
    }, [catModules, catalogueId, moduleMap])
    const includedModules = useMemo(() => includedRows.map(r => moduleMap.get(r.ref_module_id)).filter(Boolean), [includedRows, moduleMap])

    const [activeModuleId, setActiveModuleId] = useState('')
    const moduleTabsName = useMemo(() => `view_mod_${Math.random().toString(36).slice(2)}`, [])

    useEffect(() => {
        if (!catalogueId) return
        if (includedModules.length === 0) { setActiveModuleId(''); return }
        if (!includedModules.find(m => m.id === activeModuleId)) {
            setActiveModuleId(includedModules[0].id)
        }
    }, [catalogueId, includedModules, activeModuleId])

    // Options d’affichage
    const [hideSurco, setHideSurco] = useState(false)
    const [hideEmptyRows, setHideEmptyRows] = useState(false)
    const [compact, setCompact] = useState(false)

    // 1) Sélection de l’offre
    if (!offerId) {
        return (
            <div className="p-6 max-w-3xl">
                <h1 className="text-2xl font-bold mb-4">Visualiser un catalogue</h1>
                <label className="floating-label w-full">
                    <span>Choisir une offre</span>
                    <select className="select select-bordered w-full" value={offerId} onChange={(e)=> setOfferId(e.target.value)}>
                        <option value="" disabled>— Sélectionner —</option>
                        {refOffers.map(o=> <option key={o.id} value={o.id}>{o.code} — {o.libelle||'—'}</option>)}
                    </select>
                </label>
                <div className="opacity-70 text-sm mt-2">Étape 1/2</div>
            </div>
        )
    }

    // 2) Sélection du catalogue de l’offre
    if (!catalogueId) {
        return (
            <div className="p-6 max-w-3xl">
                <h1 className="text-2xl font-bold mb-4">Offre: {offerMap.get(offerId)?.code}</h1>
                <label className="floating-label w-full">
                    <span>Choisir un catalogue</span>
                    <select className="select select-bordered w-full" value={catalogueId} onChange={(e)=> setCatalogueId(e.target.value)}>
                        <option value="" disabled>— Sélectionner —</option>
                        {cataloguesOfOffer.map(c=> (
                            <option key={c.id} value={c.id}>{[c.risque, c.annee, c.version].filter(Boolean).join(' · ')}</option>
                        ))}
                    </select>
                </label>
                <div className="mt-4">
                    <button className="btn" onClick={()=> setOfferId('')}>← Changer d'offre</button>
                </div>
                <div className="opacity-70 text-sm mt-2">Étape 2/2</div>
            </div>
        )
    }

    const headerCat = catalogueMap.get(catalogueId)
    const headerOffer = offerMap.get(offerId)

    return (
        <div className={`p-4 md:p-6 lg:p-8 space-y-4 ${compact ? 'text-sm' : ''}`}>
            {/* Header */}
            <div className="flex flex-wrap items-center justify-between gap-2 print:hidden">
                <div>
                    <h1 className="text-2xl font-bold">{headerOffer?.code} — {headerOffer?.libelle}</h1>
                    <div className="opacity-70">Catalogue: {[headerCat?.risque, headerCat?.annee, headerCat?.version].filter(Boolean).join(' · ')}</div>
                </div>
                <div className="join">
                    <button className="btn join-item" onClick={()=> setCatalogueId('')}>Changer de catalogue</button>
                    <button className="btn join-item" onClick={()=> setOfferId('')}>Changer d'offre</button>
                    <button className="btn join-item" onClick={()=> window.print()}>🖨️ Imprimer</button>
                </div>
            </div>

            {/* Options d’affichage */}
            <div className="card bg-base-100 shadow-sm print:hidden">
                <div className="card-body p-4">
                    <div className="flex flex-wrap gap-4 items-center">
                        <label className="label cursor-pointer gap-2">
                            <span className="label-text">Masquer Surco</span>
                            <input type="checkbox" className="toggle" checked={hideSurco} onChange={()=> setHideSurco(v=>!v)} />
                        </label>
                        <label className="label cursor-pointer gap-2">
                            <span className="label-text">Masquer lignes vides</span>
                            <input type="checkbox" className="toggle" checked={hideEmptyRows} onChange={()=> setHideEmptyRows(v=>!v)} />
                        </label>
                        <label className="label cursor-pointer gap-2">
                            <span className="label-text">Mode compact</span>
                            <input type="checkbox" className="toggle" checked={compact} onChange={()=> setCompact(v=>!v)} />
                        </label>
                    </div>
                </div>
            </div>

            {/* Onglets Modules (selon sélection/ordre catalogue) */}
            {includedModules.length === 0 ? (
                <div className="alert alert-info">Aucun module inclus dans ce catalogue.</div>
            ) : (
                <div className="tabs tabs-lift mt-2">
                    {includedModules.map((m, i) => {
                        const checked = activeModuleId ? activeModuleId===m.id : i===0
                        const rows = groupes.filter(g=> g.catalogue_id===catalogueId && g.ref_module_id===m.id)
                            .sort((a,b)=>(a.priorite||0)-(b.priorite||0) || a.nom.localeCompare(b.nom))
                        return (
                            <Fragment key={m.id}>
                                <label className="tab print:hidden">
                                    <input
                                        type="radio"
                                        name={moduleTabsName}
                                        checked={checked}
                                        onChange={()=> setActiveModuleId(m.id)}
                                    />
                                    {m.code}
                                </label>
                                <div className="tab-content bg-base-100 border-base-300 p-4">
                                    <ModuleViewer
                                        module={m}
                                        groupes={rows}
                                        niveaux={refNiveau}
                                        categoriesByModule={categoriesByModule}
                                        actsByCategory={actsByCategory}
                                        gvaleurs={gvaleurs}
                                        membres={membres}
                                        hideSurco={hideSurco}
                                        hideEmptyRows={hideEmptyRows}
                                    />
                                </div>
                            </Fragment>
                        )
                    })}
                </div>
            )}

            {/* Styles impression simples */}
            <style jsx global>{`
        @media print {
          .print\\:hidden { display: none !important; }
          .card, .tab-content { box-shadow: none !important; border: 0 !important; }
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}</style>
        </div>
    )
}

function ModuleViewer({
                          module,
                          groupes,
                          niveaux,
                          categoriesByModule,
                          actsByCategory,
                          gvaleurs,
                          membres,
                          hideSurco,
                          hideEmptyRows,
                      }) {
    const niveauxEnabled = useMemo(
        () => (niveaux||[]).filter(n => !!n.is_enabled).sort((a,b)=>(a.ordre||0)-(b.ordre||0)),
        [niveaux]
    )

    // index membres -> ordre affichage dans le groupe
    const orderByGroup = useMemo(() => {
        const map = new Map()
        for (const m of (membres || [])) {
            if (!map.has(m.groupe_id)) map.set(m.groupe_id, new Map())
            map.get(m.groupe_id).set(m.act_id, m.ordre || 1e9)
        }
        return map
    }, [membres])

    return (
        <div className="space-y-6">
            <div className="text-xl font-semibold">Module: {module?.code} — {module?.libelle}</div>

            {groupes.length===0 && <div className="alert">Aucun groupe pour ce module.</div>}

            {groupes.map(g => (
                <GroupMatrixView
                    key={g.id}
                    group={g}
                    module={module}
                    niveaux={niveauxEnabled}
                    categoriesByModule={categoriesByModule}
                    actsByCategory={actsByCategory}
                    gvaleurs={gvaleurs}
                    orderMap={orderByGroup.get(g.id) || new Map()}
                    hideSurco={hideSurco}
                    hideEmptyRows={hideEmptyRows}
                />
            ))}
        </div>
    )
}

function GroupMatrixView({
                             group,
                             module,
                             niveaux,
                             categoriesByModule,
                             actsByCategory,
                             gvaleurs,
                             orderMap,
                             hideSurco,
                             hideEmptyRows,
                         }) {
    // (actId,niveauId,kind)-> { value, expression }
    const valMap = useMemo(() => {
        const m = new Map()
        for (const v of gvaleurs || []) {
            if (v.groupe_id !== group.id) continue
            const key = `${v.act_id}::${v.niveau_id}::${v.kind}`
            m.set(key, { value: v?.commentaire || '', expression: v?.expression || '' })
        }
        return m
    }, [gvaleurs, group.id])

    function cellVal(actId, nivId, kind) {
        return valMap.get(`${actId}::${nivId}::${kind}`) || { value:'', expression:'' }
    }

    const cats = useMemo(
        () => (categoriesByModule.get(module.id) || []).slice().sort((a,b)=>(a.ordre||0)-(b.ordre||0) || a.code.localeCompare(b.code)),
        [categoriesByModule, module.id]
    )

    // cellule affichage (value + expression)
    function RenderVal({ v }) {
        const hasV = (v.value || '').trim().length > 0
        const hasE = (v.expression || '').trim().length > 0
        if (!hasV && !hasE) return <span className="opacity-40">—</span>
        return (
            <div className="min-h-8">
                {hasV && <div className="font-mono text-sm break-words">{v.value}</div>}
                {hasE && <div className="text-xs opacity-70 break-words" title={v.expression}>{v.expression}</div>}
            </div>
        )
    }

    // helper: ligne vide (toutes valeurs vides sur niveaux visibles)
    function isRowEmpty(actId) {
        for (const n of niveaux) {
            const b = cellVal(actId, n.id, 'base')
            const s = cellVal(actId, n.id, 'surco')
            const bEmpty = !(b.value?.trim() || b.expression?.trim())
            const sEmpty = !(s.value?.trim() || s.expression?.trim())
            if (!hideSurco) {
                if (!bEmpty || !sEmpty) return false
            } else {
                if (!bEmpty) return false
            }
        }
        return true
    }

    return (
        <div className="card bg-base-100 shadow-md">
            <div className="card-body p-4">
                <div className="flex items-center gap-3 mb-2">
                    <div className="text-lg font-semibold">Groupe : {group.nom}</div>
                    <div className="badge">Priorité {group.priorite}</div>
                </div>

                <div className="overflow-x-auto">
                    <table className="table table-zebra">
                        <thead>
                        <tr>
                            <th rowSpan={2} className="align-bottom" style={{minWidth: 260}}>Garantie</th>
                            {niveaux.map(n => (
                                <th key={n.id} colSpan={hideSurco ? 1 : 2} className="text-center">{n.code}</th>
                            ))}
                        </tr>
                        <tr>
                            {niveaux.map(n => (
                                hideSurco
                                    ? <th key={`b-${n.id}`} className="text-center">Base</th>
                                    : (
                                        <Fragment key={`sub-${n.id}`}>
                                            <th className="text-center">Base</th>
                                            <th className="text-center">Surco</th>
                                        </Fragment>
                                    )
                            ))}
                        </tr>
                        </thead>
                        <tbody>
                        {cats.map(cat => {
                            // actes de la catégorie présents dans le groupe (tri par ordre groupe, fallback ref)
                            const acts = (actsByCategory.get(cat.id) || [])
                                .filter(a => orderMap.has(a.id)) // membre du groupe
                                .sort((a,b) => {
                                    const oa = orderMap.get(a.id) ?? 1e9
                                    const ob = orderMap.get(b.id) ?? 1e9
                                    if (oa !== ob) return oa - ob
                                    return (a.ordre||0)-(b.ordre||0) || a.code.localeCompare(b.code)
                                })

                            // option: masquer catégorie si toutes lignes vides
                            const visibleActs = hideEmptyRows ? acts.filter(a => !isRowEmpty(a.id)) : acts
                            if (visibleActs.length === 0) return null

                            return (
                                <Fragment key={cat.id}>
                                    <tr className="bg-base-200">
                                        <th colSpan={1 + niveaux.length*(hideSurco?1:2)} className="text-left">
                                            <span className="badge badge-outline mr-2">{cat.code}</span>
                                            <span className="opacity-70">{cat.libelle || '—'}</span>
                                        </th>
                                    </tr>

                                    {visibleActs.map(a => (
                                        <tr key={a.id}>
                                            <td>
                                                <div className="flex flex-col">
                                                    <span className="font-mono font-medium">{a.code}</span>
                                                    <span className="opacity-70 truncate">{a.libelle || '—'}</span>
                                                </div>
                                            </td>
                                            {niveaux.map(n => {
                                                const base = cellVal(a.id, n.id, 'base')
                                                const surc = cellVal(a.id, n.id, 'surco')
                                                return hideSurco ? (
                                                    <td key={`${a.id}-${n.id}-b`}><RenderVal v={base} /></td>
                                                ) : (
                                                    <Fragment key={`${a.id}-${n.id}`}>
                                                        <td><RenderVal v={base} /></td>
                                                        <td><RenderVal v={surc} /></td>
                                                    </Fragment>
                                                )
                                            })}
                                        </tr>
                                    ))}
                                </Fragment>
                            )
                        })}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}
