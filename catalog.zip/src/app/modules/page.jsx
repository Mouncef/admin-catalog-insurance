'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRefModules } from '@/providers/AppDataProvider'
import { sanitizeUpperKeep } from "@/lib/utils/StringUtil"
import { SquarePen, Trash2 } from "lucide-react"

export default function ModulePage() {
    const LS_KEY = 'app:ref_modules_v1'

    // données depuis le provider (persisté en localStorage)
    const { refModules, setRefModules } = useRefModules()

    const [mounted, setMounted] = useState(false)
    const [query, setQuery] = useState('')
    const [sortAsc, setSortAsc] = useState(true)
    const [toast, setToast] = useState(null) // {type:'success'|'error'|'info', msg:string}

    const upsertDialogRef = useRef(null)
    const deleteDialogRef = useRef(null)
    const importInputRef = useRef(null)

    const [editing, setEditing] = useState(null) // module en édition
    const [candidateDelete, setCandidateDelete] = useState(null)

    useEffect(() => { setMounted(true) }, [])

    // ======= Utils =======
    function uuid() {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID()
        return 'id-' + Math.random().toString(36).slice(2) + Date.now().toString(36)
    }

    function sanitizeModules(arr) {
        // Nettoyage simple — on ignore complètement "ordre"
        const cleaned = (arr ?? [])
            .filter(Boolean)
            .map((m) => ({
                id: m.id || uuid(),
                code: (m.code || '').trim(),
                libelle: (m.libelle || '').trim(),
            }))

        // Unicité du code (insensible à la casse) via fusion plutôt que renommage
        // -> On laisse submitUpsert empêcher les doublons; ici on supprime juste les entrées vides.
        return cleaned.filter((m) => !!m.code)
    }

    function showToast(type, msg) {
        setToast({ type, msg })
        setTimeout(() => setToast(null), 2500)
    }

    // ======= Sélecteurs/mémos =======
    const modules = useMemo(() => sanitizeModules(refModules || []), [refModules])

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase()
        const base = [...modules].sort((a, b) =>
            (sortAsc ? 1 : -1) * a.code.localeCompare(b.code)
        )
        if (!q) return base
        return base.filter(
            (m) => m.code.toLowerCase().includes(q) || (m.libelle || '').toLowerCase().includes(q)
        )
    }, [modules, query, sortAsc])

    // ======= CRUD =======
    function submitUpsert(e) {
        e?.preventDefault?.()
        if (!editing) return

        const code = (editing.code || '').trim()
        if (!code) return showToast('error', 'Le code est requis')
        if (code.length > 40) return showToast('error', 'Code ≤ 40 caractères')

        const duplicate = modules.find(
            (m) => m.code.toLowerCase() === code.toLowerCase() && m.id !== editing.id
        )
        if (duplicate) return showToast('error', `Le code "${code}" existe déjà`)

        const libelle = (editing.libelle || '').trim()

        if (!editing.id) {
            // create (sans ordre)
            const created = { id: uuid(), code, libelle }
            const next = sanitizeModules([...modules, created])
            setRefModules(next) // <-- persiste via provider -> localStorage
            showToast('success', 'Module créé')
        } else {
            // update (sans ordre)
            const next = sanitizeModules(
                modules.map((m) => (m.id === editing.id ? { ...m, code, libelle } : m))
            )
            setRefModules(next)
            showToast('success', 'Module mis à jour')
        }

        upsertDialogRef.current?.close()
        setEditing(null)
    }

    function requestDelete(mod) {
        setCandidateDelete(mod)
        deleteDialogRef.current?.showModal()
    }

    function confirmDelete() {
        if (!candidateDelete) return
        const next = sanitizeModules(modules.filter((m) => m.id !== candidateDelete.id))
        setRefModules(next)
        showToast('success', 'Module supprimé')
        deleteDialogRef.current?.close()
        setCandidateDelete(null)
    }

    function cancelDelete() {
        deleteDialogRef.current?.close()
        setCandidateDelete(null)
    }

    // ======= Import/Export =======
    function exportJSON() {
        const data = JSON.stringify(modules, null, 2) // sans ordre
        const blob = new Blob([data], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = 'ref_modules.json'
        a.click()
        URL.revokeObjectURL(url)
    }

    function triggerImport() {
        importInputRef.current?.click()
    }

    function onImportFileChange(e) {
        const file = e.target.files?.[0]
        if (!file) return
        const reader = new FileReader()
        reader.onload = () => {
            try {
                const parsed = JSON.parse(String(reader.result))
                if (!Array.isArray(parsed)) throw new Error('JSON attendu: tableau de modules')
                const merged = mergeKeepingUniqueCodes(modules, parsed)
                setRefModules(sanitizeModules(merged))
                showToast('success', 'Import réussi')
            } catch (err) {
                console.error(err)
                showToast('error', 'Import invalide: ' + (err?.message || 'erreur inconnue'))
            } finally {
                e.target.value = '' // reset input
            }
        }
        reader.readAsText(file)
    }

    function mergeKeepingUniqueCodes(existing, incoming) {
        // merge par code (case-insensitive), ignore "ordre"
        const byCode = new Map((existing || []).map((m) => [String(m.code || '').toLowerCase(), m]))
        for (const raw of incoming) {
            if (!raw) continue
            const item = {
                id: raw.id || uuid(),
                code: String(raw.code || '').trim(),
                libelle: String(raw.libelle || '').trim(),
            }
            if (!item.code) continue
            const k = item.code.toLowerCase()
            byCode.set(k, { ...byCode.get(k), ...item })
        }
        return Array.from(byCode.values())
    }

    function resetAll() {
        if (!confirm('Supprimer tous les modules stockés ?')) return
        setRefModules([])
        showToast('info', 'Liste vidée')
    }

    if (!mounted) {
        return (
            <div className="p-6">
                <div className="skeleton h-8 w-64 mb-4"></div>
                <div className="skeleton h-5 w-96 mb-2"></div>
                <div className="skeleton h-5 w-80"></div>
            </div>
        )
    }

    // ======= UI =======
    return (
        <div className="p-4 md:p-6 lg:p-8 space-y-4">
            {/* Header actions */}
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div className="text-xl font-semibold">Référentiel — Modules</div>
                <div className="flex gap-2">
                    {/* <button className="btn btn-outline" onClick={exportJSON}>Exporter JSON</button>
          <input ref={importInputRef} type="file" accept="application/json" className="hidden" onChange={onImportFileChange}/>
          <button className="btn btn-outline" onClick={triggerImport}>Importer JSON</button> */}
                    <button className="btn btn-error btn-outline" onClick={resetAll}>Vider</button>
                    <button
                        className="btn btn-primary"
                        onClick={() => { setEditing({ id: null, code: '', libelle: '' }); upsertDialogRef.current?.showModal() }}
                    >
                        Nouveau
                    </button>
                </div>
            </div>

            {/* Search + sort */}
            <div className="flex flex-col md:flex-row gap-3 items-start md:items-center">
                <label className="input input-bordered flex items-center gap-2 w-full md:w-96">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 opacity-70" viewBox="0 0 24 24" fill="currentColor"><path d="M10 2a8 8 0 015.292 13.708l4 4a1 1 0 01-1.414 1.414l-4-4A8 8 0 1110 2zm0 2a6 6 0 100 12A6 6 0 0010 4z"/></svg>
                    <input
                        type="text"
                        className="grow"
                        placeholder="Rechercher (code, libellé)"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />
                </label>
                <div className="form-control">
                    <label className="label cursor-pointer gap-3">
                        <span className="label-text">Tri A→Z</span>
                        <input
                            type="checkbox"
                            className="toggle"
                            checked={sortAsc}
                            onChange={() => setSortAsc((v) => !v)}
                        />
                    </label>
                </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
                <table className="table">
                    <thead>
                    <tr>
                        <th>Code</th>
                        <th>Libellé</th>
                        <th style={{width: 180}}>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    {filtered.map((m) => (
                        <tr key={m.id}>
                            <td className="font-mono">{m.code}</td>
                            <td>{m.libelle || <span className="opacity-50">(sans libellé)</span>}</td>
                            <td className="flex gap-2">
                                <button className="btn btn-xs btn-outline" onClick={() => { setEditing(m); upsertDialogRef.current?.showModal() }}>
                                    <SquarePen size={16} />
                                </button>
                                <button className="btn btn-xs btn-error btn-outline" onClick={() => requestDelete(m)}>
                                    <Trash2 size={16} />
                                </button>
                            </td>
                        </tr>
                    ))}
                    {filtered.length === 0 && (
                        <tr><td colSpan={3} className="opacity-60 italic">Aucun module</td></tr>
                    )}
                    </tbody>
                </table>
            </div>

            {/* Dialog: Create/Update */}
            <dialog ref={upsertDialogRef} className="modal sm:modal-middle">
                <div className="modal-box">
                    <h3 className="font-bold text-lg">
                        {editing?.id ? 'Modifier un module' : 'Nouveau module'}
                    </h3>
                    <fieldset className="fieldset bg-base-200 border-base-300 rounded-box border p-4">
                        <form className="mt-4 space-y-4" onSubmit={submitUpsert}>

                            <label className="floating-label block w-full">
                                <span className="block mb-1">Libellé <span className="text-error">*</span></span>
                                <input
                                    type="text"
                                    value={editing?.libelle ?? ''}
                                    onChange={(e) => setEditing((v) => ({
                                        ...v,
                                        libelle: e.target.value,
                                        code: sanitizeUpperKeep(e.target.value)
                                    }))}
                                    className="input input-bordered w-full font-mono"
                                    maxLength={40}
                                    required
                                />
                            </label>

                            <label className="floating-label block w-full">
                                <span className="block mb-1">Code <span className="text-error">*</span></span>
                                <input
                                    type="text"
                                    value={editing?.code ?? ''}
                                    onChange={(e) => setEditing((v) => ({ ...v, code: e.target.value }))}
                                    className="input input-bordered w-full font-mono"
                                    maxLength={40}
                                    required
                                />
                            </label>

                            <div className="modal-action">
                                <button type="button" className="btn btn-ghost" onClick={() => { upsertDialogRef.current?.close(); setEditing(null) }}>Annuler</button>
                                <button type="submit" className="btn btn-primary">Enregistrer</button>
                            </div>
                        </form>
                    </fieldset>
                </div>
                <form method="dialog" className="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>

            {/* Dialog: Delete confirm */}
            <dialog ref={deleteDialogRef} className="modal">
                <div className="modal-box">
                    <h3 className="font-bold text-lg">Supprimer le module ?</h3>
                    <p className="py-2">Cette action est irréversible.</p>
                    <div className="bg-base-200 rounded p-3 font-mono">
                        {candidateDelete?.code} — {candidateDelete?.libelle || 'sans libellé'}
                    </div>
                    <div className="modal-action">
                        <button className="btn" onClick={cancelDelete}>Annuler</button>
                        <button className="btn btn-error" onClick={confirmDelete}>Supprimer</button>
                    </div>
                </div>
                <form method="dialog" className="modal-backdrop">
                    <button>close</button>
                </form>
            </dialog>

            {/* Toast */}
            {toast && (
                <div className="toast">
                    <div className={`alert ${toast.type === 'success' ? 'alert-success' : toast.type === 'error' ? 'alert-error' : 'alert-info'}`}>
                        <span>{toast.msg}</span>
                    </div>
                </div>
            )}

            {/* Footer helper */}
            <div className="opacity-60 text-xs">
                <span className="font-mono">localStorage</span> clé: <span className="font-mono">{LS_KEY}</span> — {modules.length} modules
            </div>
        </div>
    )
}
