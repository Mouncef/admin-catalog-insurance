'use client'
export default function CatalogueHeader({ offer, catalogue, onBack, onSwitchMode }) {
    return (
        <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
                <h1 className="text-2xl font-bold">
                    {offer?.code} — {offer?.libelle}
                </h1>
                <div className="opacity-70">
                    Catalogue : {[catalogue?.risque, catalogue?.annee, catalogue?.version].filter(Boolean).join(' · ')}
                </div>
            </div>
            <div className="join">
                <button className="btn join-item" onClick={onSwitchMode}>↔ Mode modal</button>
                <button className="btn join-item" onClick={onBack}>← Retour liste</button>
            </div>
        </div>
    );
}
