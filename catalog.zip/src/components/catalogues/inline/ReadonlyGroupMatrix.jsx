'use client';

import { Fragment, useEffect, useMemo, useState } from 'react';

function CellView({ v }) {
    const hasV = (v?.value || '').trim().length > 0;
    const hasE = (v?.expression || '').trim().length > 0;
    if (!hasV && !hasE) return <span className="opacity-40">—</span>;
    return (
        <div className="min-h-8">
            {hasV && <div className="font-mono text-sm break-words">{v.value}</div>}
            {hasE && <div className="text-xs opacity-70 break-words" title={v.expression}>{v.expression}</div>}
        </div>
    );
}

export default function ReadonlyGroupMatrix({
                                                editable = false,
                                                group,
                                                module,
                                                niveaux,
                                                categoriesByModule,
                                                actsByCategory,
                                                membres,
                                                gvaleurs,
                                                onSave,
                                                onCancel,
                                            }) {
    // ===== base data
    const catsBase = useMemo(
        () => (categoriesByModule.get(module.id) || [])
            .slice()
            .sort((a, b) => (a.ordre || 0) - (b.ordre || 0) || a.code.localeCompare(b.code)),
        [categoriesByModule, module.id]
    );

    const membresRows = useMemo(
        () => (membres || [])
            .filter((m) => m.groupe_id === group.id)
            .sort((a, b) => (a.ordre || 1e9) - (b.ordre || 1e9)),
        [membres, group.id]
    );

    const valMapInitial = useMemo(() => {
        const m = new Map();
        for (const v of gvaleurs || []) {
            if (v.groupe_id !== group.id) continue;
            m.set(`${v.act_id}::${v.niveau_id}::${v.kind}`, {
                value: v?.commentaire || '',
                expression: v?.expression || '',
            });
        }
        return m;
    }, [gvaleurs, group.id]);

    const toValObj = (actId, nivId, kind) =>
        valMapInitial.get(`${actId}::${nivId}::${kind}`) || { value: '', expression: '' };

    // ===== local UI state
    const initialCatOrder = useMemo(() => {
        const stored = Array.isArray(group?.cat_order) ? group.cat_order : [];
        if (stored.length === 0) return catsBase.map((c) => c.id);
        const byId = new Set(catsBase.map((c) => c.id));
        return stored.filter((id) => byId.has(id)).concat(catsBase.filter((c) => !stored.includes(c.id)).map(c => c.id));
    }, [catsBase, group?.cat_order]);

    const [catOrder, setCatOrder] = useState(initialCatOrder);
    useEffect(() => setCatOrder(initialCatOrder), [initialCatOrder]);

    const [actOrder, setActOrder] = useState(() => membresRows.map((m) => m.act_id));
    useEffect(() => setActOrder(membresRows.map((m) => m.act_id)), [membresRows]);

    const [valuesByAct, setValuesByAct] = useState(() => {
        const out = {};
        for (const m of membresRows) {
            const aId = m.act_id;
            out[aId] = out[aId] || {};
            for (const n of (niveaux || [])) {
                const base = toValObj(aId, n.id, 'base');
                const surc = toValObj(aId, n.id, 'surco');
                if ((base.value || base.expression || surc.value || surc.expression)) {
                    out[aId][n.id] = { baseVal: base, surcoVal: surc };
                }
            }
        }
        return out;
    });
    useEffect(() => {
        const next = {};
        for (const m of membresRows) {
            const aId = m.act_id;
            next[aId] = next[aId] || {};
            for (const n of (niveaux || [])) {
                const base = toValObj(aId, n.id, 'base');
                const surc = toValObj(aId, n.id, 'surco');
                if ((base.value || base.expression || surc.value || surc.expression)) {
                    next[aId][n.id] = { baseVal: base, surcoVal: surc };
                }
            }
        }
        setValuesByAct(next);
    }, [valMapInitial, membresRows, niveaux]);

    const membersSet = useMemo(() => new Set(membresRows.map((m) => m.act_id)), [membresRows]);


    // ===== actions (si editable)
    function findActCategory(actId) {
        for (const c of catsBase) {
            const acts = actsByCategory.get(c.id) || [];
            if (acts.some((a) => a.id === actId)) return c.id;
        }
        return null;
    }
    function visibleActsInCat(catId, order) {
        const acts = (actsByCategory.get(catId) || []).filter((a) => membersSet.has(a.id));
        return acts
            .slice()
            .sort((a, b) => {
                const oa = order.indexOf(a.id);
                const ob = order.indexOf(b.id);
                if (oa !== ob) return oa - ob;
                const ra = a.ordre || 0, rb = b.ordre || 0;
                return (ra - rb) || a.code.localeCompare(b.code);
            })
            .map((a) => a.id);
    }
    function moveCategory(catId, dir) {
        if (!editable) return;
        setCatOrder((prev) => {
            const idx = prev.indexOf(catId);
            const tgt = dir === 'up' ? idx - 1 : idx + 1;
            if (idx < 0 || tgt < 0 || tgt >= prev.length) return prev;
            const arr = prev.slice();
            [arr[idx], arr[tgt]] = [arr[tgt], arr[idx]];
            return arr;
        });
    }
    function moveAct(actId, dir) {
        if (!editable) return;
        setActOrder((prev) => {
            const idx = prev.indexOf(actId);
            if (idx < 0) return prev;
            const catId = findActCategory(actId);
            if (!catId) return prev;
            const actsInCat = visibleActsInCat(catId, prev);
            const posInCat = actsInCat.indexOf(actId);
            const tgtInCat = dir === 'up' ? posInCat - 1 : posInCat + 1;
            if (posInCat < 0 || tgtInCat < 0 || tgtInCat >= actsInCat.length) return prev;
            const a = prev.indexOf(actsInCat[posInCat]);
            const b = prev.indexOf(actsInCat[tgtInCat]);
            const arr = prev.slice();
            [arr[a], arr[b]] = [arr[b], arr[a]];
            return arr;
        });
    }

    // edition cellule
    const [editing, setEditing] = useState(null); // { actId, nivId, kind, value, expression }
    function startEdit(actId, nivId, kind) {
        if (!editable) return;
        const pair = valuesByAct?.[actId]?.[nivId] || { baseVal: {}, surcoVal: {} };
        const cur = (kind === 'base' ? pair.baseVal : pair.surcoVal) || {};
        setEditing({ actId, nivId, kind, value: cur.value || '', expression: cur.expression || '' });
    }
    function saveEdit() {
        if (!editing) return;
        const { actId, nivId, kind, value, expression } = editing;
        setValuesByAct((prev) => {
            const next = { ...(prev || {}) };
            next[actId] = next[actId] || {};
            next[actId][nivId] = next[actId][nivId] || { baseVal: {}, surcoVal: {} };
            const key = kind === 'base' ? 'baseVal' : 'surcoVal';
            next[actId][nivId][key] = { value, expression };
            return next;
        });
        setEditing(null);
    }
    function cancelEdit() { setEditing(null); }
    function onCellKeyDown(e) {
        if (e.key === 'Escape') { e.preventDefault(); cancelEdit(); }
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); saveEdit(); }
    }

    // ===== submit
    function submitAll() {
        if (!editable) return;

        const catOrderSelected = catOrder.slice();

        const displayActIds = [];
        for (const catId of catOrderSelected) {
            const ids = visibleActsInCat(catId, actOrder);
            displayActIds.push(...ids);
        }

        const orderByAct = {};
        displayActIds.forEach((id, i) => (orderByAct[id] = i + 1));

        onSave?.({ catOrderSelected, orderByAct, valuesByAct });
    }

    return (
        <div className="space-y-3">
            {/*{editable && (
                <div className="flex items-center justify-end gap-2">
                    {onCancel && <button type="button" className="btn" onClick={onCancel}>Fermer</button>}
                    <button type="button" className="btn btn-primary" onClick={submitAll}>Enregistrer la grille</button>
                </div>
            )}*/}

            <div className="overflow-x-auto">
                <table className="table">
                    <thead>
                    <tr>
                        <th rowSpan={2} className="align-bottom" style={{ minWidth: 260 }}>Garantie</th>
                        {niveaux.map((n) => (
                            <th key={n.id} colSpan={2} className="text-center">{n.libelle}</th>
                        ))}
                    </tr>
                    <tr>
                        {niveaux.map((n) => (
                            <Fragment key={`sub-${n.id}`}>
                                <th className="text-center">Base</th>
                                <th className="text-center">Surco</th>
                            </Fragment>
                        ))}
                    </tr>
                    </thead>

                    <tbody>
                    { catOrder.length === 0 && (
                        <tr><td colSpan={1 + (niveaux.length * 2)} className="text-center opacity-60">—</td></tr>
                    )}

                    { (catOrder.map((id) => catsBase.find((c) => c.id === id)).filter(Boolean)).map((cat) => {
                        const actsRaw = actsByCategory.get(cat.id) || [];
                        const acts = actsRaw
                            .filter((a) => membersSet.has(a.id))
                            .sort((a, b) => {
                                const oa = actOrder.indexOf(a.id);
                                const ob = actOrder.indexOf(b.id);
                                if (oa !== ob) return oa - ob;
                                const ra = a.ordre || 0, rb = b.ordre || 0;
                                return (ra - rb) || a.code.localeCompare(b.code);
                            });

                        if (acts.length === 0) return null;

                        const isFirst = catOrder[0] === cat.id;
                        const isLast = catOrder[catOrder.length - 1] === cat.id;

                        return (
                            <Fragment key={cat.id}>
                                <tr className="bg-base-200">
                                    <th colSpan={1 + (niveaux.length * 2)} className="text-left">
                                        <div className="flex items-center gap-2">
                                            {/*<span className="badge badge-outline">{cat.code}</span>*/}
                                            <span className="opacity-70">{cat.libelle || '—'}</span>
                                            {editable && (
                                                <div className="ml-auto join">
                                                    <button
                                                        className="btn btn-xs join-item"
                                                        disabled={isFirst}
                                                        onClick={() => moveCategory(cat.id, 'up')}
                                                        title="Monter la catégorie" aria-label="Monter la catégorie"
                                                    >▲</button>
                                                    <button
                                                        className="btn btn-xs join-item"
                                                        disabled={isLast}
                                                        onClick={() => moveCategory(cat.id, 'down')}
                                                        title="Descendre la catégorie" aria-label="Descendre la catégorie"
                                                    >▼</button>
                                                </div>
                                            )}
                                        </div>
                                    </th>
                                </tr>

                                {acts.map((a) => (
                                    <tr key={a.id}>
                                        <td className="table-pin-cols">
                                            <div className="flex items-center gap-2 w-full">
                                                <div className="flex-1 min-w-0">
                                                    {/*<div className="font-mono font-medium">{a.code}</div>*/}
                                                    <div className="opacity-70 truncate">{a.libelle || '—'}</div>
                                                </div>
                                                {editable && (
                                                    <div className="join">
                                                        <button className="btn btn-xs join-item" onClick={() => moveAct(a.id, 'up')}>▲</button>
                                                        <button className="btn btn-xs join-item" onClick={() => moveAct(a.id, 'down')}>▼</button>
                                                    </div>
                                                )}
                                            </div>
                                        </td>

                                        {niveaux.map((n) => {
                                            const pair = valuesByAct?.[a.id]?.[n.id] || { baseVal: {}, surcoVal: {} };
                                            const isEditingBase = !!editing && editing.actId === a.id && editing.nivId === n.id && editing.kind === 'base';
                                            const isEditingSurc = !!editing && editing.actId === a.id && editing.nivId === n.id && editing.kind === 'surco';

                                            return (
                                                <Fragment key={`${a.id}-${n.id}`}>
                                                    {/* BASE */}
                                                    <td
                                                        onDoubleClick={() => startEdit(a.id, n.id, 'base')}
                                                        title={editable ? 'Double-clique pour éditer' : ''}
                                                    >
                                                        {editable && isEditingBase ? (
                                                            <div className="space-y-2" onKeyDown={onCellKeyDown}>
                                                                <input
                                                                    className="input input-sm input-bordered w-full font-mono"
                                                                    placeholder="value"
                                                                    autoFocus
                                                                    value={editing.value}
                                                                    onChange={(e) => setEditing((s) => ({ ...s, value: e.target.value }))}
                                                                />
                                                                <input
                                                                    className="input input-sm input-bordered w-full"
                                                                    placeholder="expression"
                                                                    value={editing.expression}
                                                                    onChange={(e) => setEditing((s) => ({ ...s, expression: e.target.value }))}
                                                                />
                                                                <div className="join">
                                                                    <button type="button" className="btn btn-xs btn-primary join-item" onClick={saveEdit}>Enregistrer</button>
                                                                    <button type="button" className="btn btn-xs join-item" onClick={cancelEdit}>Annuler</button>
                                                                </div>
                                                            </div>
                                                        ) : (
                                                            <CellView v={pair.baseVal} />
                                                        )}
                                                    </td>

                                                    {/* SURCO */}
                                                    <td
                                                        onDoubleClick={() => startEdit(a.id, n.id, 'surco')}
                                                        title={editable ? 'Double-clique pour éditer' : ''}
                                                    >
                                                        {editable && isEditingSurc ? (
                                                            <div className="space-y-2" onKeyDown={onCellKeyDown}>
                                                                <input
                                                                    className="input input-sm input-bordered w-full font-mono"
                                                                    placeholder="value"
                                                                    autoFocus
                                                                    value={editing.value}
                                                                    onChange={(e) => setEditing((s) => ({ ...s, value: e.target.value }))}
                                                                />
                                                                <input
                                                                    className="input input-sm input-bordered w-full"
                                                                    placeholder="expression"
                                                                    value={editing.expression}
                                                                    onChange={(e) => setEditing((s) => ({ ...s, expression: e.target.value }))}
                                                                />
                                                                <div className="join">
                                                                    <button type="button" className="btn btn-xs btn-primary join-item" onClick={saveEdit}>Enregistrer</button>
                                                                    <button type="button" className="btn btn-xs join-item" onClick={cancelEdit}>Annuler</button>
                                                                </div>
                                                            </div>
                                                        ) : (
                                                            <CellView v={pair.surcoVal} />
                                                        )}
                                                    </td>
                                                </Fragment>
                                            );
                                        })}
                                    </tr>
                                ))}
                            </Fragment>
                        );
                    })}
                    </tbody>
                </table>
            </div>

            {editable && (
                <div className="flex items-center justify-end gap-2">
                    {onCancel && <button type="button" className="btn" onClick={onCancel}>Fermer</button>}
                    <button type="button" className="btn btn-primary" onClick={submitAll}>Enregistrer la grille</button>
                </div>
            )}
        </div>
    );
}
