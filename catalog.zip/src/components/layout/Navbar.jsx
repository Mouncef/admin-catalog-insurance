"use client";
import { useEffect, useState } from "react";
import ThemeDropdown from "@/components/layout/ThemeDropdown";
import {PanelLeft, PanelLeftClose} from 'lucide-react'


export default function Navbar({ drawerId = "my-drawer-2" }) {
    const [collapsed, setCollapsed] = useState(false);
    // Lire l’état persistant au chargement (optionnel)
    useEffect(() => {
        const saved = localStorage.getItem("sidebar-collapsed") === "1";
        setCollapsed(saved);
        document.documentElement.setAttribute("data-sidebar", saved ? "collapsed" : "expanded");
    }, []);
    const toggleSidebar = () => {
        const next = !collapsed;
        setCollapsed(next);
        document.documentElement.setAttribute("data-sidebar", next ? "collapsed" : "expanded");
        localStorage.setItem("sidebar-collapsed", next ? "1" : "0");
    };


    return (
        <div className="navbar bg-base-100 shadow-sm">
        {/*<div className="navbar bg-base-100 shadow-sm">*/}
            <div className="navbar-start gap-1">

                <label htmlFor={drawerId} className="btn btn-ghost lg:hidden">
                    {/* … ton icône burger … */}
                    ☰
                </label>
                {/* Bouton Collapse (desktop) */}
                <button
                    onClick={toggleSidebar}
                    className="btn btn-ghost btn-square hidden lg:inline-flex"
                    aria-pressed={collapsed}
                    aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
                >
                    {collapsed ? <PanelLeft className="size-5"/> : <PanelLeftClose className="size-5"/> }
                </button>


                {/*<a className="btn btn-ghost text-xl">daisyUI</a>*/}
            </div>
            <div className="navbar-center hidden lg:flex">
                {/*<ul className="menu menu-horizontal px-1">
                    <li><a>Item 1</a></li>
                    <li>
                        <details>
                            <summary>Parent</summary>
                            <ul className="p-2">
                                <li><a>Submenu 1</a></li>
                                <li><a>Submenu 2</a></li>
                            </ul>
                        </details>
                    </li>
                    <li><a>Item 3</a></li>
                </ul>*/}
            </div>
            <div className="navbar-end gap-2">
                {/* ✅ Sélecteur de thème */}
                {/*<ThemeSelect className="hidden md:flex" />*/}
                <ThemeDropdown />

                {/* Avatar */}
                <div className="dropdown dropdown-end">
                    <div tabIndex={0} role="button" className="btn btn-ghost btn-circle avatar">
                        <div className="avatar avatar-online avatar-placeholder">
                            <div className="bg-neutral text-neutral-content w-9 rounded-full">
                                <span className="text-xl">MZ</span>
                            </div>
                        </div>
                        {/*<div className="w-10 rounded-full">
                            <img
                                alt="Tailwind CSS Navbar component"
                                src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.webp"/>
                        </div>*/}
                    </div>
                    <ul
                        tabIndex={0}
                        className="menu menu-sm dropdown-content bg-base-100 rounded-box z-1 mt-3 w-52 p-2 shadow">
                        <li>
                            <a className="justify-between">
                                Profile
                                <span className="badge">New</span>
                            </a>
                        </li>
                        <li><a>Settings</a></li>
                        <li><a>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    );
}
