'use client';

import {MultiStorageProvider, useMultiStorage} from '@/providers/MultiStorageProvider';
import {defaultSettings, SETTINGS_VERSION} from '@/lib/settings/default';

// util: pick léger
const pick = (obj, keys) =>
    keys.reduce((acc, k) => (k in obj ? (acc[k] = obj[k], acc) : acc), {});

// on découpe defaultSettings en 3 blocs : settings UI, ref_modules_v1, offres
function sourcesFromDefault(ds) {
    const UI_KEYS = ['version', 'theme', 'locale', 'density', 'apiBaseUrl', 'showBeta'];
    const ui = pick(ds, UI_KEYS);

    return {
        settings: {default: ui, version: SETTINGS_VERSION},
        ref_niveau_sets_v1: {default: ds.ref_niveau_sets_v1 ?? []},
        ref_niveaux_v1: {default: ds.ref_niveaux_v1 ?? []},
        ref_modules_v1: {default: ds.ref_modules_v1 ?? []},
        ref_categories_v1: {default: ds.ref_categories_v1 ?? []},
        ref_acts_v1: {default: ds.ref_acts_v1 ?? []},
        offres_v1: {default: ds.offres_v1 ?? []},
        catalogues_v1: {default: ds.catalogues_v1 ?? []},
        groupe_actes_membre_v1: {default: ds.groupe_actes_membre_v1 ?? []},
        groupe_valeur_v1: {default: ds.groupe_valeur_v1 ?? []},
        groupe_actes_v1: {default: ds.groupe_actes_v1 ?? []},
        cat_modules_v1: {default: ds.cat_modules_v1 ?? []},
        groupe_ui_state_v1: {default: ds.groupe_ui_state_v1 ?? {}},
    };
}

export function AppDataProvider({children}) {
    const devOverwrite = process.env.NEXT_PUBLIC_DEV_OVERWRITE === '1'
    return (
        <MultiStorageProvider
            namespace="app:"
            overwriteOnLoad={devOverwrite}
            clearNamespaceBeforeOverwrite={devOverwrite}
            sources={sourcesFromDefault(defaultSettings)}
        >
            {children}
        </MultiStorageProvider>
    )
}

/** Hooks confort (facultatifs) */
export function useUISettings() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        settings: data.settings,
        setSettings: (v) => set('settings', v),
        patchSettings: (p) => patch('settings', p),
        resetSettings: () => resetKey('settings'),
    };
}

export function useRefModules() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refModules: data.ref_modules_v1,
        setRefModules: (v) => set('ref_modules_v1', v),
        patchRefModules: (p) => patch('ref_modules_v1', p), // p = tableau complet ou objet selon ton usage
        resetRefModules: () => resetKey('ref_modules_v1'),
    };
}

export function useRefCategories() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refCategories: data.ref_categories_v1,
        setRefCategories: (v) => set('ref_categories_v1', v),
        patchRefCategories: (p) => patch('ref_categories_v1', p), // p = tableau complet ou objet selon ton usage
        resetRefCategories: () => resetKey('ref_categories_v1'),
    };
}

export function useRefActs() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refActs: data.ref_acts_v1,
        setRefActs: (v) => set('ref_acts_v1', v),
        patchRefActs: (p) => patch('ref_acts_v1', p), // p = tableau complet ou objet selon ton usage
        resetRefActs: () => resetKey('ref_acts_v1'),
    };
}

export function useRefOffers() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refOffers: data.offres_v1,
        setRefOffers: (v) => set('offres_v1', v),
        patchRefOffers: (p) => patch('offres_v1', p),
        resetRefOffers: () => resetKey('offres_v1'),
    };
}

export function useRefCatalogues() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refCatalogues: data.catalogues_v1,
        setRefCatalogues: (v) => set('catalogues_v1', v),
        patchRefCatalogues: (p) => patch('catalogues_v1', p),
        resetRefCatalogues: () => resetKey('catalogues_v1'),
    };
}

export function useRefNiveau() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refNiveau: data.ref_niveaux_v1,
        setRefNiveau: (v) => set('ref_niveaux_v1', v),
        patchRefNiveau: (p) => patch('ref_niveaux_v1', p),
        resetRefNiveau: () => resetKey('ref_niveaux_v1'),
    };
}

export function useRefNiveauSets() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refNiveauSets: data.ref_niveau_sets_v1 || [],
        setRefNiveauSets: (v) => set('ref_niveau_sets_v1', v),
        patchRefNiveauSets: (p) => patch('ref_niveau_sets_v1', p),
        resetRefNiveauSets: () => resetKey('ref_niveau_sets_v1'),
    };
}

export function useGroupActMembre() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refGroupActMembre: data.groupe_actes_membre_v1,
        setRefGroupActMembre: (v) => set('groupe_actes_membre_v1', v),
        patchRefGroupActMembre: (p) => patch('groupe_actes_membre_v1', p),
        resetRefGroupActMembre: () => resetKey('groupe_actes_membre_v1'),
    };
}

export function useGroupValeur() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refGroupValeur: data.groupe_valeur_v1,
        setRefGroupValeur: (v) => set('groupe_valeur_v1', v),
        patchRefGroupValeur: (p) => patch('groupe_valeur_v1', p),
        resetRefGroupValeur: () => resetKey('groupe_valeur_v1'),
    };
}

export function useGroupActes() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        refGroupActes: data.groupe_actes_v1,
        setRefGroupActes: (v) => set('groupe_actes_v1', v),
        patchRefGroupActes: (p) => patch('groupe_actes_v1', p),
        resetRefGroupActes: () => resetKey('groupe_actes_v1'),
    };
}

export function useCatModules() {
    const {data, set, patch, resetKey} = useMultiStorage();
    const value = Array.isArray(data.cat_modules_v1) ? data.cat_modules_v1 : [];
    return {
        catModules: value,
        setCatModules: (next) => {
            const resolved = (typeof next === 'function') ? next(value) : next;
            // garde-fou : on évite d’écrire autre chose qu’un tableau
            set('cat_modules_v1', Array.isArray(resolved) ? resolved : []);
        },
        patchCatModules: (p) => patch('cat_modules_v1', p),
        resetCatModules: () => resetKey('cat_modules_v1'),
    };
}

export function useGroupeUIState() {
    const {data, set, patch, resetKey} = useMultiStorage();
    return {
        uiState: data.groupe_ui_state_v1 || {},              // shape: { [groupId]: { locked: bool, acts: string[] } }
        setUIState: (v) => set('groupe_ui_state_v1', v),     // remplace l’objet complet
        patchUIState: (p) => patch('groupe_ui_state_v1', p), // fusion superficielle (selon ton implémentation)
        resetGroupeUIState: () => resetKey('groupe_ui_state_v1'),
    };
}


